package com.gfdrps.core;

/** One of the 6 sample slots: sample, 8 play modes, 8 voices, 5 effects, gesture recorder. Audio-thread only. */
public final class Slot {
    public static final int SLICER = 0, LOOPER = 1, BOW = 2, TAPE = 3, SCRATCH = 4, ARP = 5, KEYBOARD = 6, LOOPPLAYER = 7;
    public static final String[] MODE_NAMES = {"Slicer", "Looper", "Bow", "Tape", "Scratch", "Arpeggiator", "Keyboard", "Loop Player"};
    public static final int VOICES = 12, POLY = 8, KEYS = 24, MAX_BLOCK = 512;
    public static final int[] DIVS = {0, 4, 6, 8, 12, 16, 24, 32, 48, 64};

    final int rate;
    public volatile Sample sample;

    // user parameters (written from UI thread, read on audio thread: plain volatiles)
    public volatile int mode = SLICER;
    public volatile float volume = 0.8f, attack = 0f, decay = 0.25f, sustain = 1f, release = 0.15f, pan = 0.5f;
    public volatile int div = 0;            // slices / arp steps per bar (0 = default 8); looper marker quantize (0 = free)
    public volatile int transpose = 0;      // semitones
    /** Live pitch bend in semitones (fractional), added on top of transpose while notes play. */
    public volatile float bend = 0f;
    /** Fine tuning in semitones (the decimals of a typed pitch), kept with the track. */
    public volatile float fine = 0f;
    /** How much of the sample the waveform shows (1 = all, 4 = a quarter): the looper's grid is relative to what is on screen. */
    public volatile float viewZoom = 1f;
    public volatile boolean infinite = false, gate = false, legato = false, arpRandom = false, muted = false;
    public volatile double sampleBeats = 8;  // length of the sample in beats (loop player sync)
    public volatile boolean reversed = false;
    /** Looper: loop bounces back and forth between the fingers. */
    public volatile boolean pingPong = false;
    /** Bow: size of the grain window, 0 (tiny, granular) .. 1 (long, pad-like). Height of the finger = volume. */
    public volatile float bowSize = 0.45f;
    /** Loop Player / transpose without changing the other: tempo lock keeps the pitch (time-stretch). */
    public volatile boolean stretch = false;
    /** Keyboard (and trim) region, 0..1 of the sample. */
    public volatile float regStart = 0f, regEnd = 1f;
    /** Manual slice boundaries (0..1, sorted, interior only). null = even grid from {@link #div}. */
    public volatile float[] markers = null;

    public final Fx.Effect[] fx = new Fx.Effect[Fx.COUNT];
    public final GestureRecorder gestures = new GestureRecorder();
    final Voice[] voices = new Voice[VOICES];
    private final float[] mono = new float[MAX_BLOCK], bl = new float[MAX_BLOCK], br = new float[MAX_BLOCK];

    // touch bookkeeping
    private final int[] tIds = new int[16];
    private final float[] tX = new float[16], tY = new float[16];
    private final Voice[] tVoice = new Voice[16];
    /** Keyboard chords: the other notes of a chord belong to the same finger (up to 5 notes in all). */
    private final Voice[][] tExtra = new Voice[16][4];

    // ---- keyboard scales and chords
    public static final String[] SCALE_NAMES = {"Cromática", "Maior", "Menor natural", "Menor harmônica", "Menor melódica", "Dórico", "Frígio", "Lídio", "Mixolídio",
            "Pentatônica maior", "Pentatônica menor", "Blues", "Tons inteiros", "Diminuta", "Árabe", "Japonesa (In)"};
    public static final int[][] SCALES = {{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}, {0, 2, 4, 5, 7, 9, 11}, {0, 2, 3, 5, 7, 8, 10}, {0, 2, 3, 5, 7, 8, 11}, {0, 2, 3, 5, 7, 9, 11},
            {0, 2, 3, 5, 7, 9, 10}, {0, 1, 3, 5, 7, 8, 10}, {0, 2, 4, 6, 7, 9, 11}, {0, 2, 4, 5, 7, 9, 10}, {0, 2, 4, 7, 9}, {0, 3, 5, 7, 10}, {0, 3, 5, 6, 7, 10},
            {0, 2, 4, 6, 8, 10}, {0, 2, 3, 5, 6, 8, 9, 11}, {0, 1, 4, 5, 7, 8, 11}, {0, 1, 5, 7, 8}};
    public static final String[] NOTE_NAMES = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    public static final String[] CHORD_NAMES = {"Off", "Maior", "Menor", "7", "Maj7", "m7", "sus2", "sus4", "dim", "aug", "9", "Power (5ª)", "Oitava", "Diatônico (tríade)", "Diatônico (7ª)"};
    public static final int[][] CHORDS = {{0}, {0, 4, 7}, {0, 3, 7}, {0, 4, 7, 10}, {0, 4, 7, 11}, {0, 3, 7, 10}, {0, 2, 7}, {0, 5, 7}, {0, 3, 6}, {0, 4, 8}, {0, 4, 7, 10, 14}, {0, 7, 12}, {0, 12}, {0, 4, 7}, {0, 4, 7, 11}};
    public static final int CHORD_DIATONIC = 13, CHORD_DIATONIC7 = 14;
    /** Scale (0 = chromatic: the 24 keys are semitones), root note 0..11 and chord type for the keyboard. */
    public volatile int scaleType = 0, scaleRoot = 0, chordType = 0;

    private int semiOfDegree(int d, int[] iv) {
        int n = iv.length;
        return Math.floorDiv(d, n) * 12 + iv[Math.floorMod(d, n)];
    }
    /** Semitone offset (from the sample's own pitch) of a key, before transposition. */
    public int keySemi(int key) {
        if (scaleType <= 0) return key - KEYS / 2;
        int[] iv = SCALES[Math.min(SCALES.length - 1, scaleType)];
        return semiOfDegree(key - iv.length, iv) + scaleRoot;
    }
    /** True for the keys that sit on the scale's root (the UI highlights them). */
    public boolean keyIsRoot(int key) {
        if (scaleType <= 0) return Math.floorMod(key - KEYS / 2, 12) == 0;
        return Math.floorMod(key - SCALES[Math.min(SCALES.length - 1, scaleType)].length, SCALES[Math.min(SCALES.length - 1, scaleType)].length) == 0;
    }
    /** Semitone offsets of every note played by a key (just one unless a chord is selected). */
    public int[] keyNotes(int key) {
        int ct = Math.max(0, Math.min(CHORDS.length - 1, chordType));
        int base = keySemi(key);
        if (ct == 0) return new int[]{base};
        if (ct == CHORD_DIATONIC || ct == CHORD_DIATONIC7) {
            int[] iv = scaleType > 0 ? SCALES[Math.min(SCALES.length - 1, scaleType)] : SCALES[1];
            if (scaleType > 0) {
                int d = key - iv.length, c = ct == CHORD_DIATONIC ? 3 : 4;
                int[] o = new int[c];
                for (int i = 0; i < c; i++) o[i] = semiOfDegree(d + 2 * i, iv) + scaleRoot;
                return o;
            }
        }
        int[] ch = CHORDS[ct];
        int[] o = new int[ch.length];
        for (int i = 0; i < ch.length; i++) o[i] = base + ch[i];
        return o;
    }

    private int tCount;
    // arpeggiator
    /** 0 up (left to right), 1 down, 2 up-down, 3 random, 4 order the fingers were put down. */
    public volatile int arpDir = 0;
    /** Notes per bar: 4, 8, 16 or 32 (1/4 .. 1/32 notes). */
    public volatile int arpRate = 16;
    /** Slice played by the last arp step and a 1..0 flash for the UI. */
    public volatile int arpSlice = -1;
    public volatile float arpFlash;
    private double nextStepBeat = -1;
    private boolean arpImmediate;
    private int arpCounter, arpLast = -1;
    private final int[] arpTmp = new int[16], arpOrd = new int[16];
    private final float[] arpVel = new float[16];
    private final double[] bounds = new double[2];
    private final int[] tSlice = new int[16], tSlice0 = new int[16];
    private final Voice[] looperVs = new Voice[4];
    /** Loops kept by the latch after the fingers left (each can be re-tuned with handles on its two ends). */
    private final boolean[] pairFull = new boolean[4], pairDone = new boolean[4];
    private final Voice[] latchedLoops = new Voice[8];
    /** UI snapshot of the kept loops: start/end as 0..1 positions. */
    public final float[] uiLoopA = new float[8], uiLoopB = new float[8];
    public volatile int uiLoopN;
    private boolean isLooperVoice(Voice v) {
        for (Voice x : looperVs) if (x == v) return true;
        for (Voice x : latchedLoops) if (x == v) return true;
        return false;
    }
    private void keepLoop(Voice v) {
        v.latched = true;
        for (int i = 0; i < latchedLoops.length; i++) if (latchedLoops[i] == v) return;
        int slot = -1;
        for (int i = 0; i < latchedLoops.length; i++) { Voice o = latchedLoops[i]; if (o == null || !o.active || o.releasing || o.touchId != -3) { slot = i; break; } }
        if (slot < 0) { Voice o = latchedLoops[0]; o.latched = false; o.release(); System.arraycopy(latchedLoops, 1, latchedLoops, 0, latchedLoops.length - 1); slot = latchedLoops.length - 1; }
        latchedLoops[slot] = v;
    }
    private void snapshotLoops() {
        int n = 0;
        Sample s = sample;
        for (int i = 0; i < latchedLoops.length; i++) {
            Voice v = latchedLoops[i];
            if (v == null || !v.active || v.releasing || !v.latched || s == null) continue;
            double len = Math.max(1, s.length());
            uiLoopA[n] = (float) (v.start / len); uiLoopB[n] = (float) (v.end / len); n++;
        }
        uiLoopN = n;
    }
    /** Moves one end of a kept loop (index as in uiLoopA/B). Called on the audio thread. */
    public void setLoopEdge(int index, boolean end, float x) {
        Sample s = sample; if (s == null) return;
        int n = 0;
        for (int i = 0; i < latchedLoops.length; i++) {
            Voice v = latchedLoops[i];
            if (v == null || !v.active || v.releasing || !v.latched) continue;
            if (n++ != index) continue;
            double len = s.length(), pos = Math.max(0.0, Math.min(1.0, x)) * len;
            double st = v.start, en = v.end;
            if (end) en = Math.max(st + 64, Math.min(len, pos)); else st = Math.min(en - 64, Math.max(0, pos));
            v.setRegion(st, en);
            return;
        }
    }
    private void releaseLoopers() {
        for (int k = 0; k < looperVs.length; k++) {
            Voice v = looperVs[k];
            if (v != null && v.active && v.touchId == -3) { if (latch) keepLoop(v); else v.release(); }
            looperVs[k] = null;
        }
    }

    // latch / quantize / slicer auto-play
    /** Latch: lifting the finger (or changing play mode) leaves the sound running until the next gesture. */
    public volatile boolean latch = false;
    /** Slicer & Keyboard: triggers wait for the next grid step ({@link #arpRate} notes per bar). */
    public volatile boolean quantize = false;
    /** Slicer: plays the slices by itself, left to right (or shuffled), one per grid step. */
    public volatile boolean autoPlay = false, shuffle = false;
    /** Shuffle flavours for the auto-play order. */
    public static final String[] SHUFFLE_NAMES = {"Aleatório (sem repetir)", "Aleatório livre", "Vai e volta", "Da direita p/ esquerda", "Caminhada (±1–2)", "Pares depois ímpares", "Espelhado (meio p/ fora)"};
    public volatile int shuffleMode = 0;
    /** Chance (0..1) that an auto step is skipped (rests). */
    public volatile float autoSkip = 0f;

    // ---- slicer step mode: every slice is a step with its own on/off, pitch, filter, attack, decay and chance
    public static final int STEPS = 128;
    public volatile boolean stepMode = false;
    public final boolean[] stepOn = new boolean[STEPS];
    public final float[] stepPitch = new float[STEPS];            // semitones -12..12
    public final float[] stepFilter = new float[STEPS];           // 0..1, 1 = open
    public final float[] stepAtk = new float[STEPS];              // 0..1
    public final float[] stepDec = new float[STEPS];              // 0..1 (1 = the whole slice, small = short plucks)
    public final float[] stepChance = new float[STEPS];           // 0..1 probability that the step plays
    public volatile int stepPlaying = -1;
    { resetSteps(); }
    public void resetSteps() {
        for (int i = 0; i < STEPS; i++) { stepOn[i] = true; stepPitch[i] = 0f; stepFilter[i] = 1f; stepAtk[i] = 0f; stepDec[i] = 1f; stepChance[i] = 1f; }
    }
    public void randomizeSteps() {
        java.util.Random r = new java.util.Random();
        int n = Math.min(STEPS, Math.max(1, sliceTotal()));
        for (int i = 0; i < n; i++) {
            stepOn[i] = r.nextFloat() < 0.85f;
            stepPitch[i] = r.nextFloat() < 0.6f ? 0f : (float) (r.nextInt(13) - 6);
            stepFilter[i] = r.nextFloat() < 0.5f ? 1f : 0.35f + 0.65f * r.nextFloat();
            stepAtk[i] = r.nextFloat() < 0.7f ? 0f : 0.3f * r.nextFloat();
            stepDec[i] = r.nextFloat() < 0.6f ? 1f : 0.25f + 0.75f * r.nextFloat();
            stepChance[i] = r.nextFloat() < 0.7f ? 1f : 0.4f + 0.5f * r.nextFloat();
        }
    }
    /** Set when a touch needs the transport running (loop player); the engine clears it. */
    public volatile boolean requestTransport = false;
    private int lastMode = -1, physDown;
    private boolean arpLatched;
    private double curBeat, nextAutoBeat = -1;
    private int autoCounter, autoLast = -1;
    private final int[] pId = new int[8];
    private final float[] pX = new float[8], pY = new float[8];
    private final double[] pBeat = new double[8];
    private final boolean[] pUp = new boolean[8];
    private int pN;
    private float curGL, curGR;
    // visual feedback (read by UI)
    public final float[] playheads = new float[VOICES];
    /** Fingers currently held in this slot (live and replayed gestures), for the UI: id, x, y (position in the sample). Gesture-replay ids are >= GestureRecorder.ID_OFFSET. */
    public final int[] uiId = new int[16];
    public final float[] uiX = new float[16], uiY = new float[16];
    public volatile int uiN;
    public volatile int activeVoices;
    public volatile float level;

    public Slot(int rate) {
        this.rate = rate;
        for (int i = 0; i < VOICES; i++) { voices[i] = new Voice(); voices[i].engineRate = rate; }
        for (int i = 0; i < Fx.COUNT; i++) fx[i] = Fx.create(i, rate);
    }

    public void setSample(Sample s, double bpm) {
        stopAll();
        sample = s;
        markers = null;
        reversed = false;
        regStart = 0f; regEnd = 1f;
        if (s != null) {
            double dur = s.length() / (double) s.sampleRate;
            sampleBeats = Math.max(1, Math.round(dur * bpm / 60.0));
        }
    }

    /** Undo support: everything an edit can change about the sample. */
    public static final class Snapshot {
        public final Sample sample; public final float[] markers; public final boolean reversed; public final float regStart, regEnd;
        Snapshot(Sample s, float[] m, boolean r, float a, float b) { sample = s; markers = m; reversed = r; regStart = a; regEnd = b; }
    }

    public Snapshot snapshot() { return new Snapshot(sample, markers, reversed, regStart, regEnd); }

    public void restore(Snapshot n) {
        stopAll();
        sample = n.sample; markers = n.markers; reversed = n.reversed; regStart = n.regStart; regEnd = n.regEnd;
    }

    /** Cuts the sample to the region (regStart..regEnd). Markers inside the region are kept and rescaled. */
    public boolean trimToRegion() {
        Sample s = sample;
        if (s == null) return false;
        int n = s.length();
        int a = Math.max(0, (int) (regStart * n)), b = Math.min(n, (int) (regEnd * n));
        if (b - a < 64 || (a == 0 && b == n)) return false;
        float[] d = java.util.Arrays.copyOfRange(s.data, a, b);
        float[] m = markers;
        float[] nm = null;
        if (m != null) {
            float[] t = new float[m.length]; int c = 0;
            for (float v : m) { double p = (v * n - a) / (double) (b - a); if (p > 0.0 && p < 1.0) t[c++] = (float) p; }
            nm = cleanMarkers(java.util.Arrays.copyOf(t, c));
        }
        stopAll();
        sample = new Sample(d, s.sampleRate, s.name);
        markers = nm;
        regStart = 0f; regEnd = 1f;
        return true;
    }

    /** Plays the sample backwards from now on (toggle: calling it again restores it). */
    public void reverseSample() {
        Sample s = sample;
        if (s == null) return;
        int n = s.length();
        float[] d = new float[n];
        for (int i = 0; i < n; i++) d[i] = s.data[n - 1 - i];
        softStopAll();
        sample = new Sample(d, s.sampleRate, s.name);
        reversed = !reversed;
        float[] m = markers;
        if (m != null) {
            float[] nm = new float[m.length];
            for (int i = 0; i < m.length; i++) nm[i] = 1f - m[m.length - 1 - i];
            markers = nm;
        }
    }

    /** Sorts, clamps and de-duplicates marker positions; returns null when there are none. */
    public static float[] cleanMarkers(float[] in) {
        if (in == null || in.length == 0) return null;
        float[] c = in.clone();
        java.util.Arrays.sort(c);
        float[] out = new float[c.length];
        int n = 0;
        for (float v : c) {
            if (!(v > 0.002f && v < 0.998f)) continue;
            if (n > 0 && v - out[n - 1] < 0.004f) continue;
            out[n++] = v;
            if (n >= 63) break;
        }
        return n == 0 ? null : java.util.Arrays.copyOf(out, n);
    }

    /** Interior slice boundaries currently in use (manual markers or the even grid), for drawing. */
    public float[] sliceBoundaries() {
        float[] m = markers;
        if (m != null) return m;
        int n = sliceCount();
        float[] g = new float[n - 1];
        for (int i = 1; i < n; i++) g[i - 1] = i / (float) n;
        return g;
    }

    /** Fades every voice out quickly (no click) and forgets all fingers, arp steps and the looper. */
    public void fadeAll() {
        for (Voice v : voices) if (v.active) v.fastRelease();
        tCount = 0;
        for (int i = 0; i < tVoice.length; i++) { tVoice[i] = null; java.util.Arrays.fill(tExtra[i], null); }
        nextStepBeat = -1;
        java.util.Arrays.fill(looperVs, null);
        autoPlay = false;
        pN = 0; physDown = 0; arpLatched = false; nextAutoBeat = -1;
    }

    /** Releases every note kept alive by the latch (audio thread). exceptLooper keeps the looper voice for reuse. */
    private void releaseLatched(boolean exceptLooper) {
        for (Voice v : voices) {
            if (v.active && v.latched && !(exceptLooper && isLooperVoice(v))) { v.latched = false; v.release(); }
        }
        if (!exceptLooper) java.util.Arrays.fill(latchedLoops, null);
    }

    private void releaseAuto() {
        for (Voice v : voices) if (v.active && v.touchId == -5 && !v.releasing) v.release();
    }

    /** Called on the audio thread when the latch button changes. */
    public void applyLatch(boolean on) {
        latch = on;
        if (!on) {
            releaseLatched(false);
            java.util.Arrays.fill(latchedLoops, null);
            if (tCount == 0) for (Voice v : looperVs) if (v != null && v.active && v.touchId == -3) v.release();
            if (arpLatched && physDown == 0) { tCount = 0; arpLatched = false; nextStepBeat = -1; }
        }
    }

    /** Fades every voice out in ~5 ms instead of cutting it (no click when the sample is swapped under a playing note). */
    public void softStopAll() {
        for (Voice v : voices) if (v.active) v.fastRelease();
        tCount = 0;
        for (int i = 0; i < tVoice.length; i++) { tVoice[i] = null; java.util.Arrays.fill(tExtra[i], null); }
    }

    public void stopAll() {
        for (Voice v : voices) v.kill();
        tCount = 0;
        for (int i = 0; i < tVoice.length; i++) { tVoice[i] = null; java.util.Arrays.fill(tExtra[i], null); }
    }

    private float bowGrain() { float b = bowSize; return (float) ((0.012 + b * b * 0.35) * rate); }

    private double pitchRatio() { return Math.pow(2.0, transpose / 12.0); }
    private int sliceCount() { int d = div; return d <= 0 ? 8 : d; }

    /** Index of the slice under horizontal position x (manual markers or even grid). */
    public int sliceIndex(float x) {
        float[] mk = markers;
        if (mk != null) {
            int i = 0;
            while (i < mk.length && x >= mk[i]) i++;
            return i;
        }
        int n = sliceCount();
        return Math.min(n - 1, (int) (x * n));
    }

    /** Start/end (0..1) of slice idx. */
    private void sliceBounds(int idx, double[] out) {
        float[] mk = markers;                       // one snapshot: the UI may change the slices at any time
        if (mk != null) {
            if (idx < 0) idx = 0;
            if (idx > mk.length) idx = mk.length;
            out[0] = idx == 0 ? 0.0 : mk[idx - 1];
            out[1] = idx >= mk.length ? 1.0 : mk[idx];
        } else {
            int n = sliceCount();
            if (idx < 0) idx = 0;
            if (idx > n - 1) idx = n - 1;
            out[0] = (double) idx / n;
            out[1] = (double) (idx + 1) / n;
        }
    }

    public int sliceTotal() { float[] mk = markers; return mk != null ? mk.length + 1 : sliceCount(); }

    private int find(int id) {
        for (int i = 0; i < tCount; i++) if (tIds[i] == id) return i;
        return -1;
    }

    /** Gives a free voice. Beyond POLY live voices the oldest one is faded out (no hard cut = no click). */
    private Voice alloc(long frame) {
        int live = 0;
        Voice free = null, oldestLive = null;
        for (Voice v : voices) {
            if (!v.active) { if (free == null) free = v; continue; }
            if (!v.releasing) {
                live++;
                if (oldestLive == null || v.startedAt < oldestLive.startedAt) oldestLive = v;
            }
        }
        if (live >= POLY && oldestLive != null) oldestLive.fastRelease();
        if (free != null) return free;
        Voice pick = null;
        for (Voice v : voices) {
            if (pick == null || (v.releasing && !pick.releasing) || (v.releasing == pick.releasing && v.startedAt < pick.startedAt)) pick = v;
        }
        pick.kill();
        return pick;
    }

    private Voice prepare(int kind, long frame) {
        Sample s = sample;
        Voice v = alloc(frame);
        v.sm = s;
        v.kind = kind;
        v.ratio = s.sampleRate / (double) rate;
        v.engineRate = rate;
        v.setEnv(attack, decay, sustain, release);
        v.speed = pitchRatio();
        v.loop = false;
        v.pingPong = false;
        v.pitch = 1.0;
        v.vel = 1f;
        v.fCut = 1f;
        return v;
    }

    // ---------------------------------------------------------------- touch handling

    public void handle(int type, int id, float x, float y, long frame, double beat) {
        Sample s = sample;
        if (s == null || s.length() < 2) return;
        x = clamp01(x); y = clamp01(y);
        if (type != 0 || !(quantize && (mode == SLICER || mode == KEYBOARD))) {
            int q = pendingIndex(id);
            if (q >= 0 && type == 1) { pX[q] = x; pY[q] = y; return; }              // finger still moving before its quantized start
            if (q >= 0 && type == 2) { pUp[q] = true; return; }                     // lifted early: released right after it starts
        }
        if (type == 0) {
            if (quantize && (mode == SLICER || mode == KEYBOARD) && pN < pId.length) {
                double step = 4.0 / Math.max(1, arpRate);
                int q = pendingIndex(id);
                if (q < 0) q = pN++;
                pId[q] = id; pX[q] = x; pY[q] = y; pUp[q] = false;
                pBeat[q] = Math.ceil(curBeat / step - 1e-9) * step;
                return;
            }
            down(id, x, y, frame, beat, s);
        } else if (type == 1) move(id, x, y, s);
        else up(id);
    }

    private int pendingIndex(int id) {
        for (int i = 0; i < pN; i++) if (pId[i] == id) return i;
        return -1;
    }

    private void firePending(double uptoBeat, long frame, Sample s) {
        for (int i = 0; i < pN; ) {
            if (pBeat[i] <= uptoBeat) {
                int id = pId[i]; float x = pX[i], y = pY[i]; boolean upNow = pUp[i];
                for (int j = i; j < pN - 1; j++) { pId[j] = pId[j + 1]; pX[j] = pX[j + 1]; pY[j] = pY[j + 1]; pBeat[j] = pBeat[j + 1]; pUp[j] = pUp[j + 1]; }
                pN--;
                down(id, x, y, frame, curBeat, s);
                if (upNow) up(id);
            } else i++;
        }
    }

    private void down(int id, float x, float y, long frame, double beat, Sample s) {
        int k = find(id);
        if (k >= 0) { remove(k); }
        if (mode == ARP && arpLatched && physDown == 0) { tCount = 0; arpLatched = false; }     // a new gesture replaces the latched pattern
        if (latch && physDown == 0 && mode != LOOPPLAYER) releaseLatched(mode == LOOPER);
        physDown++;
        if (tCount >= tIds.length) return;
        k = tCount++;
        tIds[k] = id; tX[k] = x; tY[k] = y; tVoice[k] = null;
        int len = s.length();
        float vel = 0.25f + 0.75f * (1f - y);
        switch (mode) {
            case SLICER: {
                sliceBounds(sliceIndex(x), bounds);
                Voice v = prepare(Voice.PLAY, frame);
                v.start = bounds[0] * len;
                v.end = bounds[1] * len;
                v.pos = v.start;
                v.loop = infinite;
                v.vel = vel;
                v.trigger(id, frame);
                tVoice[k] = v;
                tSlice[k] = tSlice0[k] = sliceIndex(x);
                arpSlice = tSlice[k]; arpFlash = 1f;
                break;
            }
            case LOOPER:
                updateLooper(frame, s);
                break;
            case BOW: {
                int live = 0; Voice oldest = null;                      // up to 4 notes at once
                for (Voice o : voices) if (o.active && o.kind == Voice.BOW && !o.releasing) { live++; if (oldest == null || o.startedAt < oldest.startedAt) oldest = o; }
                if (live >= 4 && oldest != null) oldest.fastRelease();
                Voice v = prepare(Voice.BOW, frame);
                v.center = x * (len - 1);
                v.grainTgt = bowGrain();
                v.gPos[0] = v.gPos[1] = v.center;
                v.gPh[0] = 0f; v.gPh[1] = 0.5f;
                v.vel = 0.2f + 0.6f * (1f - y);                          // height = volume
                v.trigger(id, frame);
                tVoice[k] = v;
                break;
            }
            case TAPE: {
                Voice v = prepare(Voice.TAPE, frame);
                v.pos = x * (len - 1);
                v.center = x;           // x where the finger went down
                v.speed = pitchRatio();
                v.baseSpeed = v.speed;
                v.vel = 0.9f;
                v.trigger(id, frame);
                tVoice[k] = v;
                break;
            }
            case SCRATCH: {
                Voice v = prepare(Voice.SCRATCH, frame);
                v.pos = x * (len - 1);
                v.center = x;                                   // x where the finger went down
                v.scrBase = v.pos;
                v.scrTarget = v.pos;
                // full screen width = 0.25 s (finger low) .. 2 s (finger high) of audio
                v.scrSpan = (0.25 + 1.75 * (1.0 - y)) * s.sampleRate;
                v.vel = 0.9f;
                v.trigger(id, frame);
                tVoice[k] = v;
                break;
            }
            case ARP:
                if (tCount == 1) { arpCounter = 0; arpLast = -1; arpImmediate = true; }
                break;
            case KEYBOARD: {
                int key = Math.min(KEYS - 1, (int) (x * KEYS));
                int[] notes = keyNotes(key);
                double rs = Math.min(regStart, regEnd - 0.002f) * len, re = Math.max(regEnd, regStart + 0.002f) * len;
                java.util.Arrays.fill(tExtra[k], null);
                for (int ni = 0; ni < notes.length && ni < 5; ni++) {
                    Voice v = prepare(Voice.PLAY, frame);
                    v.speed = Math.pow(2.0, (notes[ni] + transpose) / 12.0);
                    v.start = Math.max(0, rs); v.end = Math.min(len, re); v.pos = v.start;
                    v.loop = infinite;
                    v.vel = vel * (ni == 0 ? 1f : 0.85f);
                    v.trigger(id, frame);
                    if (ni == 0) tVoice[k] = v; else tExtra[k][ni - 1] = v;
                }
                break;
            }
            case LOOPPLAYER: {
                // the finger is the play needle: touching puts the playhead there (and starts the loop if it was stopped)
                Voice running = null;
                for (Voice v : voices) if (v.active && (v.kind == Voice.PLAY || v.kind == Voice.STRETCH) && v.loop && !v.releasing && v.start == 0 && v.end == len && v.touchId == -2) running = v;
                double at = Math.max(0.0, Math.min(len - 1.0, x * (double) len));
                if (running != null) {
                    running.jumpTo(at);
                    tVoice[k] = running;
                } else {
                    Voice v = prepare(stretch ? Voice.STRETCH : Voice.PLAY, frame);
                    v.start = 0; v.end = len; v.loop = true;
                    v.vel = 0.9f;
                    v.pos = at;
                    v.pitch = pitchRatio();
                    v.speed = stretch ? 1.0 : pitchRatio();
                    v.trigger(-2, frame);   // -2 marks a loop-player voice (tempo-synced in render)
                    if (stretch) v.jumpTo(at);
                    tVoice[k] = v;
                    requestTransport = true;        // the very first touch starts it, no need to press play
                }
                break;
            }
            default: break;
        }
    }

    private void move(int id, float x, float y, Sample s) {
        int k = find(id);
        if (k < 0) return;
        tX[k] = x; tY[k] = y;
        Voice v = tVoice[k];
        int len = s.length();
        switch (mode) {
            case LOOPER: updateLooper(0, s); break;
            case BOW:
                if (v != null && v.active) {
                    v.center = x * (len - 1);
                    v.grainTgt = bowGrain();
                    v.vel = 0.2f + 0.6f * (1f - y);
                }
                break;
            case TAPE:
                if (v != null && v.active) {
                    double dx = x - v.center;
                    if (div > 0) dx = Math.round(dx * div) / (double) div;       // marker presets: the speed moves in steps
                    v.speedTgt = v.baseSpeed + dx * 6.0; v.glide = 0.003f;
                }
                break;
            case SCRATCH:
                if (v != null && v.active) {
                    double dxs = x - v.center;
                    if (div > 0) dxs = Math.round(dxs * div) / (double) div;     // marker presets: the playhead hops between steps
                    double t = v.scrBase + dxs * v.scrSpan;
                    v.scratchTo(Math.max(0, Math.min(len - 1, t)));
                }
                break;
            case SLICER:
                if (legato && v != null && v.active && !v.releasing) {
                    int idx = sliceIndex(x);
                    if (idx != tSlice[k]) {
                        // glissando: the note carries on into the new slice, gliding up/down one semitone per slice
                        sliceBounds(idx, bounds);
                        Voice nv = prepare(Voice.PLAY, 0);
                        nv.start = bounds[0] * len; nv.end = bounds[1] * len;
                        nv.pos = nv.start; nv.loop = infinite; nv.vel = v.vel;
                        double target = Math.pow(2.0, (idx - tSlice0[k]) / 12.0) * pitchRatio();
                        nv.speed = v.speed;
                        v.fastRelease();
                        nv.trigger(tIds[k], 0);
                        nv.speedTgt = target; nv.glide = 0.004f;
                        tVoice[k] = nv;
                        tSlice[k] = idx; arpSlice = idx; arpFlash = 1f;
                    }
                }
                break;
            case LOOPPLAYER:
                if (v != null && v.active && v.touchId == -2) v.jumpTo(Math.max(0.0, Math.min(len - 1.0, x * (double) len)));     // drag = scrub the needle
                break;
            case KEYBOARD:
                if (v != null && v.active) {
                    int key = Math.min(KEYS - 1, (int) (x * KEYS));
                    int[] notes = keyNotes(key);
                    if (legato) {
                        v.speedTgt = Math.pow(2.0, (notes[0] + transpose) / 12.0); v.glide = 0.0015f;
                        for (int ni = 1; ni < notes.length && ni < 5; ni++) {
                            Voice ev = tExtra[k][ni - 1];
                            if (ev != null && ev.active) { ev.speedTgt = Math.pow(2.0, (notes[ni] + transpose) / 12.0); ev.glide = 0.0015f; }
                        }
                    }
                }
                break;
            default: break;
        }
    }

    private void up(int id) {
        int k = find(id);
        if (k < 0) return;
        if (physDown > 0) physDown--;
        Voice v = tVoice[k];
        Voice[] ex = tExtra[k].clone();
        if (mode == KEYBOARD) for (Voice e2 : ex) if (e2 != null && e2.active && e2.touchId == id) { if (latch) e2.latched = true; else e2.release(); }
        if (mode == ARP && latch) { if (physDown == 0) arpLatched = true; return; }       // keep the arp pattern running
        remove(k);
        if (mode == LOOPER) { updateLooper(0, sample); return; }
        if (v == null || !v.active || v.touchId != id) return;
        if (latch && mode != LOOPPLAYER) { v.latched = true; return; }                  // latch: the note keeps sounding
        boolean rel = v.kind != Voice.PLAY || mode == KEYBOARD || v.loop && mode != LOOPPLAYER || gate && mode != LOOPPLAYER;
        if (mode == LOOPPLAYER) rel = gate;
        if (rel) v.release(); else v.held = false;
    }

    private void remove(int k) {
        for (int i = k; i < tCount - 1; i++) {
            tIds[i] = tIds[i + 1]; tX[i] = tX[i + 1]; tY[i] = tY[i + 1]; tVoice[i] = tVoice[i + 1]; tExtra[i] = tExtra[i + 1];
        }
        tCount--;
        tVoice[tCount] = null; tExtra[tCount] = new Voice[4];
    }

    /**
     * Looper: fingers work in pairs (1+2, 3+4, 5+6, 7+8): each pair sets its own loop region, so up to four loops
     * play together. Crossing a pair (second finger left of the first) plays that loop in reverse. A lone last
     * finger makes a short loop. With a quantize value (4/8/16/32) the markers snap to that grid, 0 = free.
     */
    private void updateLooper(long frame, Sample s) {
        if (s == null) return;
        int len = s.length();
        int loops = (tCount + 1) / 2;
        if (loops > looperVs.length) loops = looperVs.length;
        if (tCount == 0) {
            java.util.Arrays.fill(pairFull, false); java.util.Arrays.fill(pairDone, false);
            for (int k = 0; k < looperVs.length; k++) {
                Voice lv = looperVs[k];
                if (lv != null && lv.active && lv.kind == Voice.PLAY && lv.touchId == -3) {
                    if (latch) keepLoop(lv); else lv.release();
                }
                looperVs[k] = null;
            }
            return;
        }
        int q = div;
        for (int k = 0; k < looperVs.length; k++) {
            Voice lv = looperVs[k];
            if (k >= loops) {      // finger of this pair was lifted: its loop ends
                if (lv != null && lv.active && lv.touchId == -3 && !lv.releasing) { if (latch) keepLoop(lv); else lv.release(); }
                looperVs[k] = null;
                continue;
            }
            int f0 = 2 * k, f1 = 2 * k + 1;
            if (tCount <= f0) { pairFull[k] = false; pairDone[k] = false; }
            if (pairDone[k]) continue;                       // one finger of this pair already lifted: the loop is finished, ignore the other one
            if (f1 >= tCount && pairFull[k]) {
                pairDone[k] = true; pairFull[k] = false;
                if (lv != null && lv.active && lv.touchId == -3 && !lv.releasing) { if (latch) keepLoop(lv); else lv.release(); }
                looperVs[k] = null;
                continue;
            }
            if (f1 < tCount) pairFull[k] = true;
            double a, b;
            boolean reverse = false;
            if (f1 < tCount) {
                a = Math.min(tX[f0], tX[f1]);
                b = Math.max(tX[f0], tX[f1]);
                reverse = tX[f1] < tX[f0];
            } else {
                a = tX[f0];
                b = a + (q > 0 ? 1.0 / q : 1.0 / 32.0);
            }
            if (q > 0) {
                double g = q * Math.max(1f, viewZoom);          // zoomed in: the grid gets finer, so the finger distance is respected
                a = Math.round(a * g) / g;
                b = Math.round(b * g) / g;
                if (b - a < 0.5 / g) b = a + 1.0 / g;
            }
            if (b > 1.0) { double w = b - a; b = 1.0; a = Math.max(0.0, b - w); }
            double st = a * len, en = b * len;
            if (en - st < 64) { en = Math.min(len, st + 64); st = Math.max(0, en - 64); }
            double sp = reverse ? -pitchRatio() : pitchRatio();
            if (!(lv != null && lv.active && lv.touchId == -3 && !lv.releasing)) {
                lv = prepare(Voice.PLAY, frame);
                lv.loop = true; lv.vel = loops > 1 ? 0.75f : 0.9f;
                lv.start = st; lv.end = en; lv.speed = sp; lv.speedTgt = sp;
                lv.pingPong = pingPong;
                lv.pos = reverse ? en - 1 : st;
                lv.trigger(-3, frame);
                looperVs[k] = lv;
            } else {
                lv.pingPong = pingPong;
                double sg = sp;
                if (pingPong) sg = Math.copySign(Math.abs(sp), lv.speedTgt != 0 ? lv.speedTgt : sp);
                lv.speedTgt = sg; lv.glide = pingPong ? 0f : 0.02f;
                if (pingPong) lv.speed = sg;
                lv.setRegion(st, en);
            }
            tVoice[f0] = lv;
            if (f1 < tCount) tVoice[f1] = lv;
        }
    }

    // ---------------------------------------------------------------- arpeggiator step

    /**
     * One arpeggiator step. The slices under the held fingers form the pattern; direction decides the
     * order, the rate decides the speed (locked to the project beat grid). Each step plays the start of the
     * slice for one step's length (or the whole slice when the infinity button is on).
     */
    private void arpStep(long frame, double stepFrames) {
        Sample s = sample;
        if (s == null || tCount == 0) return;
        int len = s.length();
        // distinct slices under the fingers, in touch order
        int n = 0;
        for (int k = 0; k < tCount; k++) {
            int sl = sliceIndex(tX[k]);
            boolean dup = false;
            for (int q = 0; q < n; q++) if (arpOrd[q] == sl) { dup = true; break; }
            if (!dup) { arpOrd[n] = sl; arpVel[n] = 0.25f + 0.75f * (1f - tY[k]); n++; }
        }
        if (n == 0) return;
        int[] sorted = arpTmp;
        System.arraycopy(arpOrd, 0, sorted, 0, n);
        // keep velocities attached: sort indices by slice number
        float[] vel = new float[n];
        for (int a = 0; a < n; a++) vel[a] = arpVel[a];
        if (arpDir != 4) {
            for (int a = 1; a < n; a++) {                       // insertion sort, n <= 16
                int key = sorted[a]; float kv = vel[a]; int b = a - 1;
                while (b >= 0 && sorted[b] > key) { sorted[b + 1] = sorted[b]; vel[b + 1] = vel[b]; b--; }
                sorted[b + 1] = key; vel[b + 1] = kv;
            }
        }
        int pick;
        int dir = arpRandom ? 3 : arpDir;
        switch (dir) {
            case 1: pick = n - 1 - (arpCounter % n); break;
            case 2: {
                int period = Math.max(1, 2 * n - 2);
                int j = arpCounter % period;
                pick = j < n ? j : period - j;
                break;
            }
            case 3:
                pick = (int) (Math.random() * n);
                if (n > 1 && sorted[pick] == arpLast) pick = (pick + 1) % n;     // no immediate repeats
                break;
            default: pick = arpCounter % n; break;
        }
        arpCounter++;
        int slice = sorted[pick];
        arpLast = slice;
        sliceBounds(slice, bounds);
        Voice v = prepare(Voice.PLAY, frame);
        v.start = bounds[0] * len;
        double sliceEnd = bounds[1] * len;
        double play = infinite ? (sliceEnd - v.start) : stepFrames * v.ratio * pitchRatio() * 0.98;
        v.end = Math.min(sliceEnd, v.start + play);
        if (v.end - v.start < 64) v.end = Math.min(len, v.start + 64);
        v.pos = v.start;
        v.vel = vel[pick];
        v.setEnv(attack, decay, sustain, infinite ? release : Math.min(release, (float) (stepFrames / rate * 0.9)));
        v.trigger(-4, frame);
        arpSlice = slice;
        arpFlash = 1f;
    }

    private int autoWalk;
    private int pickAuto(int n) {
        if (n <= 1) return 0;
        int c = autoCounter;
        if (!shuffle) return c % n;
        switch (shuffleMode) {
            case 1: return (int) (Math.random() * n);
            case 2: { int per = 2 * n - 2; int k = c % per; return k < n ? k : per - k; }
            case 3: return n - 1 - (c % n);
            case 4: { int d = (int) (Math.random() * 4) - 2; if (d == 0) d = 1; autoWalk = Math.floorMod(autoWalk + d, n); return autoWalk; }
            case 5: { int ev = (n + 1) / 2; int k = c % n; return k < ev ? k * 2 : (k - ev) * 2 + 1; }
            case 6: { int mid = n / 2, k = c % n; int off = (k + 1) / 2; return Math.max(0, Math.min(n - 1, (k & 1) == 1 ? mid + off : mid - off)); }
            default: {
                int idx = (int) (Math.random() * n);
                if (idx == autoLast) idx = (idx + 1 + (int) (Math.random() * (n - 1))) % n;
                return idx;
            }
        }
    }

    /** Slicer auto-play: triggers the next slice (the previous auto note fades out with the release time). */
    private void autoStep(long frame) {
        Sample sm = sample;
        if (sm == null) return;
        int n = sliceTotal();
        int idx = pickAuto(n);
        autoCounter++;
        autoLast = idx;
        final boolean st = stepMode && idx < STEPS;
        if (st) stepPlaying = idx;
        if (autoSkip > 0f && Math.random() < autoSkip) return;
        if (st && (!stepOn[idx] || (stepChance[idx] < 0.999f && Math.random() > stepChance[idx]))) { releaseAuto(); return; }
        releaseAuto();
        int len = sm.length();
        sliceBounds(idx, bounds);
        Voice v = prepare(Voice.PLAY, frame);
        v.start = bounds[0] * len;
        v.end = bounds[1] * len;
        v.pos = v.start;
        v.vel = 0.9f;
        if (st) {
            v.speed *= Math.pow(2.0, stepPitch[idx] / 12.0);
            v.fCut = stepFilter[idx];
            float at = stepAtk[idx] * stepAtk[idx] * 0.5f;                         // 0..0.5 s
            double stepSec = 240.0 / Math.max(1, arpRate) / Math.max(30.0, curBpm);
            float dc = stepDec[idx];                                               // 1 = the whole slice, small = short plucks
            if (dc < 0.999f) {
                double sliceSec = (v.end - v.start) / (v.ratio * rate);
                double maxLen = Math.min(sliceSec, stepSec * 1.2);
                double playSec = Math.max(0.02, maxLen * dc * dc);
                v.end = Math.min(v.end, v.start + playSec * rate * v.ratio * Math.abs(v.speed));
                if (v.end - v.start < 64) v.end = Math.min(len, v.start + 64);
            }
            v.setEnv(Math.max(attack, at), decay, sustain, release);
        }
        v.trigger(-5, frame);
        arpSlice = idx;
        arpFlash = 1f;
    }
    private volatile double curBpm = 120.0;

    // ---------------------------------------------------------------- audio

    /** Adds this slot's stereo output into outL/outR (after its own effects). n <= MAX_BLOCK. */
    public void render(float[] outL, float[] outR, int n, long frame, double bpm, boolean playing) {
        render(outL, outR, n, frame, bpm, playing, frame * bpm / (60.0 * rate));
    }

    /** beat = position on the project's beat grid at the start of the block (arp steps lock to it). */
    public void render(float[] outL, float[] outR, int n, long frame, double bpm, boolean playing, double beat) {
        curBpm = bpm;
        Sample s = sample;
        java.util.Arrays.fill(mono, 0, n, 0f);
        java.util.Arrays.fill(bl, 0, n, 0f);
        java.util.Arrays.fill(br, 0, n, 0f);
        // play mode changed: the finger table belongs to the old mode. With latch the sound keeps going.
        int m = mode;
        if (m != lastMode) {
            if (lastMode >= 0) {
                for (int i = 0; i < tCount; i++) {
                    Voice tv = tVoice[i];
                    if (tv != null && tv.active) { if (latch) tv.latched = true; else tv.release(); }
                }
                releaseLoopers();
                tCount = 0; physDown = 0; arpLatched = false; nextStepBeat = -1; pN = 0;
                if (!latch && autoPlay) { autoPlay = false; releaseAuto(); }
            }
            lastMode = m;
        }
        if (s != null) {
            int off = 0;
            final double framesPerBeat = rate * 60.0 / bpm;
            final double stepBeats = 4.0 / Math.max(1, arpRate);
            while (off < n) {
                int chunk = n - off;
                final double cur = beat + off / framesPerBeat;
                curBeat = cur;
                // quantized triggers (Slicer / Keyboard)
                if (pN > 0) {
                    double next = Double.MAX_VALUE;
                    for (int i = 0; i < pN; i++) next = Math.min(next, pBeat[i]);
                    double until = (next - cur) * framesPerBeat;
                    if (until <= 0.5) { firePending(cur + 0.5 / framesPerBeat, frame + off, s); continue; }
                    chunk = Math.min(chunk, (int) Math.ceil(until));
                }
                // sample-accurate arp steps on the beat grid
                if (mode == ARP && tCount > 0) {
                    if (nextStepBeat < 0 || nextStepBeat < cur - stepBeats * 2) nextStepBeat = Math.ceil(cur / stepBeats - 1e-9) * stepBeats;
                    if (arpImmediate) {
                        arpImmediate = false;
                        double untilNext = (nextStepBeat - cur) * framesPerBeat;
                        if (untilNext > 0.2 * stepBeats * framesPerBeat) {        // first note now, the rest on the grid
                            arpStep(frame + off, stepBeats * framesPerBeat);
                            continue;
                        }
                    }
                    double until = (nextStepBeat - cur) * framesPerBeat;
                    if (until <= 0.5) {
                        arpStep(frame + off, stepBeats * framesPerBeat);
                        nextStepBeat += stepBeats;
                        continue;
                    }
                    chunk = Math.min(chunk, (int) Math.ceil(until));
                } else {
                    nextStepBeat = -1;
                }
                // slicer auto-play: every grid step triggers the next slice (left to right, or shuffled)
                if (autoPlay) {
                    if (nextAutoBeat < 0 || nextAutoBeat < cur - stepBeats * 2) {
                        nextAutoBeat = Math.ceil(cur / stepBeats - 1e-9) * stepBeats; autoCounter = 0; autoLast = -1;
                    }
                    double until = (nextAutoBeat - cur) * framesPerBeat;
                    if (until <= 0.5) {
                        autoStep(frame + off);
                        nextAutoBeat += stepBeats;
                        continue;
                    }
                    chunk = Math.min(chunk, (int) Math.ceil(until));
                } else if (nextAutoBeat >= 0) {
                    nextAutoBeat = -1;
                    releaseAuto();
                }
                renderVoices(off, chunk, bpm, playing);
                off += chunk;
            }
            curBeat = beat + n / framesPerBeat;
        }
        arpFlash *= 0.92f;
        snapshotLoops();
        {
            int cnt = Math.min(tCount, uiId.length);
            for (int i = 0; i < cnt; i++) { uiId[i] = tIds[i]; uiX[i] = tX[i]; uiY[i] = tY[i]; }
            uiN = cnt;
        }
        float p = pan;
        float gl = (float) Math.cos(p * Math.PI * 0.5) * 1.414f * 0.7071f;
        float gr = (float) Math.sin(p * Math.PI * 0.5) * 1.414f * 0.7071f;
        float v = muted ? 0f : volume;
        float peak = 0f;
        final float tgtL = v * gl, tgtR = v * gr;
        final float dL = (tgtL - curGL) / n, dR = (tgtR - curGR) / n;   // ramp per block: no zipper noise on sliders
        for (int i = 0; i < n; i++) {
            curGL += dL; curGR += dR;
            bl[i] = mono[i] * curGL;
            br[i] = mono[i] * curGR;
            float a = Math.abs(mono[i]) * v;
            if (a > peak) peak = a;
        }
        for (int e : Fx.ORDER) fx[e].process(bl, br, n, bpm);
        for (int i = 0; i < n; i++) { outL[i] += bl[i]; outR[i] += br[i]; }
        level = Math.max(peak, level * 0.9f);
        int act = 0;
        for (int i = 0; i < VOICES; i++) {
            if (voices[i].active) { act++; playheads[i] = voices[i].sm == null ? 0f : (float) (voices[i].pos / Math.max(1, voices[i].sm.length())); }
            else playheads[i] = -1f;
        }
        activeVoices = act;
    }

    private final float[] chunkBuf = new float[MAX_BLOCK];

    private void renderVoices(int off, int n, double bpm, boolean playing) {
        java.util.Arrays.fill(chunkBuf, 0, n, 0f);
        Sample s = sample;
        for (Voice v : voices) {
            if (!v.active) continue;
            if (v.kind == Voice.BOW) v.grainTgt = bowGrain();
            float bb = bend + fine;
            v.bendTgt = bb == 0f ? 1.0 : Math.pow(2.0, bb / 12.0);
            if (v.kind == Voice.BOW) v.bendTgt *= pitchRatio();      // Bow: transposition is live too
            if (v.touchId != -4) v.setEnv(attack, decay, sustain, release);     // ADSR sliders act on held notes live
            if (v.touchId == -2 && s != null) {
                if (!playing) { v.release(); continue; }
                double dur = s.length() / (double) s.sampleRate;
                if (v.kind == Voice.STRETCH) { v.speed = bpm * dur / (60.0 * sampleBeats); v.pitch = pitchRatio(); }   // tempo lock, pitch untouched
                else v.speed = bpm * dur / (60.0 * sampleBeats) * pitchRatio();   // lock loop to project tempo
            }
            if (v.kind == Voice.PLAY && mode == KEYBOARD && legato) { /* speed set in move() */ }
            v.render(chunkBuf, n);
        }
        for (int i = 0; i < n; i++) mono[off + i] += chunkBuf[i];
    }

    static float clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
}
