package com.gfdrps.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;

import com.gfdrps.core.Engine;
import com.gfdrps.core.Fx;

/**
 * Kaoss-style XY pad for the selected effect of the selected slot (or the master bus).
 * Touching switches the effect on; letting go switches it off unless it is latched.
 */
public final class XYPadView extends View {
    private final Engine engine;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private int slot, fxIndex;
    private boolean master, latch, touching;
    private float tx = 0.5f, ty = 0.5f;
    private int downFx, downSlot;

    public XYPadView(Context c, Engine e) {
        super(c);
        engine = e;
        setBackgroundColor(Theme.WAVE_BG);
    }

    public void select(int slot, int fx, boolean master) {
        this.slot = slot; this.fxIndex = fx; this.master = master;
        Fx.Effect ef = effect();
        tx = ef.x; ty = ef.y;
        invalidate();
    }

    public void setLatch(boolean l) {
        latch = l;
        engine.fxHold = l;
        if (!l && !touching) effect().active = false;
        invalidate();
    }

    public boolean isLatch() { return latch; }

    private Fx.Effect effect() { return master ? engine.master[fxIndex] : engine.slots[slot].fx[fxIndex]; }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) getParent().requestDisallowInterceptTouchEvent(true);
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE) {
            if (a == MotionEvent.ACTION_DOWN && android.os.Build.VERSION.SDK_INT >= 26) requestUnbufferedDispatch(e);
            tx = Math.max(0f, Math.min(1f, e.getX() / Math.max(1, getWidth())));
            ty = Math.max(0f, Math.min(1f, 1f - e.getY() / Math.max(1, getHeight())));
            // goes through the engine so the gesture recorder sees the pad too (id = fx index, +16 for master)
            engine.fxTouch(slot, a == MotionEvent.ACTION_DOWN ? 3 : 4, fxIndex + (master ? 16 : 0), tx, ty);
            touching = true; downFx = fxIndex + (master ? 16 : 0); downSlot = slot;
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            touching = false;
            engine.fxTouch(downSlot, 5, downFx, 0f, 0f);
        }
        invalidate();
        return true;
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        Fx.Effect ef = effect();
        int col = Theme.FX[fxIndex];
        boolean on = ef.active;
        // response hint curve
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(0x33FFFFFF);
        // grid: with a tempo-synced delay / amp mod the columns ARE the note divisions (the pad's x picks one of them)
        int[] cols = null; int hot = -1;
        if (fxIndex == Fx.DELAY && ((Fx.Delay) ef).sync) {
            Fx.Delay d = (Fx.Delay) ef;
            cols = Fx.Delay.DIV_RATES;
            hot = (d.follow && d.gridRate > 0) ? indexOf(cols, d.gridRate) : Fx.Delay.divIndex(ef.x);
        } else if (fxIndex == Fx.AMP && ((Fx.AmpMod) ef).sync) {
            cols = Fx.AmpMod.SYNC_RATES;
            hot = Fx.AmpMod.syncIndex(ef.x);
        }
        if (cols != null) {
            float cw = w / cols.length;
            p.setStyle(Paint.Style.FILL);
            p.setColor((col & 0x00FFFFFF) | 0x30000000);
            if (hot >= 0) c.drawRect(hot * cw, 0, (hot + 1) * cw, h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x44FFFFFF);
            for (int i = 1; i < cols.length; i++) c.drawLine(i * cw, 0, i * cw, h, p);
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(Math.min(cw * 0.34f, h * 0.06f));
            for (int i = 0; i < cols.length; i++) {
                p.setColor(i == hot ? 0xFFFFFFFF : 0x99FFFFFF);
                c.drawText(Fx.noteName(cols[i]), (i + 0.5f) * cw, h - h * 0.03f, p);
            }
            p.setTextAlign(Paint.Align.LEFT);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0x33FFFFFF);
            for (int i = 1; i < 4; i++) c.drawLine(0, i * h / 4, w, i * h / 4, p);
        } else for (int i = 1; i < 4; i++) {
            c.drawLine(i * w / 4, 0, i * w / 4, h, p);
            c.drawLine(0, i * h / 4, w, i * h / 4, p);
        }
        path.reset();
        if (fxIndex == Fx.AMP) {
            // the chosen waveform, one cycle per grid column (synced) or as many cycles as the rate would give
            Fx.AmpMod am = (Fx.AmpMod) ef;
            float depth = on ? (touching ? ty : ef.y) : 0.7f;
            int cycles = cols != null ? cols.length : 2 + Math.round((touching || on ? (touching ? tx : ef.x) : 0.5f) * 10f);
            int per = 40;
            for (int cy2 = 0; cy2 < cycles; cy2++) {
                for (int i = 0; i <= per; i++) {
                    float ph = i / (float) per;
                    float level = 1f - depth * (1f - Fx.AmpMod.shapeAt(am.shape, Math.min(0.9999, ph), cy2));
                    float px = (cy2 + ph) / cycles * w, py = h * 0.86f - level * h * 0.62f;
                    if (cy2 == 0 && i == 0) path.moveTo(px, py); else path.lineTo(px, py);
                }
            }
        } else for (int i = 0; i <= 64; i++) {
            float x = i / 64f;
            float y = curve(x, ef);
            float px = x * w, py = h - (0.1f + 0.8f * y) * h;
            if (i == 0) path.moveTo(px, py); else path.lineTo(px, py);
        }
        p.setStrokeWidth(3f);
        p.setColor(on ? col : 0x66FFFFFF);
        c.drawPath(path, p);
        // a replayed gesture (or MIDI) moves the effect without a finger: show where it is
        boolean follow = on && !touching;
        float cx = (follow ? ef.x : tx) * w, cy = (1f - (follow ? ef.y : ty)) * h;
        if (follow) { p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5f); p.setColor(0xFFFF4D5E); c.drawCircle(cx, cy, Math.min(w, h) * 0.1f, p); }
        if (on) {
            p.setStyle(Paint.Style.FILL);
            p.setColor((col & 0x00FFFFFF) | 0x33000000);
            c.drawCircle(cx, cy, Math.min(w, h) * 0.28f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(col);
            p.setStrokeWidth(2f);
            c.drawLine(cx, 0, cx, h, p);
            c.drawLine(0, cy, w, cy, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4f);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy, Math.min(w, h) * 0.07f, p);
        // label
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x99FFFFFF);
        p.setTextSize(Math.min(w, h) * 0.075f);
        String extra = fxIndex == Fx.FILTER ? (" · " + Fx.Filter.MODE_SHORT[((Fx.Filter) ef).mode]) : "";
        if (fxIndex == Fx.DELAY) {
            Fx.Delay d = (Fx.Delay) ef;
            int ms = Math.round(d.sync ? d.shownMs : (float) Fx.Delay.msForX(ef.x));
            extra = " · " + (d.sync ? Fx.Delay.DIV_NAMES[Fx.Delay.divIndex(ef.x)] + " SYNC · " : "") + (ms >= 1000 ? String.format(java.util.Locale.US, "%.2f s", ms / 1000f) : ms + " ms");
        }
        if (fxIndex == Fx.DELAY || fxIndex == Fx.REVERB) {
            Fx.Tone tn = fxIndex == Fx.DELAY ? ((Fx.Delay) ef).tone : ((Fx.Reverb) ef).tone;
            if (tn.mode != 0) extra += " · " + Fx.Tone.NAMES[tn.mode] + " " + fmtHz(tn.cutoffHz());
        }
        java.util.Locale us = java.util.Locale.US;
        if (fxIndex == Fx.ROLL) extra = " · " + Fx.noteName(Fx.Roll.RATES[Fx.Roll.rateIndex(ef.x)]) + (ef.y > 0.05f ? " · acelera " + Math.round(ef.y * 100) + "%" : "");
        else if (fxIndex == Fx.STUTTER) extra = " · passo " + Fx.noteName(Fx.Stutter.RATES[Math.min(Fx.Stutter.RATES.length - 1, (int) (ef.x * Fx.Stutter.RATES.length))]) + " · " + (2 + Math.round(ef.y * 14f)) + "x";
        else if (fxIndex == Fx.RING) extra = " · " + Fx.RingMod.SHAPES[((Fx.RingMod) ef).shape] + " " + fmtHz(((Fx.RingMod) ef).freqHz()) + " Hz · " + Math.round(ef.y * 100) + "%";
        else if (fxIndex == Fx.CRUSH) extra = String.format(us, " · 1/%.0f taxa · %.1f bits", ((Fx.Crush) ef).hold(), ((Fx.Crush) ef).bits());
        c.drawText((master ? "MASTER · " : "") + Fx.NAMES[fxIndex] + extra + (latch || ef.hold ? "  (hold)" : ""), w * 0.03f, h * 0.1f, p);
    }

    private static int indexOf(int[] a, int v) { for (int i = 0; i < a.length; i++) if (a[i] == v) return i; return -1; }

    static String fmtHz(double hz) { return hz >= 1000 ? String.format(java.util.Locale.US, "%.1fk", hz / 1000.0) : Math.round(hz) + ""; }

    /** A small sketch of what the effect does along x, just for orientation. */
    private float curve(float x, Fx.Effect ef) {
        switch (fxIndex) {
            case Fx.FILTER: {
                // true magnitude response of the 2nd-order state-variable filter, -40..+20 dB
                Fx.Filter f = (Fx.Filter) ef;
                double fc = f.cutoffHz(), k = f.damping();
                double fr = 40.0 * Math.pow(400.0, x);
                double r = fr / fc;
                double den = Math.sqrt((1 - r * r) * (1 - r * r) + k * k * r * r);
                double lp = 1.0 / Math.max(1e-6, den);
                double mag;
                switch (f.mode) {
                    case 1: mag = r * r * lp; break;                              // high-pass
                    case 2: mag = k * r * lp; break;                              // band-pass (unity at the cutoff)
                    case 3: mag = Math.abs(1 - r * r) * lp; break;                // notch
                    default: mag = lp;
                }
                double db = 20 * Math.log10(Math.max(1e-6, mag));
                return (float) Math.max(0.0, Math.min(1.0, (db + 40.0) / 60.0));
            }
            case Fx.DIST: return (float) Math.tanh((x * 6f) - 2f) * 0.5f + 0.5f;
            case Fx.CRUSH: { float st = 1f + tx * tx * 12f; return (float) (Math.floor(x * st) / st); }          // staircase
            case Fx.RING: return 0.5f + 0.4f * (float) Math.sin(x * (4f + tx * 30f) * Math.PI) * (0.3f + 0.7f * ty);
            case Fx.ROLL: case Fx.STUTTER: return ((int) (x * (3f + tx * 10f)) & 1) == 0 ? 0.85f : 0.2f;
            case Fx.AMP: return 0.5f + 0.4f * (float) Math.sin(x * (3f + tx * 20f) * Math.PI) * ty;
            case Fx.DELAY: return (float) Math.pow(0.5f + 0.4f * ty, x * 6f);   // echoes fading with time
            default: return (float) Math.exp(-x * (5f - tx * 4f)) * (0.3f + 0.7f * ty);
        }
    }
}
