# Changelog

## 2.1 (build 12)
- **Step mode na própria fatia**: botão STEP (modo Slicer). Cada fatia é um passo; escolha o parâmetro na linha que aparece (Liga, Pitch, Filtro, Attack, Decay, **Chance**) e toque ou arraste direto nas fatias: a altura define o valor, arrastar pinta várias fatias, e o valor aparece desenhado em barras sobre a waveform. Substitui o menu de passos antigo. Salvo no projeto.
- **Menus de efeito flutuantes**: não bloqueiam mais o app (dá para tocar a waveform e o pad com o menu aberto), podem ser arrastados pelo título e **minimizados**, e têm um pino de **hold** em cada menu (liga o efeito e o mantém ligado, mesmo sem tocar o pad).
- **Novos efeitos**: **Roll** (congela o último trecho e repete como roll de DJ, com roll-up), **Stutter** (re-captura a cada passo da grade e repete), **Ring Mod** (4 formas de portadora, modo notas) e **Crush** (bit + sample rate, dither). Ficam numa segunda coluna ao lado dos efeitos originais e valem também para o master.
- **Delay Reverse**: os ecos tocam de trás para frente.
- **Filtro multimodo**: LPF, HPF, BPF e Notch no efeito Filtro e no filtro do Delay e do Reverb. O pad desenha a resposta de cada modo.

## 2.0 (build 11)
- **Turing Machine** (menu ⋮ › Turing Machine · modulação): duas máquinas com registrador de 16 bits, tamanho 2–16, knob de probabilidade (1 = loop travado, 0,5 = aleatório, 0 = travado e invertido), clock sincronizado ao BPM ou livre (Hz), swing, slew, gate, saída uni/bipolar, quantização em 16 escalas, edição bit a bit, write, 3 CVs e 6 pulsos (lógica entre bits). **Matriz de modulação** com 315 parâmetros mapeáveis (volume, pan, pitch, ADSR, grão, X/Y de todos os efeitos de cada track e do master, delay pitch/difusão, chorus do reverb, tempo, compressor, limiter…) até 16 rotas com profundidade ±100 %. O valor que você ajusta vira a base da modulação. Tudo salvo no projeto.
- **Delay**: difusão agora vai até "cloud": 8 all-pass + tanque de combs cruzados, os ecos viram uma nuvem de reverb.
- **Reverb**: **chorus** e **modulação de pitch** (vibrato de até ±50 cents) com velocidade ajustável, aplicados só ao som do reverb.
- **Keyboard**: **escalas** (16, as teclas viram graus da escala, tônicas destacadas) e **acordes** (13 tipos + diatônico em tríade/7ª); um dedo toca o acorde inteiro. Ao editar o início do sample as teclas continuam escondidas.
- **Slicer**: **step mode** com 16 passos, cada um com fatia, pitch, filtro, attack e decay; menu do **shuffle** (segure) com 7 ordens (aleatório, livre, vai e volta, direita→esquerda, caminhada, pares/ímpares, espelhado) e chance de pausa.
- **Amp mod**: forma **aleatória suave** e o pad mostra a forma de onda escolhida em cada coluna da grade (sync) ou nos ciclos da taxa.
- **Compressor e limiter**: 9 presets de uso real (cola de mix, bateria, voz, baixo, punch paralelo, master loudness, brickwall…).
- **Interface**: o ícone dos faders agora fica dentro do botão do fader (não mais acima dele); **duplo toque em qualquer slider volta ao valor inicial**.
- **Gestos**: deslize sobre o número de compassos para escolher; novo modo **LIVRE** (grava até apertar ● de novo e o loop tem exatamente o tamanho tocado).
- **Scratch**: filtro anti-aliasing quando o dedo passa mais rápido que a velocidade normal (era a fonte do chiado nos arrastos rápidos).

## 1.9 (build 10)
- **Delay (todos os tipos)**: novos sliders **Pitch** (-12 a +12 semitons; fica dentro da realimentação, então cada repetição sobe/desce mais um passo) e **Difusão** (0–100 %: all-pass em série que espalha os ecos, de nítido a nuvem). Valem também para o Multitap. Salvos no projeto.
- **Filtro com envelope**: o cutoff segue o volume da própria forma de onda (envelope follower). Quantidade bipolar (abre ou fecha no sinal forte), sensibilidade, ataque e release.
- **Compressor e limiter**: agora **iniciam ativos**. Controles completos: threshold, ratio, attack, release, makeup (compressor) e teto + release (limiter), além do macro de antes. Botão **Salvar como padrão** (vale para toda abertura do app) e **Restaurar original**. Projetos antigos continuam carregando.
- **Bow**: o pitch não funcionava de fato (bug): transposição, pitch bend e ajuste fino não eram aplicados à leitura dos grãos. Corrigido, agora respondem ao vivo.
- **Keyboard**: ao ligar o botão de fatia/edição, as teclas somem e a waveform fica livre para marcar o ponto inicial com precisão.
- **Reverse**: corrigido o click. O ataque forte do sample original vira o final do reverso e era cortado de forma seca (fade de apenas ~2 ms); o fade final agora é de pelo menos 8 ms, a rede de segurança foi alongada e inverter com notas tocando faz fade em vez de corte.

## 1.8 (build 9)
- **Reverb com 4 tipos** (duplo toque no efeito): Cloud (o de antes), **Hall** (grande espaço: pré-delay longo, cauda de até ~14 s e mais escura), **Plate** (placa: densa, brilhante, ataque rápido) e **Spring** (mola de amplificador: cadeia de all-pass dispersivos em loop de realimentação com leve não linearidade, o "splash/boing").
- **Delay com 4 tipos**: **Digital** (repetições fiéis), **Analógico** (cada repetição perde brilho, com leve oscilação estilo bucket-brigade), **Fita** (saturação, banda limitada, wow e flutter) e **Multitap** (4 taps em 1/4, 1/2, 3/4 e 1 do tempo, cada um com nível e posição no estéreo). Todos continuam com sync, grade do slot e filtro LP/HP.
- Os tipos aparecem como tiles com ícones e uma descrição curta; ficam salvos no projeto.

## 1.7 (build 8)
- **Latch no Looper**: os loops criados continuam depois de soltar os dedos; novos pares de dedos somam mais loops (até 8). Com o latch ligado cada loop mostra uma **haste com bolinha em cada ponta** para ajustar início e fim arrastando. Se um dedo do par sai antes do outro, o loop fica como estava (não encolhe).
- **Fatiar por números**: depois do auto-fatiar (ou de marcadores manuais) os botões 4/6/8/12/… voltam a funcionar (recolocam a grade uniforme; undo desfaz).
- **Pad XY do Delay e do Amp mod**: com sync ligado a grade do pad tem uma coluna para cada divisão de tempo, com o nome da nota (1/64 … 1 compasso, tercinas); a coluna ativa fica destacada (com "seguir a grade", a do slot).
- **Menus no visual do app**: opções dos efeitos (duplo toque), compressor/limiter, pitch, importar trecho e gestos/presets agora usam painéis escuros com tiles de ícones e sliders (novos ícones: formas de onda, compressor, limiter, salvar, carregar, lixeira, relógio, link, grade…).

## 1.6 (build 7)
- **Slicer + legato**: deslizar o dedo entre fatias faz glissando (a nota continua e sobe/desce um semitom por fatia) em vez de retocar.
- **Delay**: a grade de sync usa a mesma divisão de tempo do resto do app (1/64 a 1 compasso, com tercinas) e há a opção "seguir a grade do slot" (taxa do Arp / Q).
- **Amp mod = gate** com 7 formas de onda (seno, gate, serra, rampa, triângulo, trance, aleatório) e taxa livre ou sincronizada ao BPM.
- **Duplo toque em cada efeito** abre um submenu com as opções dele (tipo do filtro, forma do amp mod, sync/grade/filtro do delay, filtro do reverb, centralizar pad).
- **Master**: compressor e limiter (menu Gf → "Master: compressor e limiter"); salvos no projeto.
- **Gestos**: apertar ● de novo não perde mais o gesto (finaliza e mantém); ● com o gesto tocando faz **overdub** (soma uma camada; undo remove); menu (segure ●): **presets de gesto** (salvar / carregar em qualquer track / apagar).
- **Importar áudio**: escolha o início e o tamanho do trecho (segundos ou min:seg); só o trecho é decodificado.
- **Loop Player**: o dedo é a agulha — tocar ou arrastar leva o playhead para aquele ponto.
- **Sliders** com ícones (volume, attack, decay, sustain, release, pan, grão).
- **Zoom**: deslizar o dedo para cima/baixo no botão move a faixa horizontalmente.
- **Latência**: buffer de áudio começa com apenas 1 burst e cresce sozinho se houver underrun (verificação mais rápida).
- **Looper**: a grade (4/8/16/32) agora é relativa ao trecho visível — com zoom em faixas longas a distância entre os dedos é respeitada.
- **Arp**: o botão de marcador volta a aparecer e edita as fatias; a taxa passou a ser o botão amarelo (Q).
- **Transposição**: deslizar no valor = pitch bend (direita sobe, esquerda desce, volta ao soltar); segurar 2 s abre o campo para digitar o pitch (aceita decimais).
- **Layout**: botões que não valem para o modo atual desaparecem (em vez de ficarem esmaecidos).

## 1.5 (build 6)
- **Gestos reproduzidos aparecem na tela**: os dedos gravados viram anéis vermelhos (com linha vertical) na waveform e a posição do efeito gravado é mostrada no pad XY com um anel vermelho.
- **Slicer**: a fatia tocada brilha em branco, como no Arpeggiator (também quando vem de auto-play ou de toque quantizado).
- **Bow**: o slider de tamanho do grão agora é fluido (o tamanho desliza em tempo real, inclusive com a nota segurada, e a altura do dedo / volume não dá mais degraus).
- **Looper**: corrigido — cada par de dedos faz um loop próprio (1+2, 3+4, 5+6, 7+8): até 4 loops ao mesmo tempo, cada um com seu reverse, e soltar um par só encerra aquele loop. A tela pinta uma região para cada par.
- **Refazer (redo)** ao lado do desfazer; uma edição nova limpa a pilha de refazer.
- **Deslizar nos botões**: o zoom aumenta/diminui continuamente ao deslizar sobre o botão; a taxa do Arp, a grade do Q e as fatias (0 4 6 8 12 16 24 32 48 64) mudam ao deslizar na horizontal.
- **Mais subdivisões**: taxa/grade 1/1, 1/2, 1/4, 1/8, 1/16, 1/32, 1/64 e tercinas (1/2T, 1/4T, 1/8T, 1/16T, 1/32T).
- **LP/HP no Delay e no Reverb**: botão LP/HP (toque = desligado → passa-baixas → passa-altas; deslize = frequência de corte, 40 Hz–18 kHz). No Delay o filtro age também na realimentação (repetições mais escuras ou mais finas). Salvo no projeto.
- **Mais tracks**: botão "+" no rodapé adiciona tracks (até 12); a barra de tracks rola. O projeto salva o número de tracks.
- **Tela de gravação**: ao gravar (microfone ou mix) aparece uma tela com a waveform sendo gravada, medidor de nível, tempo e botões SALVAR / CANCELAR. Para o resample do mix a barra fica só sobre o rodapé, então dá para continuar tocando.
- **Ajuda**: a legenda agora ajusta colunas e tamanho do texto para caber, então todo número da tela tem sua explicação.

## 1.4 (build 5)
- **Looper**: botão P-P liga o ping-pong (o loop vai e volta entre os dedos, sem saltos).
- **Bow**: altura do dedo = volume; slider azul novo = tamanho do grão (de granular a pad); no máximo 4 notas.
- **Tape / Scratch**: com 4/8/16/32 selecionado a velocidade (Tape) e a posição (Scratch) andam em degraus.
- **Keyboard**: botão de marcador edita início e fim do sample; segure para voltar ao sample inteiro.
- **Zoom da waveform** (botão 1x–16x, segure para voltar; a barra no topo rola) para Slicer, Looper, Bow, Arp e edição de região.
- **Cortar (trim)**: menu do slot → "Cortar o sample para início/fim"; os marcadores são reescalados.
- **Loop Player STR**: time-stretch (WSOLA) — o BPM muda o tempo sem mudar a altura, e a transposição muda a altura sem mudar o tempo.
- **Desfazer** (botão undo): sample, reverse, trim, fatias, região e gestos (até 8 passos por slot, com limite de memória).
- **Exportar**: menu Gf → gravar o que está tocando em WAV estéreo (Music/GfDrps); menu do slot → exportar o sample em WAV.
- **Projeto**: agora salva as posições dos efeitos (XY, sync do delay, LP/HP), hold e as novas opções.
- **MIDI clock de entrada**: menu Gf → "Clock MIDI externo": o BPM segue o clock e start/stop controlam o transporte.
- **Gestos**: segure o ● para quantizar (1/16, 1/8, 1/4), deslocar, ou apagar só o pad de efeito / só os toques da waveform.
- **Ajuda**: o "?" mostra um overlay com cada controle numerado sobre a própria tela (segure o "?" para o texto completo).
- Botões que não valem para o modo atual ficam esmaecidos (grade, legato, editar, ação do modo).

## 1.3 (build 4)
- **Estabilidade**: corrigido o fechamento ao mudar o número de fatias no modo Arp (índice fora do limite ao desenhar) e uma exceção no Looper ao soltar os dedos depois do Stop; a thread de áudio não derruba mais o app (silêncio no bloco com erro); importação de arquivos grandes por streaming (codec), limite de 4 min, `largeHeap` e aviso se faltar memória.
- **Latência**: buffer de áudio do menor tamanho estável (2 bursts) que cresce sozinho se houver underrun; toques sem agrupamento (`requestUnbufferedDispatch`) na waveform e no pad.
- **Scratch**: interpolação cúbica, o alvo do dedo continua se movendo entre os eventos de toque (sem degraus de 60 Hz), mola mais suave e gate de volume mais rápido para abrir e mais lento para fechar. Sem estalos nem modulação de 60 Hz (testado).
- **Latch** (botão verde): o som continua ao soltar o dedo e ao trocar de modo; um novo gesto ou desligar o latch solta. Vale também para o padrão do Arp, o Looper e o auto-play.
- **Slicer**: botão ▶ (auto-play das fatias da esquerda para a direita na grade do BPM), 🎲 shuffle, **Q** quantiza os toques na grade (segure o Q para 1/4–1/32). O Q também vale no Keyboard.
- **Loop Player**: o primeiro toque já liga o loop (e o transporte), sem precisar apertar play.
- **Delay**: 10 ms a 4000 ms, em milissegundos inteiros (1 em 1 ms nas faixas curtas) — perto de 10 ms vira filtro pente/eco metálico; acima de ~150 ms o feedback é ping-pong. Botão **sync** trava o tempo no BPM (1/32 a 1 compasso, retas e pontuadas). O pad mostra o tempo em ms ou a nota.
- **BPM**: arrastar na horizontal (direita = mais rápido), o topo da tela é a borda.
- **Gestos**: a gravação começa no primeiro toque (waveform ou pad de efeito), em qualquer modo; os movimentos do pad de efeito (inclusive master) são gravados e repetidos; os gestos são salvos e carregados com o projeto.

## 1.2 (build 3)
- **ADSR completo em todos os modos**: novos sliders Decay e Sustain; Attack/Decay/Sustain/Release valem para Slicer, Looper, Bow, Keyboard, Loop Player e Arpejador, e agem ao vivo em notas seguradas. Tape: o release controla o tempo da parada de fita.
- **Reverb "cloud"** reescrito (plate de Dattorro): cauda longa, densa e difusa, com modulação lenta nas linhas de atraso e amortecimento dos agudos — sem ressonâncias metálicas (testado por métricas de periodicidade e picos espectrais).
- **Arpejador refeito**: usa as fatias sob os dedos (grade 0/4/8/16/32 ou fatias manuais), direção (UP, DN, U-D, RND, ORD) no botão rosa, taxa 1/4–1/32 no botão amarelo, notas travadas na grade do BPM, fatia tocada acende na tela, usa o ADSR do slot.
- Filtro: um único módulo (toque de novo no ícone alterna LP/HP).
- Versão do app aparece no botão "Gf vX.Y" e em Gf → Sobre.
- Projetos salvam decay, sustain, direção e taxa do arpejador.

## 1.1
- Botão ■ realmente para tudo; filtro único LP/HP; fatias manuais e automáticas; reverse; reverb FDN; sem estalos.
