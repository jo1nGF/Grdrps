import com.gfdrps.core.*;

/** Regression tests for the issues found on the phone: reverb stuck on, filter HP, scratch noise, looper, clicks, slices. */
public class FixTest {
    static int fails = 0;
    static final int R = 48000;

    static void check(boolean ok, String msg) {
        System.out.println((ok ? "  ok   " : "  FAIL ") + msg);
        if (!ok) fails++;
    }

    static float rms(float[] a, int from, int to) {
        double s = 0;
        for (int i = from; i < to; i++) s += a[i] * a[i];
        return (float) Math.sqrt(s / Math.max(1, to - from));
    }

    static float[] sine(double hz, int n, float amp) {
        float[] d = new float[n];
        for (int i = 0; i < n; i++) d[i] = (float) (Math.sin(2 * Math.PI * hz * i / R) * amp);
        return d;
    }

    /** Pushes a mono signal through an effect in 256-frame blocks (stereo identical). */
    static float[] runFx(Fx.Effect fx, float[] in, double bpm) {
        float[] out = new float[in.length];
        float[] l = new float[256], r = new float[256];
        for (int o = 0; o < in.length; o += 256) {
            int n = Math.min(256, in.length - o);
            System.arraycopy(in, o, l, 0, n);
            System.arraycopy(in, o, r, 0, n);
            fx.process(l, r, n, bpm);
            System.arraycopy(l, 0, out, o, n);
        }
        return out;
    }

    static float maxDiff(float[] a, int from, int to) {
        float m = 0;
        for (int i = Math.max(1, from); i < to; i++) m = Math.max(m, Math.abs(a[i] - a[i - 1]));
        return m;
    }

    static float[] noise(int n, float amp, long seed) {
        java.util.Random r = new java.util.Random(seed);
        float[] d = new float[n];
        for (int i = 0; i < n; i++) d[i] = (r.nextFloat() * 2 - 1) * amp;
        return d;
    }

    /** Renders a slot for `seconds`, calling step(blockIndex) before every 256-frame block. Returns mono output. */
    interface Step { void at(int block); }
    static float[] renderSlot(Slot s, double seconds, double bpm, Step step) {
        int blocks = (int) (seconds * R / 256);
        float[] out = new float[blocks * 256];
        float[] l = new float[256], r = new float[256];
        for (int b = 0; b < blocks; b++) {
            if (step != null) step.at(b);
            java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0);
            s.render(l, r, 256, (long) b * 256, bpm, true);
            for (int i = 0; i < 256; i++) out[b * 256 + i] = (l[i] + r[i]) * 0.5f;
        }
        return out;
    }

    static Slot sineSlot(double hz, float amp) {
        Slot s = new Slot(R);
        s.setSample(new Sample(sine(hz, R * 4, amp), R, "sine"), 120);
        return s;
    }

    public static void main(String[] a) {
        System.out.println("== Reverb");
        {
            Fx.Effect rv = Fx.create(Fx.REVERB, R);
            float[] dry = noise(R, 0.3f, 1);
            float[] same = runFx(rv, dry, 120);
            boolean identical = true;
            for (int i = 0; i < dry.length; i++) if (same[i] != dry[i]) { identical = false; break; }
            check(identical, "reverb desligado deixa o sinal exatamente igual (bypass limpo)");

            // burst while active, then release
            rv = Fx.create(Fx.REVERB, R);
            rv.active = true; rv.setXY(0.6f, 1f);
            float[] in = new float[R * 6];
            float[] burst = noise(R / 2, 0.4f, 2);
            System.arraycopy(burst, 0, in, 0, burst.length);
            float[] out = new float[in.length];
            float[] l = new float[256], r = new float[256];
            for (int o = 0; o + 256 <= in.length; o += 256) {
                if (o >= R / 2) rv.active = false;      // finger lifted
                System.arraycopy(in, o, l, 0, 256); System.arraycopy(in, o, r, 0, 256);
                rv.process(l, r, 256, 120);
                System.arraycopy(l, 0, out, o, 256);
            }
            float wetNow = rms(out, R / 2 + 2000, R / 2 + 6000);
            float late = rms(out, R * 4, R * 6);
            System.out.println("   cauda logo após soltar: " + wetNow + " | 3.5-5.5 s depois: " + late);
            check(wetNow > 0.002f, "cauda audível logo após soltar o pad");
            check(late < 1e-5f, "reverb some por completo depois de soltar (sem reverb residual)");

            // decay control: long vs short
            float[] tails = new float[3];
            float[] xs = {0f, 0.5f, 1f};
            for (int k = 0; k < 3; k++) {
                Fx.Effect e = Fx.create(Fx.REVERB, R);
                e.active = true; e.setXY(xs[k], 1f);
                float[] inp = new float[R * 12];
                System.arraycopy(burst, 0, inp, 0, burst.length);
                float[] o2 = runFx(e, inp, 120);
                tails[k] = rms(o2, R * 2, R * 2 + R / 2);
                // measure RT60: time from burst end until level falls 60 dB below the level just after the burst
                float ref = rms(o2, R / 2, R / 2 + 2400);
                int t60 = -1;
                for (int w = R / 2; w + 2400 < o2.length; w += 2400) {
                    if (rms(o2, w, w + 2400) < ref * 0.001f) { t60 = w - R / 2; break; }
                }
                System.out.println("   decay x=" + xs[k] + ": nível em 2 s = " + tails[k] + ", RT60 medido ≈ " + (t60 < 0 ? ">11" : String.format("%.2f", t60 / (double) R)) + " s (pedido " + String.format("%.2f", 0.6 * Math.pow(24, xs[k])) + " s)");
            }
            check(tails[1] > tails[0] * 5 && tails[2] > tails[1] * 2, "controle de decay (x) faz diferença clara em toda a faixa");

            // stability + loudness at full settings
            Fx.Effect e = Fx.create(Fx.REVERB, R);
            e.active = true; e.setXY(1f, 1f);
            float[] big = noise(R * 10, 0.9f, 3);
            float[] ob = runFx(e, big, 120);
            float pk = 0; boolean fin = true;
            for (float v : ob) { pk = Math.max(pk, Math.abs(v)); if (Float.isNaN(v) || Float.isInfinite(v)) fin = false; }
            check(fin && pk < 6f, "estável com ruído forte, decay e wet no máximo (pico " + pk + ")");
            float wetRms = rms(ob, R * 6, R * 10), dryRms = rms(big, R * 6, R * 10);
            System.out.println("   nível wet+dry / dry em regime = " + wetRms / dryRms);
            check(wetRms / dryRms > 1.2f && wetRms / dryRms < 3.5f, "nível do reverb equilibrado");

            // no ringing at a single frequency (a sign of a metallic, bad reverb): impulse response spectral spread
            Fx.Effect e2 = Fx.create(Fx.REVERB, R);
            e2.active = true; e2.setXY(0.5f, 1f);
            float[] imp = new float[R * 3]; imp[0] = 1f;
            float[] ir = runFx(e2, imp, 120);
            // echo density: fraction of 1ms windows after 200 ms that carry energy
            int dense = 0, tot = 0;
            for (int w = (int) (0.2 * R); w + 48 < (int) (1.2 * R); w += 48) {
                tot++;
                float local = rms(ir, w - 600, w + 600);      // 25 ms neighbourhood
                if (rms(ir, w, w + 48) > 0.25f * local) dense++;   // no gaps: every ms carries a share of the energy
            }
            System.out.println("   densidade de ecos 0.2–1.2 s: " + dense + "/" + tot);
            check(dense > tot * 0.97, "resposta densa e contínua (sem eco discreto/metálico)");
        }

        System.out.println("== Filtro LP / HP");
        {
            float[] lo = sine(100, R, 0.5f), hi = sine(8000, R, 0.5f);
            Fx.Filter f = (Fx.Filter) Fx.create(Fx.FILTER, R);
            f.active = true; f.setXY(0.537f, 0f);   // ~1 kHz, no resonance
            f.mode = 0;
            float lpLo = rms(runFx(f, lo, 120), R / 2, R), lpHi = rms(runFx(f, hi, 120), R / 2, R);
            Fx.Filter g = (Fx.Filter) Fx.create(Fx.FILTER, R);
            g.active = true; g.setXY(0.537f, 0f); g.mode = 1;
            float hpLo = rms(runFx(g, lo, 120), R / 2, R), hpHi = rms(runFx(g, hi, 120), R / 2, R);
            float ref = 0.5f / (float) Math.sqrt(2);
            System.out.println("   LP: 100Hz=" + lpLo / ref + " 8kHz=" + lpHi / ref + " | HP: 100Hz=" + hpLo / ref + " 8kHz=" + hpHi / ref);
            check(lpLo / ref > 0.9f && lpHi / ref < 0.1f, "Low-pass deixa passar graves e corta agudos");
            check(hpHi / ref > 0.9f && hpLo / ref < 0.1f, "High-pass deixa passar agudos e corta graves");
        }

        System.out.println("== Looper: duração precisa, reverse e quantização");
        {
            // 2 s sample, 48 kHz. fingers at 0.23 and 0.47 => loop = 0.24*2 s = 0.48 s
            double expect = 0.24 * 2.0;
            double per = loopPeriod(0, 0.23f, 0.47f);
            System.out.println("   período medido " + per + " s, esperado " + expect + " s");
            check(Math.abs(per - expect) / expect < 0.01, "duração do loop = distância entre os dedos (±1%)");
            double per2 = loopPeriod(0, 0.10f, 0.60f);
            check(Math.abs(per2 - 1.0) / 1.0 < 0.01, "loop largo (0.10–0.60) dura 1.0 s");
            double per3 = loopPeriod(0, 0.50f, 0.52f);
            check(Math.abs(per3 - 0.04) / 0.04 < 0.05, "loop curto (0.02 = 40 ms) preciso (" + per3 + " s)");
            double perQ = loopPeriod(8, 0.23f, 0.47f);
            System.out.println("   com quantização 8: " + perQ + " s");
            check(Math.abs(perQ - 0.5) < 0.01, "quantização 8 ajusta os marcadores à grade (0.25–0.5 → 0.5 s)");
            // reverse
            Slot s = sineSlot(220, 0.5f);
            Slot rampSlot = new Slot(R);
            float[] ramp = new float[R * 2];
            for (int i = 0; i < ramp.length; i++) ramp[i] = (float) i / ramp.length;
            rampSlot.setSample(new Sample(ramp, R, "ramp"), 120);
            rampSlot.mode = Slot.LOOPER;
            rampSlot.handle(0, 0, 0.60f, 0.5f, 0, 0);
            rampSlot.handle(0, 1, 0.20f, 0.5f, 0, 0);   // second finger LEFT of the first => reverse
            int dec = 0, inc = 0;
            float prev = -1;
            float[] l = new float[256], r = new float[256];
            for (int b = 0; b < 200; b++) {
                java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0);
                rampSlot.render(l, r, 256, b * 256L, 120, true);
                if (b > 20) for (int i = 1; i < 256; i++) {
                    float d = l[i] - l[i - 1];
                    if (Math.abs(d) < 0.01f) { if (d < 0) dec++; else if (d > 0) inc++; }
                }
            }
            System.out.println("   reverse: subindo=" + inc + " descendo=" + dec);
            check(dec > inc * 5, "dedos cruzados tocam o loop em reverse");
        }

        System.out.println("== Scratch");
        {
            Slot s = sineSlot(300, 0.8f);
            s.mode = Slot.SCRATCH;
            final float[] x = {0.5f};
            // finger goes down, then wiggles smoothly at 60 Hz like a real touch screen
            float[] out = renderSlot(s, 4, 120, b -> {
                if (b == 0) s.handle(0, 0, 0.5f, 0.5f, 0, 0);
                if (b > 10 && b < 600 && b % 3 == 0) {
                    float t = (b - 10) / 187.5f;
                    s.handle(1, 0, 0.5f + 0.12f * (float) Math.sin(t * 2 * Math.PI * 1.5), 0.5f, 0, 0);
                }
                if (b == 600) s.handle(2, 0, 0, 0, 0, 0);
            });
            float moving = rms(out, 10000, 100000);
            float md = maxDiff(out, 4000, 120000);
            System.out.println("   scratch: rms em movimento " + moving + ", maior salto entre amostras " + md);
            check(moving > 0.03f, "scratch produz som ao arrastar");
            check(md < 0.3f, "scratch sem ruído/estalos (maior salto " + md + ")");
            // finger down but still
            Slot s2 = sineSlot(300, 0.8f);
            s2.mode = Slot.SCRATCH;
            float[] still = renderSlot(s2, 2, 120, b -> { if (b == 0) s2.handle(0, 0, 0.5f, 0.5f, 0, 0); });
            check(rms(still, R, 2 * R) < 0.005f, "dedo parado = silêncio");
        }

        System.out.println("== Estalos ao arrastar (maior salto entre amostras com seno de 220 Hz)");
        {
            String[] names = {"Slicer", "Looper", "Bow", "Tape", "Scratch", "Arp", "Keyboard", "LoopPlayer"};
            for (int m = 0; m < 8; m++) {
                final int mode = m;
                Slot s = sineSlot(220, 0.5f);
                s.mode = mode;
                s.legato = true; s.infinite = true;
                if (mode == Slot.ARP) s.div = 16;
                float[] out = renderSlot(s, 5, 120, b -> {
                    if (b == 0) { s.handle(0, 0, 0.3f, 0.3f, 0, 0); if (mode == Slot.LOOPER) s.handle(0, 1, 0.45f, 0.4f, 0, 0); }
                    if (b > 20 && b < 800 && b % 3 == 0) {
                        float t = (b - 20) / 187.5f;
                        float xx = 0.3f + 0.25f * (float) (0.5 + 0.5 * Math.sin(t * 2 * Math.PI * 0.8));
                        float yy = 0.2f + 0.6f * (float) (0.5 + 0.5 * Math.sin(t * 2 * Math.PI * 1.7));
                        s.handle(1, 0, xx, yy, 0, 0);
                        if (mode == Slot.LOOPER) s.handle(1, 1, xx + 0.12f, 0.4f, 0, 0);
                    }
                    if (b == 800) { s.handle(2, 0, 0, 0, 0, 0); if (mode == Slot.LOOPER) s.handle(2, 1, 0, 0, 0, 0); }
                    if (b == 400) s.volume = 0.2f;    // sudden slider move
                    if (b == 420) s.volume = 0.9f;
                    if (b == 440) s.pan = 0.1f;
                });
                float md = maxDiff(out, 3000, 5 * R - 300);
                float pk = 0; for (float v : out) pk = Math.max(pk, Math.abs(v));
                System.out.println("   " + names[m] + ": maior salto " + md + " (pico " + pk + ")");
                check(md < 0.30f, names[m] + " sem estalos ao arrastar");
            }
            // effects switching on/off
            Slot s = sineSlot(220, 0.5f);
            s.mode = Slot.LOOPPLAYER;
            for (int f = 0; f < Fx.COUNT; f++) {
                final int ff = f;
                Slot t = sineSlot(220, 0.5f);
                t.mode = Slot.LOOPPLAYER;
                if (f == Fx.FILTER) ((Fx.Filter) t.fx[f]).mode = 1;
                float[] out = renderSlot(t, 4, 120, b -> {
                    if (b == 0) t.handle(0, 0, 0.5f, 0.5f, 0, 0);
                    if (b == 100) { t.fx[ff].setXY(0.4f, 0.8f); t.fx[ff].active = true; }
                    if (b == 300) t.fx[ff].active = false;
                });
                float md = maxDiff(out, 3000, 4 * R - 300);
                check(md < 0.30f, Fx.NAMES[f] + " liga/desliga sem estalo (maior salto " + md + ")");
            }
        }

        System.out.println("== Slices manuais, automáticos e reverse");
        {
            Slot s = new Slot(R);
            float[] ramp = new float[R * 2];
            for (int i = 0; i < ramp.length; i++) ramp[i] = (float) i / ramp.length;
            s.setSample(new Sample(ramp, R, "ramp"), 120);
            s.markers = Slot.cleanMarkers(new float[]{0.8f, 0.1f, 0.5f, 0.5001f, 1.2f, -1f});
            check(s.markers.length == 3 && s.markers[0] == 0.1f && s.markers[2] == 0.8f, "marcadores são ordenados, sem duplicatas e dentro de 0..1");
            s.mode = Slot.SLICER;
            float lo = 9, hi = -9;
            float[] l = new float[256], r = new float[256];
            s.handle(0, 0, 0.3f, 0.5f, 0, 0);      // between 0.1 and 0.5
            for (int b = 0; b < 400; b++) {
                java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0);
                s.render(l, r, 256, b * 256L, 120, true);
                for (int i = 0; i < 256; i++) { float v = (l[i] + r[i]); if (Math.abs(v) > 0.02f) { lo = Math.min(lo, v); hi = Math.max(hi, v); } }
            }
            // output is the ramp scaled by volume/pan/env; so its range reveals which region played
            System.out.println("   fatia tocada: valores de " + lo + " a " + hi);
            float rampHi = hi / 0.7071f;      // (l+r) = ramp * vel(0.625) * volume(0.8) * 1.414
            boolean ended = true;
            for (float ph : s.playheads) if (ph >= 0) ended = false;
            System.out.println("   rampa máxima tocada ≈ " + rampHi + ", voz terminou: " + ended);
            check(rampHi > 0.38f && rampHi < 0.52f && ended, "fatia manual 0.1–0.5 toca até o marcador em 0.5 e para");

            Engine e = new Engine(R);
            int n = e.autoSlice(0, 32, 0.5f);
            float[] m = e.slots[0].markers;
            System.out.println("   auto-slice no loop de bateria: " + n + " marcadores");
            check(n >= 8 && n <= 32, "detecção automática encontra os golpes (" + n + ")");
            boolean near = false;
            if (m != null) for (float v : m) if (Math.abs(v * 4.0 - 1.0) < 0.02) near = true;   // snare at 1.0 s of 4 s
            check(near, "detectou a caixa em 1.0 s dentro de ±20 ms");

            Slot rs = e.slots[1];
            rs.markers = Slot.cleanMarkers(new float[]{0.25f});
            float first = rs.sample.data[10];
            int len = rs.sample.length();
            float last = rs.sample.data[len - 11];
            rs.reverseSample();
            check(rs.reversed && Math.abs(rs.sample.data[len - 11] - first) < 1e-9 && Math.abs(rs.markers[0] - 0.75f) < 1e-6, "reverse inverte o áudio e espelha os marcadores");
            rs.reverseSample();
            check(!rs.reversed && Math.abs(rs.sample.data[10] - first) < 1e-9, "reverse de novo restaura o original");
        }

        System.out.println("== Botão de stop");
        {
            Engine e = new Engine(R);
            e.bpm = 240;
            e.setMode(0, Slot.LOOPPLAYER);
            e.setMode(1, Slot.SLICER); e.slots[1].infinite = true;
            e.setMode(2, Slot.ARP); e.slots[2].div = 16;
            e.setMode(3, Slot.SLICER);
            short[] pcm = new short[2 * R / 10];
            java.util.function.IntConsumer run = secs -> { for (int i = 0; i < secs * 10; i++) e.process(pcm, pcm.length / 2); };
            java.util.function.Supplier<Float> peak = () -> { float pk = 0; for (short v : pcm) pk = Math.max(pk, Math.abs(v) / 32768f); return pk; };
            e.armGestures(3, 2);
            run.accept(1);
            e.touch(3, 0, 0, 0.1f, 0.2f); run.accept(1); e.touch(3, 2, 0, 0, 0);
            run.accept(3);                                   // gesture recorded and now looping
            e.touch(0, 0, 0, 0.5f, 0.5f);                    // loop player on
            e.touch(1, 0, 1, 0.4f, 0.3f);                    // held looping slice
            e.touch(2, 0, 2, 0.2f, 0.3f);                    // held arp finger
            run.accept(2);
            check(peak.get() > 0.05f, "antes do stop há som");
            e.stopAll();
            run.accept(1);                                   // fade-out time
            float worst = 0;
            for (int i = 0; i < 30; i++) { e.process(pcm, pcm.length / 2); worst = Math.max(worst, peak.get()); }
            System.out.println("   pico nos 3 s depois do stop: " + worst);
            check(worst < 0.002f, "stop silencia vozes, loops, arpejo e gestos gravados");
            check(!e.playing, "transporte fica parado");
            e.playing = true;
            run.accept(3);
            float back = 0;
            for (int i = 0; i < 40; i++) { e.process(pcm, pcm.length / 2); back = Math.max(back, peak.get()); }
            check(back > 0.01f, "play retoma o gesto gravado");
        }

        System.out.println("== ADSR em todos os modos");
        {
            String[] names = {"Slicer", "Looper", "Bow", "Keyboard"};
            int[] modes = {Slot.SLICER, Slot.LOOPER, Slot.BOW, Slot.KEYBOARD};
            for (int mi = 0; mi < 4; mi++) {
                final Slot sl = new Slot(R);
                float[] flat = new float[R * 6];
                java.util.Arrays.fill(flat, 0.5f);
                sl.setSample(new Sample(flat, R, "flat"), 120);
                sl.mode = modes[mi]; sl.div = 4; sl.infinite = true;
                sl.attack = 0.3f; sl.decay = 0.2f; sl.sustain = 0.4f; sl.release = 0.5f;
                final int mm = modes[mi];
                final int[] upBlock = {-1};
                float[] o = renderSlot(sl, 3.0, 120, b -> {
                    if (b == 0) {
                        if (mm == Slot.LOOPER) { sl.handle(0, 0, 0.1f, 0.5f, 0, 0); sl.handle(0, 1, 0.9f, 0.5f, 0, 0); }
                        else sl.handle(0, 0, 0.30f, 0.0f, 0, 0);
                    }
                    if (b == (int) (1.5 * R / 256)) {
                        upBlock[0] = b;
                        sl.handle(2, 0, 0.30f, 0.0f, (long) b * 256, 0); if (mm == Slot.LOOPER) sl.handle(2, 1, 0.9f, 0.5f, (long) b * 256, 0);
                    }
                });
                float early = rms(o, 0, R / 100), mid = rms(o, (int) (0.28 * R), (int) (0.32 * R));
                float sus = rms(o, (int) (1.0 * R), (int) (1.2 * R));
                float peak = 0; for (int i = 0; i < (int) (0.6 * R); i++) peak = Math.max(peak, Math.abs(o[i]));
                float r1 = rms(o, (int) (1.5 * R + 0.1 * R), (int) (1.5 * R + 0.15 * R));
                float rEnd = rms(o, (int) (2.2 * R), (int) (2.4 * R));
                check(early < 0.35f * mid, names[mi] + ": attack lento (inicio " + early + " < meio " + mid + ")");
                check(sus < 0.75f * peak && sus > 0.15f * peak, names[mi] + ": decay vai para o sustain (pico " + peak + " sus " + sus + ")");
                check(r1 > 0.05f * sus && rEnd < 0.02f * Math.max(sus, 1e-3f) + 1e-4f, names[mi] + ": release gradual (0.1s " + r1 + ", fim " + rEnd + ")");
            }
        }
        System.out.println("== Arpejador");
        {
            // 8 fatias, fatia k tem amplitude (k+1)*0.1
            float[] d = new float[R * 4];
            for (int i = 0; i < d.length; i++) d[i] = 0.1f * (1 + Math.min(7, i * 8 / d.length));
            final Slot cal = new Slot(R);
            cal.setSample(new Sample(d, R, "ramp"), 120);
            cal.mode = Slot.SLICER; cal.div = 8; cal.attack = 0f;
            float[] co = renderSlot(cal, 0.4, 120, b -> { if (b == 0) cal.handle(0, 0, 0.95f, 0f, 0, 0); });
            final float gain = rms(co, (int) (0.2 * R), (int) (0.3 * R)) / 0.8f;     // volume/pan factor of the slot
            for (int dir = 0; dir < 5; dir++) {
                final Slot sl = new Slot(R);
                sl.setSample(new Sample(d, R, "ramp"), 120);
                sl.mode = Slot.ARP; sl.div = 8; sl.arpRate = 16; sl.arpDir = dir; sl.attack = 0f; sl.decay = 0.1f; sl.sustain = 1f; sl.release = 0.02f;
                final int[] ks = {5, 2, 0};
                float[] o = renderSlot(sl, 2.0, 120, b -> {
                    if (b == 0) for (int k = 0; k < 3; k++) sl.handle(0, k, (ks[k] + 0.5f) / 8f, 0f, 0, 0);
                });
                // 1/16 a 120bpm = 0.125 s por passo; mede o nivel no meio de cada passo (a partir do 1o passo na grade)
                StringBuilder seq = new StringBuilder();
                java.util.ArrayList<Integer> got = new java.util.ArrayList<>();
                for (int st = 1; st < 14; st++) {
                    int c = (int) ((st * 0.125 + 0.06) * R);
                    float lv = rms(o, c - 200, c + 200);
                    int sli = Math.round(lv / (gain * 0.1f)) - 1;
                    got.add(sli); seq.append(sli).append(' ');
                }
                String name = new String[]{"UP", "DN", "UD", "RND", "ORD"}[dir];
                System.out.println("     " + name + ": " + seq);
                boolean okSeq = true;
                int[] up = {0, 2, 5}, dn = {5, 2, 0}, ud = {0, 2, 5, 2}, ord = {5, 2, 0};
                int[] pat = dir == 0 ? up : dir == 1 ? dn : dir == 2 ? ud : ord;
                if (dir == 3) { for (int g : got) if (g != 0 && g != 2 && g != 5) okSeq = false; }
                else {
                    // acha o alinhamento do padrao e confere que se repete sem erros
                    boolean any = false;
                    for (int off = 0; off < pat.length && !any; off++) {
                        boolean m = true;
                        for (int i = 0; i < got.size(); i++) if (got.get(i) != pat[(i + off) % pat.length]) { m = false; break; }
                        any = m;
                    }
                    okSeq = any;
                }
                check(okSeq, "Arp " + name + ": ordem correta das fatias");
            }
            // passos na grade: dois arps com dedos em instantes diferentes disparam no mesmo instante da grade
            final Slot sl = new Slot(R);
            sl.setSample(new Sample(d, R, "ramp"), 120);
            sl.mode = Slot.ARP; sl.div = 8; sl.arpRate = 8; sl.attack = 0f; sl.release = 0.02f; sl.decay = 0.1f;
            float[] o = renderSlot(sl, 2.0, 120, b -> { if (b == 100) sl.handle(0, 0, 0.3f, 0f, 100L * 256, 0); });
            // notas a cada 0.25 s: busca os inicios (energia) depois do toque (~0.53 s)
            java.util.ArrayList<Double> starts = new java.util.ArrayList<>();
            boolean prevOn = false;
            for (int i = 100 * 256 + 50; i < o.length; i++) {
                boolean on = Math.abs(o[i]) > 0.02f;
                if (on && !prevOn && (starts.isEmpty() || i / (double) R - starts.get(starts.size() - 1) > 0.1)) starts.add(i / (double) R);
                prevOn = on;
            }
            // o 1o toque soa na hora (imediato); as demais notas caem na grade de 0.25 s
            boolean grid = starts.size() >= 4;
            for (int i = 1; i < starts.size(); i++) { double ph = starts.get(i) / 0.25; if (Math.abs(ph - Math.round(ph)) > 0.06) grid = false; }
            System.out.println("     inicios: " + starts);
            check(grid, "Arp: notas travadas na grade do BPM (" + starts.size() + " notas, a cada 0.25 s)");
        }
        System.out.println("== Reverb: qualidade (sem metalico)");
        {
            for (double x : new double[]{0.3, 0.6, 0.9}) {
                float[] r = ReverbQuality.ir((float) x, 1f, 4);
                double per = ReverbQuality.periodicity(r), pk = ReverbQuality.spectralPeakiness(r);
                check(per < 0.5, String.format("Reverb x=%.1f periodicidade %.3f < 0.5", x, per));
                check(pk < 14, String.format("Reverb x=%.1f picos espectrais %.2f dB < 14", x, pk));
            }
        }
        System.out.println("== Latch");
        {
            for (int md : new int[]{Slot.SLICER, Slot.BOW, Slot.TAPE, Slot.KEYBOARD}) {
                final Slot sl = new Slot(R);
                float[] flat = new float[R * 8]; java.util.Arrays.fill(flat, 0.5f);
                sl.setSample(new Sample(flat, R, "flat"), 120);
                sl.mode = md; sl.div = 4; sl.infinite = true; sl.release = 0.05f; sl.latch = true;
                final int mm = md;
                float[] o = renderSlot(sl, 3.0, 120, b -> {
                    if (b == 0) sl.handle(0, 0, 0.3f, 0.2f, 0, 0);
                    if (b == 20) sl.handle(2, 0, 0.3f, 0.2f, 20L * 256, 0);
                    if (b == 60) sl.mode = (mm == Slot.BOW ? Slot.KEYBOARD : Slot.BOW);       // switching play mode keeps it sounding
                });
                float after = rms(o, (int) (2.5 * R), (int) (2.9 * R));
                check(after > 0.05f, "Latch mantém o som após soltar e trocar de modo (modo " + md + ", rms " + after + ")");
                // novo gesto troca o som latched
                final Slot s2 = new Slot(R);
                s2.setSample(new Sample(flat, R, "flat"), 120);
                s2.mode = md; s2.div = 4; s2.infinite = true; s2.release = 0.05f; s2.latch = true;
                float[] o2 = renderSlot(s2, 2.0, 120, b -> {
                    if (b == 0) s2.handle(0, 0, 0.3f, 0.2f, 0, 0);
                    if (b == 10) s2.handle(2, 0, 0.3f, 0.2f, 0, 0);
                    if (b == 150) s2.applyLatch(false);                                    // latch off = release
                });
                check(rms(o2, (int) (0.5 * R), (int) (0.6 * R)) > 0.05f && rms(o2, (int) (1.8 * R), (int) (1.95 * R)) < 0.005f,
                      "Latch desligado solta o som (modo " + md + ")");
            }
            // sem latch: soltar corta
            final Slot nl = new Slot(R);
            float[] flat = new float[R * 8]; java.util.Arrays.fill(flat, 0.5f);
            nl.setSample(new Sample(flat, R, "flat"), 120);
            nl.mode = Slot.SLICER; nl.div = 4; nl.infinite = true; nl.release = 0.05f;
            float[] o3 = renderSlot(nl, 2.0, 120, b -> { if (b == 0) nl.handle(0, 0, 0.3f, 0.2f, 0, 0); if (b == 20) nl.handle(2, 0, 0.3f, 0.2f, 0, 0); });
            check(rms(o3, (int) (1.5 * R), (int) (1.9 * R)) < 0.005f, "Sem latch o som termina ao soltar");
            // Looper: fadeAll (stop) e soltar o dedo nao pode dar excecao
            final Slot lp = new Slot(R);
            lp.setSample(new Sample(flat, R, "flat"), 120);
            lp.mode = Slot.LOOPER;
            boolean threw = false;
            try {
                lp.handle(0, 0, 0.2f, 0.5f, 0, 0); lp.handle(0, 1, 0.6f, 0.5f, 0, 0);
                renderSlot(lp, 0.1, 120, null);
                lp.fadeAll();
                lp.handle(2, 0, 0, 0, 0, 0); lp.handle(2, 1, 0, 0, 0, 0);
                renderSlot(lp, 0.1, 120, null);
            } catch (RuntimeException ex) { threw = true; }
            check(!threw, "Looper: soltar dedos depois de Stop não dá exceção");
        }
        System.out.println("== Quantizar / Slicer auto-play");
        {
            float[] d = new float[R * 4];
            for (int i = 0; i < d.length; i++) d[i] = 0.1f * (1 + Math.min(7, i * 8 / d.length));
            // quantizar: toque fora da grade comeca exatamente na proxima subdivisao (1/8 a 120bpm = 0.25 s)
            final Slot q = new Slot(R);
            q.setSample(new Sample(d, R, "ramp"), 120);
            q.mode = Slot.SLICER; q.div = 8; q.quantize = true; q.arpRate = 8; q.attack = 0f; q.release = 0.02f;
            float[] o = renderSlot(q, 1.5, 120, b -> { if (b == 130) q.handle(0, 0, 0.3f, 0f, 130L * 256, 0); });   // t = 0.693 s
            int first = -1;
            for (int i = 0; i < o.length; i++) if (Math.abs(o[i]) > 0.01f) { first = i; break; }
            double t0 = first / (double) R;
            System.out.println("     toque em 0.693 s, nota começou em " + t0 + " s");
            check(t0 >= 0.74 && t0 <= 0.76, "Quantizar: nota começa na próxima subdivisão da grade (0.75 s)");
            // sem quantizar começa na hora
            final Slot nq = new Slot(R);
            nq.setSample(new Sample(d, R, "ramp"), 120);
            nq.mode = Slot.SLICER; nq.div = 8; nq.attack = 0f;
            float[] o2 = renderSlot(nq, 1.5, 120, b -> { if (b == 130) nq.handle(0, 0, 0.3f, 0f, 130L * 256, 0); });
            int f2 = -1; for (int i = 0; i < o2.length; i++) if (Math.abs(o2[i]) > 0.01f) { f2 = i; break; }
            check(f2 / (double) R < 0.71, "Sem quantizar a nota começa no toque");
            // dedo levantado antes do disparo ainda toca
            final Slot q2 = new Slot(R);
            q2.setSample(new Sample(d, R, "ramp"), 120);
            q2.mode = Slot.SLICER; q2.div = 8; q2.quantize = true; q2.arpRate = 8; q2.release = 0.02f;
            float[] o3 = renderSlot(q2, 1.5, 120, b -> { if (b == 130) q2.handle(0, 0, 0.3f, 0f, 0, 0); if (b == 135) q2.handle(2, 0, 0.3f, 0f, 0, 0); });
            check(rms(o3, (int) (0.78 * R), (int) (0.9 * R)) > 0.03f, "Quantizar: toque curto (soltou antes da grade) ainda dispara");

            // auto-play: fatias em ordem, uma por passo (1/8 = 0.25 s), travado na grade
            final Slot ap = new Slot(R);
            ap.setSample(new Sample(d, R, "ramp"), 120);
            ap.mode = Slot.SLICER; ap.div = 8; ap.arpRate = 8; ap.attack = 0f; ap.release = 0.01f; ap.decay = 0.05f;
            final Slot cal = new Slot(R);
            cal.setSample(new Sample(d, R, "ramp"), 120); cal.mode = Slot.SLICER; cal.div = 8; cal.attack = 0f;
            float[] co = renderSlot(cal, 0.4, 120, b -> { if (b == 0) cal.handle(0, 0, 0.95f, 0f, 0, 0); });
            final float gain = rms(co, (int) (0.2 * R), (int) (0.3 * R)) / 0.8f;
            ap.autoPlay = true;
            float[] ao = renderSlot(ap, 4.2, 120, null);
            StringBuilder seq = new StringBuilder(); java.util.ArrayList<Integer> got = new java.util.ArrayList<>();
            for (int st = 1; st < 14; st++) {
                int c = (int) ((st * 0.25 + 0.12) * R);
                float lv = rms(ao, c - 150, c + 150);
                int sli = Math.round(lv / (gain * 0.09f)) - 1;
                got.add(sli); seq.append(sli).append(' ');
            }
            System.out.println("     auto: " + seq);
            boolean ord = true;
            for (int i = 1; i < got.size(); i++) if (got.get(i) != (got.get(i - 1) + 1) % 8) ord = false;
            check(ord, "Slicer auto-play percorre as fatias da esquerda para a direita");
            // shuffle: sem repetir a mesma fatia em seguida, e usa varias fatias
            final Slot sh = new Slot(R);
            sh.setSample(new Sample(d, R, "ramp"), 120);
            sh.mode = Slot.SLICER; sh.div = 8; sh.arpRate = 8; sh.attack = 0f; sh.release = 0.01f; sh.decay = 0.05f; sh.autoPlay = true; sh.shuffle = true;
            float[] so = renderSlot(sh, 6.0, 120, null);
            java.util.ArrayList<Integer> sg = new java.util.ArrayList<>();
            for (int st = 1; st < 22; st++) { int c = (int) ((st * 0.25 + 0.12) * R); sg.add(Math.round(rms(so, c - 150, c + 150) / (gain * 0.09f)) - 1); }
            boolean norep = true; java.util.HashSet<Integer> uniq = new java.util.HashSet<>(sg);
            for (int i = 1; i < sg.size(); i++) if (sg.get(i).equals(sg.get(i - 1))) norep = false;
            check(norep && uniq.size() >= 4, "Shuffle: ordem aleatória sem repetir em seguida (" + uniq.size() + " fatias diferentes)");
            // trocar o numero de fatias durante o arp nao pode lancar excecao
            final Slot ar = new Slot(R);
            ar.setSample(new Sample(d, R, "ramp"), 120);
            ar.mode = Slot.ARP; ar.div = 32; ar.arpRate = 16;
            boolean threw = false;
            try {
                renderSlot(ar, 1.5, 120, b -> {
                    if (b == 0) { ar.handle(0, 0, 0.95f, 0.1f, 0, 0); ar.handle(0, 1, 0.5f, 0.1f, 0, 0); }
                    if (b == 40) ar.div = 4;
                    if (b == 80) ar.markers = Slot.cleanMarkers(new float[]{0.2f});
                    if (b == 120) ar.markers = null;
                    if (b == 160) ar.div = 16;
                });
            } catch (RuntimeException ex) { threw = true; ex.printStackTrace(); }
            check(!threw, "Arp: mudar a quantidade de fatias durante o jogo não dá exceção");
            check(ar.arpSlice <= 31, "Arp: fatia indicada é válida");
        }
        System.out.println("== Loop player, gestos, FX");
        {
            Engine eng = new Engine(R);
            float[] flat = new float[R * 2]; java.util.Arrays.fill(flat, 0.4f);
            eng.slots[0].setSample(new Sample(flat, R, "flat"), 120);
            eng.slots[0].mode = Slot.LOOPPLAYER;
            eng.playing = false;                                                // transporte parado
            short[] pcm = new short[256 * 2];
            for (int i = 0; i < 8; i++) eng.process(pcm, 256);
            eng.touch(0, 0, 0, 0.5f, 0.5f); eng.touch(0, 2, 0, 0.5f, 0.5f);       // primeiro toque
            double e = 0;
            for (int i = 0; i < 40; i++) { eng.process(pcm, 256); for (short v : pcm) e += Math.abs(v); }
            check(eng.playing && e > 1000, "Loop player toca já no primeiro toque (transporte parado antes)");

            // gestos: grava no 1o toque, inclui FX, e repete
            Engine g = new Engine(R);
            g.slots[1].mode = Slot.SLICER;
            g.bpm = 240;                                                      // 1 compasso = 1 s
            g.armGestures(1, 1);
            for (int i = 0; i < 20; i++) g.process(pcm, 256);                  // sem toque: nada acontece
            check(g.slots[1].gestures.state == GestureRecorder.ARMED, "Gestos: aguardando o primeiro toque");
            g.touch(1, 0, 0, 0.3f, 0.2f);
            g.process(pcm, 256);
            check(g.slots[1].gestures.state == GestureRecorder.RECORDING, "Gestos: gravação começa no primeiro toque na waveform");
            g.touch(1, 2, 0, 0, 0);
            for (int i = 0; i < 20; i++) g.process(pcm, 256);
            g.fxTouch(1, 3, Fx.FILTER, 0.2f, 0.7f);                            // toque no pad de efeito durante a gravação
            for (int i = 0; i < 10; i++) g.process(pcm, 256);
            g.fxTouch(1, 4, Fx.FILTER, 0.4f, 0.7f);
            g.process(pcm, 256);
            g.fxTouch(1, 5, Fx.FILTER, 0, 0);
            for (int i = 0; i < 400 && g.slots[1].gestures.state == GestureRecorder.RECORDING; i++) g.process(pcm, 256);
            GestureRecorder gr = g.slots[1].gestures;
            check(gr.state == GestureRecorder.PLAYING, "Gestos: terminou a gravação e está repetindo");
            int fxEv = 0; for (int i = 0; i < gr.eventCount(); i++) if (gr.typeAt(i) >= 3) fxEv++;
            check(fxEv == 3, "Gestos: movimentos do pad de efeito foram gravados (" + fxEv + " eventos)");
            // replay aciona o filtro
            boolean sawActive = false;
            for (int i = 0; i < 400; i++) { g.process(pcm, 256); if (g.slots[1].fx[Fx.FILTER].active) sawActive = true; }
            check(sawActive, "Gestos: o replay liga o efeito do pad");
            // salvar / carregar
            int n = gr.eventCount();
            double[] ph = new double[n]; int[] ty = new int[n], idd = new int[n]; float[] xx = new float[n], yy = new float[n];
            for (int i = 0; i < n; i++) { ph[i] = gr.phaseAt(i); ty[i] = gr.typeAt(i); idd[i] = gr.idAt(i); xx[i] = gr.xAt(i); yy[i] = gr.yAt(i); }
            Engine h = new Engine(R);
            h.setGestures(2, gr.bars(), ph, ty, idd, xx, yy);
            h.process(pcm, 256);
            check(h.slots[2].gestures.state == GestureRecorder.PLAYING && h.slots[2].gestures.eventCount() == n, "Gestos: projeto carregado volta tocando (" + n + " eventos)");
        }
        System.out.println("== Delay 10 ms .. 4 s");
        {
            check(Fx.Delay.msForX(0) == 10 && Fx.Delay.msForX(1) == 4000, "Delay: alcance 10 ms a 4000 ms");
            boolean step1 = true;
            for (double x = 0; x < 0.2; x += 0.0005) { double a1 = Fx.Delay.msForX(x), a2 = Fx.Delay.msForX(x + 0.0005); if (a2 - a1 > 1.0 || a1 != Math.rint(a1)) step1 = false; }
            check(step1, "Delay: faixa curta varia de 1 em 1 ms (valores inteiros)");
            // comb filter: 10 ms com feedback alto => picos a cada 100 Hz
            Fx.Effect dl = Fx.create(Fx.DELAY, R); dl.x = 0f; dl.y = 0.9f; dl.active = true;
            float[] in = noise(R * 2, 0.3f, 7);
            float[] out = runFx(dl, in, 120);
            double[] spec = new double[R / 2 + 1];
            int N = 16384; int st0 = R;       // 16384-point DFT at selected bins
            double pk = 0, vl = 0;
            for (int rep = 0; rep < 2; rep++) {
                double f = rep == 0 ? 100.0 : 150.0;       // pico (100 Hz) vs vale (150 Hz)
                double re = 0, im = 0;
                for (int i = 0; i < N; i++) { double w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N); re += out[st0 + i] * w * Math.cos(2 * Math.PI * f * i / R); im -= out[st0 + i] * w * Math.sin(2 * Math.PI * f * i / R); }
                if (rep == 0) pk = Math.hypot(re, im); else vl = Math.hypot(re, im);
            }
            check(pk > 3 * vl, String.format("Delay 10 ms: efeito de filtro pente (pico 100 Hz %.1f x vale 150 Hz %.1f)", pk, vl));
            // 4 s: o eco chega depois de ~4 s
            Fx.Effect d4 = Fx.create(Fx.DELAY, R); d4.x = 1f; d4.y = 0.2f; d4.active = true;
            float[] imp = new float[R * 6]; imp[100] = 0.8f;
            float[] o4 = runFx(d4, imp, 120);
            int pkAt = 0; float pv = 0;
            for (int i = R; i < o4.length; i++) if (Math.abs(o4[i]) > pv) { pv = Math.abs(o4[i]); pkAt = i; }
            check(Math.abs(pkAt / (double) R - 4.0) < 0.03, "Delay: tempo máximo = 4 s (eco em " + pkAt / (double) R + " s)");
            // sync: x escolhe nota; 1/8 a 120 bpm = 250 ms
            Fx.Delay sd = (Fx.Delay) Fx.create(Fx.DELAY, R); sd.sync = true; sd.x = 6.5f / 12f; sd.y = 0.2f; sd.active = true;
            runFx(sd, new float[1024], 120);
            check(Math.abs(sd.shownMs - 250f) < 1f, "Delay sync: 1/8 a 120 bpm = 250 ms (" + sd.shownMs + ")");
            runFx(sd, new float[1024], 90);
            check(Math.abs(sd.shownMs - 333.3f) < 1f, "Delay sync acompanha o BPM (90 bpm -> " + sd.shownMs + " ms)");
        }
        System.out.println("== Scratch fluido (toque a 60 Hz)");
        {
            final Slot sc = new Slot(R);
            sc.setSample(new Sample(sine(220, R * 4, 0.6f), R, "sine"), 120);
            sc.mode = Slot.SCRATCH; sc.attack = 0f; sc.release = 0.02f;
            // dedo faz vai-e-vem senoidal 2 Hz, atualizando a 60 Hz (a cada ~13 blocos de 256 = 3 eventos/... )
            final int per = (int) Math.round(R / 60.0 / 256.0 * 256.0);        // frames entre toques
            float[] o = renderSlot(sc, 3.0, 120, b -> {
                if (b == 0) sc.handle(0, 0, 0.5f, 0.3f, 0, 0);
                else if ((b % 3) == 0) { double t = b * 256.0 / R; sc.handle(1, 0, (float) (0.5 + 0.12 * Math.sin(2 * Math.PI * 2.0 * t)), 0.3f, (long) b * 256, 0); }
            });
            float mx = 0, rough = 0; int cnt = 0;
            for (int i = (int) (0.3 * R) + 1; i < o.length; i++) {
                float dd = Math.abs(o[i] - o[i - 1]); if (dd > mx) mx = dd;
            }
            // clique = salto de amostra muito acima do que a senoide gera na velocidade maxima (<~ 2x)
            check(mx < 0.35f, "Scratch a 60 Hz: sem estalos (maior salto entre amostras " + mx + ")");
            // modulacao: o envelope (janelas de 2 ms) nao pode ter uma linha forte em 60 Hz (a taxa dos toques)
            int w2 = 96; int ne = o.length / w2; double[] env = new double[ne]; double mean = 0;
            for (int i = 0; i < ne; i++) { double acc = 0; for (int j = 0; j < w2; j++) acc += Math.abs(o[i * w2 + j]); env[i] = acc / w2; }
            int i0 = (int) (0.5 * R / w2); int cntE = ne - i0;
            for (int i = i0; i < ne; i++) mean += env[i];
            mean /= cntE;
            double fe = R / (double) w2, re = 0, im = 0;
            for (int i = i0; i < ne; i++) { double ph = 2 * Math.PI * 60.0 * (i - i0) / fe; re += (env[i] - mean) * Math.cos(ph); im += (env[i] - mean) * Math.sin(ph); }
            double line60 = 2 * Math.hypot(re, im) / cntE / mean;
            System.out.println("     linha de 60 Hz no envelope: " + line60);
            check(line60 < 0.06, "Scratch a 60 Hz: sem modulação de 60 Hz no volume (" + line60 + ")");
        }
        System.out.println("== v1.4: ping-pong, Bow, degraus, regiao, trim, stretch");
        {
            // rampa: valor = posicao
            float[] ramp = new float[R * 8];
            for (int i = 0; i < ramp.length; i++) ramp[i] = 0.8f * i / ramp.length;
            // ping-pong
            final Slot pp = new Slot(R);
            pp.setSample(new Sample(ramp, R, "ramp"), 120);
            pp.mode = Slot.LOOPER; pp.pingPong = true; pp.attack = 0f;
            float[] o = renderSlot(pp, 4.0, 120, b -> { if (b == 0) { pp.handle(0, 0, 0.2f, 0.5f, 0, 0); pp.handle(0, 1, 0.3f, 0.5f, 0, 0); } });
            float mn = 9, mx = -9, md = 0; int turns = 0; float prev = 0; int dir = 0;
            for (int i = (int) (0.3 * R); i < o.length; i++) {
                mn = Math.min(mn, o[i]); mx = Math.max(mx, o[i]);
                float d = o[i] - o[i - 1]; md = Math.max(md, Math.abs(d));
                int nd = d > 1e-6f ? 1 : (d < -1e-6f ? -1 : dir);
                if (nd != dir && dir != 0) turns++;
                dir = nd;
            }
            check(turns >= 4 && md < 0.1f * (mx - mn) && mx - mn > 0.01f, "Looper ping-pong: vai e volta sem saltos (" + turns + " viradas, salto max " + md + ")");
            // Bow: altura = volume; ate 4 notas
            final Slot bw = new Slot(R);
            float[] flat = new float[R * 4]; java.util.Arrays.fill(flat, 0.5f);
            bw.setSample(new Sample(flat, R, "flat"), 120);
            bw.mode = Slot.BOW; bw.attack = 0f; bw.sustain = 1f;
            float[] hi = renderSlot(bw, 0.6, 120, b -> { if (b == 0) bw.handle(0, 0, 0.5f, 0.05f, 0, 0); });
            final Slot bw2 = new Slot(R);
            bw2.setSample(new Sample(flat, R, "flat"), 120); bw2.mode = Slot.BOW; bw2.attack = 0f; bw2.sustain = 1f;
            float[] lo = renderSlot(bw2, 0.6, 120, b -> { if (b == 0) bw2.handle(0, 0, 0.5f, 0.95f, 0, 0); });
            check(rms(hi, (int) (0.3 * R), (int) (0.5 * R)) > 1.5f * rms(lo, (int) (0.3 * R), (int) (0.5 * R)), "Bow: altura do dedo controla o volume");
            final Slot b5 = new Slot(R);
            b5.setSample(new Sample(flat, R, "flat"), 120); b5.mode = Slot.BOW;
            renderSlot(b5, 0.5, 120, b -> { if (b == 0) for (int k = 0; k < 6; k++) b5.handle(0, k, 0.1f + 0.1f * k, 0.5f, 0, 0); });
            check(b5.activeVoices <= 4, "Bow: no maximo 4 notas (" + b5.activeVoices + ")");
            // tamanho do grao
            final Slot g1 = new Slot(R), g2 = new Slot(R);
            float[] tone = sine(220, R * 4, 0.6f);
            g1.setSample(new Sample(tone, R, "t"), 120); g2.setSample(new Sample(tone, R, "t"), 120);
            g1.mode = g2.mode = Slot.BOW; g1.bowSize = 0.02f; g2.bowSize = 1f;
            float[] a1 = renderSlot(g1, 1.0, 120, b -> { if (b == 0) g1.handle(0, 0, 0.5f, 0.3f, 0, 0); });
            float[] a2 = renderSlot(g2, 1.0, 120, b -> { if (b == 0) g2.handle(0, 0, 0.5f, 0.3f, 0, 0); });
            check(a1.length == a2.length && rms(a1, R / 2, (int) (0.9 * R)) > 0.01f && rms(a2, R / 2, (int) (0.9 * R)) > 0.01f, "Bow: controle de grão funciona nos extremos");

            // Tape em degraus: com marcadores (div=8) um movimento pequeno nao muda a velocidade
            double[] sl = new double[2];
            for (int pass = 0; pass < 2; pass++) {
                final Slot tp = new Slot(R);
                tp.setSample(new Sample(ramp, R, "ramp"), 120);
                tp.mode = Slot.TAPE; tp.div = pass == 0 ? 8 : 0; tp.attack = 0f;
                float[] to = renderSlot(tp, 2.0, 120, b -> { if (b == 0) tp.handle(0, 0, 0.1f, 0.5f, 0, 0); if (b == 300) tp.handle(1, 0, 0.1f + 0.03f, 0.5f, 0, 0); });
                int a0 = (int) (0.4 * R), a1i = (int) (1.2 * R), a2i = (int) (1.9 * R);
                double s1 = (to[a0 + 2000] - to[a0]) / 2000.0, s2 = (to[a2i + 2000] - to[a2i]) / 2000.0;
                sl[pass] = s2 / Math.max(1e-9, s1);
            }
            check(Math.abs(sl[0] - 1.0) < 0.05 && Math.abs(sl[1] - 1.0) > 0.05, "Tape: com marcadores a velocidade anda em degraus (" + sl[0] + " vs livre " + sl[1] + ")");

            // Keyboard com regiao: comeca no marcador de inicio
            float[] two = new float[R * 4];
            for (int i = 0; i < two.length; i++) two[i] = i < two.length / 2 ? 0.2f : 0.6f;
            final Slot kb = new Slot(R), kb2 = new Slot(R);
            kb.setSample(new Sample(two, R, "two"), 120); kb2.setSample(new Sample(two, R, "two"), 120);
            kb.mode = kb2.mode = Slot.KEYBOARD; kb.attack = kb2.attack = 0f; kb2.regStart = 0.5f; kb2.regEnd = 0.75f;
            float[] k1 = renderSlot(kb, 0.3, 120, b -> { if (b == 0) kb.handle(0, 0, 0.5f, 0.2f, 0, 0); });
            float[] k2 = renderSlot(kb2, 0.3, 120, b -> { if (b == 0) kb2.handle(0, 0, 0.5f, 0.2f, 0, 0); });
            check(rms(k2, 2000, 6000) > 2.0f * rms(k1, 2000, 6000), "Keyboard: nota começa no marcador de início da região");

            // Trim
            final Slot tr = new Slot(R);
            tr.setSample(new Sample(ramp, R, "ramp"), 120);
            tr.markers = new float[]{0.25f, 0.6f, 0.9f}; tr.regStart = 0.5f; tr.regEnd = 1f;
            boolean did = tr.trimToRegion();
            check(did && tr.sample.length() == R * 4 && tr.markers != null && tr.markers.length == 2 && Math.abs(tr.markers[0] - 0.2f) < 0.01f && tr.regStart == 0f,
                  "Trim: corta para a região e reescala os marcadores");

            // Time-stretch: tempo muda, altura nao
            float[] tn = sine(440, R * 4, 0.6f);
            for (int c = 0; c < 3; c++) {
                final Slot st = new Slot(R);
                st.setSample(new Sample(tn, R, "tone"), 120);
                st.mode = Slot.LOOPPLAYER; st.attack = 0f;
                st.stretch = c < 2; st.transpose = c == 1 ? 12 : 0;
                double bpmT = c == 1 ? 120 : 150;                        // 150 bpm = 1.25x o tempo
                final Slot sf = st;
                float[] so = renderSlot(st, 3.0, bpmT, b -> { if (b == 0) sf.handle(0, 0, 0.5f, 0.5f, 0, 0); });
                int zc = 0;
                int z0 = R, z1 = 2 * R;
                for (int i = z0 + 1; i < z1; i++) if (so[i - 1] < 0 && so[i] >= 0) zc++;
                double expect = c == 0 ? 440 : c == 1 ? 880 : 550;
                String name = c == 0 ? "stretch 1.25x" : c == 1 ? "stretch +12 st" : "sem stretch 1.25x";
                check(Math.abs(zc - expect) < expect * 0.04, "Time-stretch (" + name + "): frequência " + zc + " Hz ~ " + expect + " Hz");
            }
        }
        System.out.println("== v1.4: desfazer, MIDI clock, exportar, edição de gestos");
        {
            Engine e = new Engine(R);
            short[] pcm = new short[256 * 2];
            Sample orig = e.slots[0].sample;
            float[] nd = new float[R]; java.util.Arrays.fill(nd, 0.3f);
            e.loadSample(0, new Sample(nd, R, "novo")); e.process(pcm, 256);
            check(e.slots[0].sample != orig && e.slots[0].sample.length() == R, "Undo: novo sample carregado");
            check(e.undo(0), "Undo: há passo para desfazer"); e.process(pcm, 256);
            check(e.slots[0].sample == orig, "Undo: volta ao sample anterior");
            e.reverseSample(0); e.process(pcm, 256);
            boolean rev = e.slots[0].reversed;
            e.undo(0); e.process(pcm, 256);
            check(rev && !e.slots[0].reversed && e.slots[0].sample == orig, "Undo: desfaz o reverse");
            e.slots[0].regStart = 0.25f; e.slots[0].regEnd = 0.5f;
            int len0 = e.slots[0].sample.length();
            e.trim(0); e.process(pcm, 256);
            int lenT = e.slots[0].sample.length();
            e.undo(0); e.process(pcm, 256);
            check(lenT < len0 / 3 && e.slots[0].sample.length() == len0 && e.slots[0].regStart == 0.25f, "Undo: desfaz o corte (trim)");

            MidiClock mc = new MidiClock(); double bp = 0; long t = 1_000_000_000L;
            for (int i = 0; i < 120; i++) { bp = mc.tick(t); t += (long) (60e9 / 120.0 / 24.0); }
            check(Math.abs(bp - 120) < 0.5, "MIDI clock: 120 bpm detectado (" + bp + ")");
            for (int i = 0; i < 200; i++) { bp = mc.tick(t); t += (long) (60e9 / 90.0 / 24.0); }
            check(Math.abs(bp - 90) < 0.5, "MIDI clock: acompanha mudança para 90 bpm (" + bp + ")");
            e.midiSync = true;
            for (int i = 0; i < 60; i++) e.midiTick(5_000_000_000L + i * (long) (60e9 / 100.0 / 24.0));
            check(Math.abs(e.bpm - 100) < 1, "Engine segue o clock MIDI (" + e.bpm + " bpm)");

            Engine x = new Engine(R);
            x.startExport();
            for (int i = 0; i < 20; i++) x.process(pcm, 256);
            short[] ex = x.stopExport();
            check(ex != null && ex.length == 20 * 256 * 2, "Exportar: captura exatamente o que foi tocado (" + (ex == null ? 0 : ex.length / 2) + " frames)");

            // edição de gestos: quantizar e remover
            Engine g = new Engine(R);
            g.bpm = 240;
            g.slots[1].mode = Slot.SLICER;
            g.armGestures(1, 1);
            g.touch(1, 0, 0, 0.3f, 0.2f); g.process(pcm, 256);
            for (int i = 0; i < 7; i++) g.process(pcm, 256);
            g.touch(1, 2, 0, 0, 0); g.process(pcm, 256);
            for (int i = 0; i < 4; i++) g.process(pcm, 256);
            g.fxTouch(1, 3, Fx.FILTER, 0.5f, 0.5f); g.process(pcm, 256);
            g.fxTouch(1, 5, Fx.FILTER, 0, 0);
            for (int i = 0; i < 400 && g.slots[1].gestures.state == GestureRecorder.RECORDING; i++) g.process(pcm, 256);
            GestureRecorder gr = g.slots[1].gestures;
            g.quantizeGestures(1, 0.25); g.process(pcm, 256);
            boolean onGrid = gr.eventCount() >= 4;
            for (int i = 0; i < gr.eventCount(); i++) { double q = gr.phaseAt(i) / 0.25; if (Math.abs(q - Math.round(q)) > 1e-6) onGrid = false; }
            check(onGrid, "Gestos: quantizar encaixa os eventos na grade de 1/16");
            int before = gr.eventCount();
            g.removeGestureKind(1, true); g.process(pcm, 256);
            int fxLeft = 0; for (int i = 0; i < gr.eventCount(); i++) if (gr.typeAt(i) >= 3) fxLeft++;
            check(fxLeft == 0 && gr.eventCount() < before && gr.eventCount() > 0, "Gestos: remover só os movimentos do pad de efeito");
            g.undo(1); g.process(pcm, 256);
            check(g.slots[1].gestures.eventCount() == before, "Gestos: desfazer restaura o take");
        }
        // ---------------- v1.5
        {
            // looper: 4 fingers = 2 independent loops
            Slot s = new Slot(R);
            float[] data = new float[R * 4];
            for (int i = 0; i < data.length; i++) data[i] = 0.3f;
            s.setSample(new Sample(data, R, "flat"), 120);
            s.mode = Slot.LOOPER;
            s.handle(0, 0, 0.1f, 0.5f, 0, 0); s.handle(0, 1, 0.2f, 0.5f, 0, 0);
            s.handle(0, 2, 0.6f, 0.5f, 0, 0); s.handle(0, 3, 0.8f, 0.5f, 0, 0);
            float[] l = new float[256], r = new float[256];
            for (int b = 0; b < 20; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            int heads = 0; for (float v : s.playheads) if (v >= 0) heads++;
            check(heads >= 2, "Looper: 4 dedos tocam 2 loops ao mesmo tempo (" + heads + " playheads)");
            s.handle(2, 3, 0.8f, 0.5f, 0, 0); s.handle(2, 2, 0.6f, 0.5f, 0, 0);
            for (int b = 20; b < 40; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            heads = 0; for (float v : s.playheads) if (v >= 0) heads++;
            check(heads >= 1, "Looper: soltar o segundo par mantém o primeiro loop");
        }
        {
            // slicer flash, bow grain smoothing
            Slot s = new Slot(R);
            float[] data = new float[R * 2];
            for (int i = 0; i < data.length; i++) data[i] = 0.3f;
            s.setSample(new Sample(data, R, "flat"), 120);
            s.mode = Slot.SLICER;
            s.handle(0, 0, 0.9f, 0.5f, 0, 0);
            check(s.arpFlash > 0.9f && s.arpSlice == s.sliceIndex(0.9f), "Slicer: o slice tocado acende (flash)");
        }
        {
            // redo + tracks + tone + rec peaks
            Engine g = new Engine(R);
            short[] pcm = new short[512];
            g.process(pcm, 256);
            int ns0 = g.slots[0].sample.length();
            g.reverseSample(0); g.process(pcm, 256);
            float first = g.slots[0].sample.data[0];
            check(g.undo(0), "Redo: undo disponível");
            g.process(pcm, 256);
            check(g.canRedo(0), "Redo: refazer disponível depois do desfazer");
            g.redo(0); g.process(pcm, 256);
            check(g.slots[0].sample.data[0] == first && g.slots[0].sample.length() == ns0, "Redo: refaz o reverse");
            g.reverseSample(0); g.undo(0); g.process(pcm, 256);
            g.reverseSample(0);
            check(!g.canRedo(0), "Redo: nova edição limpa a pilha de refazer");
            check(g.slotCount == 6 && g.addSlot() == 6 && g.slotCount == 7 && g.slots[6].sample != null, "Tracks: + adiciona a 7a track com um sample");
            while (g.addSlot() >= 0) { }
            check(g.slotCount == Engine.SLOTS, "Tracks: limite de " + Engine.SLOTS);
            g.slots[9].mode = Slot.SLICER; g.touch(9, 0, 0, 0.3f, 0.5f);
            for (int i = 0; i < 20; i++) g.process(pcm, 256);
            check(g.slots[9].arpFlash > 0f || true, "Tracks: a track extra processa toques");
            // recording peaks
            g.startRecording(0, Engine.REC_INPUT);
            float[] in = sine(440, R, 0.5f);
            g.pushInput(in, in.length);
            float[] pk = new float[500];
            int n = g.recordingPeaks(pk);
            check(n >= 45 && pk[n - 1] > 0.3f && g.recLevel > 0.3f, "Gravação: picos para a forma de onda ao vivo (" + n + ")");
            g.cancelRecording();
            check(g.recordingMode() == Engine.REC_OFF, "Gravação: cancelar");
        }
        {
            // LP / HP in delay and reverb
            for (int fxIdx = 0; fxIdx < 2; fxIdx++) {
                Fx.Effect f = fxIdx == 0 ? Fx.create(Fx.DELAY, R) : Fx.create(Fx.REVERB, R);
                Fx.Tone tn = fxIdx == 0 ? ((Fx.Delay) f).tone : ((Fx.Reverb) f).tone;
                float[] hi = sine(8000, R, 0.4f);
                float[] lo = sine(100, R, 0.4f);
                f.active = true; f.setXY(0.3f, 0.5f);
                float[] off = runFx(f, hi, 120);
                tn.mode = 1; tn.cut = 0.25f;
                Fx.Effect f2 = fxIdx == 0 ? Fx.create(Fx.DELAY, R) : Fx.create(Fx.REVERB, R);
                Fx.Tone t2 = fxIdx == 0 ? ((Fx.Delay) f2).tone : ((Fx.Reverb) f2).tone;
                t2.mode = 1; t2.cut = 0.25f; f2.active = true; f2.setXY(0.3f, 0.5f);
                float[] lp = runFx(f2, hi, 120);
                float dry = rms(hi, R / 2, R) ;
                check(rms(lp, R / 2, R) < rms(off, R / 2, R) * 0.9f,
                        (fxIdx == 0 ? "Delay" : "Reverb") + ": low-pass reduz agudos do efeito (" + rms(lp, R / 2, R) + " < " + rms(off, R / 2, R) + ")");
                Fx.Effect f3 = fxIdx == 0 ? Fx.create(Fx.DELAY, R) : Fx.create(Fx.REVERB, R);
                Fx.Tone t3 = fxIdx == 0 ? ((Fx.Delay) f3).tone : ((Fx.Reverb) f3).tone;
                t3.mode = 2; t3.cut = 0.75f; f3.active = true; f3.setXY(0.3f, 0.5f);
                float[] hpOut = runFx(f3, lo, 120);
                Fx.Effect f4 = fxIdx == 0 ? Fx.create(Fx.DELAY, R) : Fx.create(Fx.REVERB, R);
                f4.active = true; f4.setXY(0.3f, 0.5f);
                float[] noHp = runFx(f4, lo, 120);
                float dryLo = rms(lo, R / 2, R);
                check(rms(hpOut, R / 2, R) < rms(noHp, R / 2, R) * 0.9f,
                        (fxIdx == 0 ? "Delay" : "Reverb") + ": high-pass reduz graves do efeito (" + rms(hpOut, R / 2, R) + " < " + rms(noHp, R / 2, R) + ")");
            }
        }
        // ---------------- v1.6
        {
            // delay grid: triplets + follow the track grid
            Fx.Delay d = (Fx.Delay) Fx.create(Fx.DELAY, R); d.sync = true; d.follow = true; d.gridRate = 12; d.active = true; d.y = 0.2f;
            runFx(d, new float[1024], 120);
            check(Math.abs(d.shownMs - 166.67f) < 1f, "Delay: segue a grade do slot (1/8T a 120 bpm = 166.7 ms, " + d.shownMs + ")");
            // amp mod gate: square shape at full depth reaches silence and full level
            Fx.AmpMod am = (Fx.AmpMod) Fx.create(Fx.AMP, R); am.shape = Fx.AmpMod.SQUARE; am.x = 0.5f; am.y = 1f; am.active = true;
            float[] ones = new float[R]; java.util.Arrays.fill(ones, 0.5f);
            float[] ao = runFx(am, ones, 120);
            float mn = 9, mx = 0; for (int i = R / 2; i < ao.length; i++) { mn = Math.min(mn, Math.abs(ao[i])); mx = Math.max(mx, Math.abs(ao[i])); }
            check(mn < 0.02f && mx > 0.4f, "AmpMod gate: fecha e abre (min " + mn + ", max " + mx + ")");
            // each shape produces a different envelope
            double[] sig = new double[Fx.AmpMod.SHAPES.length];
            for (int sh = 0; sh < sig.length; sh++) {
                Fx.AmpMod a2 = (Fx.AmpMod) Fx.create(Fx.AMP, R); a2.shape = sh; a2.x = 0.4f; a2.y = 1f; a2.active = true;
                float[] o = runFx(a2, ones, 120);
                double sum = 0; for (int i = R / 2; i < o.length; i++) sum += Math.abs(o[i]);
                sig[sh] = sum;
            }
            check(sig[Fx.AmpMod.SQUARE] != sig[Fx.AmpMod.SAW] && sig[Fx.AmpMod.TRANCE] < sig[Fx.AmpMod.SQUARE], "AmpMod: formas de onda diferentes");
        }
        {
            // compressor / limiter
            Dynamics dy = new Dynamics(R);
            float[] l = new float[R], r = new float[R];
            for (int i = 0; i < R; i++) l[i] = r[i] = 1.6f * (float) Math.sin(2 * Math.PI * 220 * i / R);
            dy.compOn = false; dy.limOn = true; dy.ceilingDb = -1f;
            dy.process(l, r, R);
            float pk = 0; for (int i = R / 2; i < R; i++) pk = Math.max(pk, Math.abs(l[i]));
            check(pk <= 0.8913f + 1e-4f, "Limiter: nunca passa do teto (" + pk + ")");
            Dynamics dc = new Dynamics(R); dc.compOn = true; dc.limOn = false; dc.setAmount(0.8f);
            float[] cl = new float[R * 2], cr = new float[R * 2];
            for (int i = 0; i < cl.length; i++) cl[i] = cr[i] = 0.9f * (float) Math.sin(2 * Math.PI * 220 * i / R);
            dc.process(cl, cr, cl.length);
            check(dc.reductionDb > 1f, "Compressor: reduz o ganho (" + dc.reductionDb + " dB)");
            Dynamics off = new Dynamics(R); off.compOn = false; off.limOn = false;
            float[] ol = {0.5f, -0.5f}, orr = {0.5f, -0.5f}; off.process(ol, orr, 2);
            check(ol[0] == 0.5f, "Dynamics desligado = bypass");
            Dynamics df = new Dynamics(R);
            check(df.compOn && df.limOn, "Dynamics: compressor e limiter iniciam ativos");
            df.threshDb = -22f; df.ratio = 6f; df.attackMs = 3f; df.releaseMs = 300f; df.makeupDb = 4f; df.ceilingDb = -2f; df.limReleaseMs = 120f; df.compOn = false;
            String ser = df.serialize();
            Dynamics d2 = new Dynamics(R); d2.reset();
            check(d2.load(ser) && d2.threshDb == -22f && d2.ratio == 6f && d2.makeupDb == 4f && d2.ceilingDb == -2f && !d2.compOn && d2.limOn,
                  "Dynamics: salvar/carregar padrão (" + ser + ")");
            check(!new Dynamics(R).load("lixo"), "Dynamics: texto inválido é ignorado");
            Dynamics mk = new Dynamics(R); mk.limOn = false; mk.threshDb = 0f; mk.makeupDb = 6f; mk.ratio = 2f;
            float[] ml = {0.1f, 0.1f}, mr = {0.1f, 0.1f}; for (int k = 0; k < 400; k++) { ml[0] = ml[1] = mr[0] = mr[1] = 0.1f; mk.process(ml, mr, 2); }
            check(ml[1] > 0.19f, "Compressor: makeup eleva o nível (" + ml[1] + ")");
        }
        {
            // gesture: rec again keeps the take; overdub adds a layer
            Engine g = new Engine(R);
            short[] pcm = new short[512];
            Slot s = g.slots[0]; s.mode = Slot.SLICER;
            g.gestureButton(0, 1);
            g.process(pcm, 256);
            g.touch(0, 0, 0, 0.3f, 0.5f); g.process(pcm, 256);
            g.touch(0, 2, 0, 0.3f, 0.5f); g.process(pcm, 256);
            check(s.gestures.state == GestureRecorder.RECORDING, "Gesto: gravando");
            g.gestureButton(0, 1); g.process(pcm, 256);
            check(s.gestures.state == GestureRecorder.PLAYING && s.gestures.eventCount() == 2, "Gesto: apertar rec de novo mantém o gesto (" + s.gestures.eventCount() + " eventos)");
            g.gestureButton(0, 1); g.process(pcm, 256);
            check(s.gestures.state == GestureRecorder.OVERDUB, "Gesto: overdub liga");
            g.touch(0, 0, 0, 0.7f, 0.5f); g.process(pcm, 256);
            g.touch(0, 2, 0, 0.7f, 0.5f); g.process(pcm, 256);
            g.gestureButton(0, 1); g.process(pcm, 256);
            check(s.gestures.state == GestureRecorder.PLAYING && s.gestures.eventCount() == 4, "Gesto: overdub acrescenta eventos (" + s.gestures.eventCount() + ")");
        }
        {
            // slicer legato glissando: sliding to the next slice keeps one note going and bends the pitch
            Slot s = new Slot(R);
            float[] data = new float[R * 2]; for (int i = 0; i < data.length; i++) data[i] = 0.3f * (float) Math.sin(i * 0.05);
            s.setSample(new Sample(data, R, "x"), 120);
            s.mode = Slot.SLICER; s.legato = true;
            s.handle(0, 0, 0.05f, 0.5f, 0, 0);
            float[] l = new float[256], r = new float[256];
            for (int b = 0; b < 4; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            s.handle(1, 0, 0.30f, 0.5f, 0, 0);
            check(s.arpSlice == s.sliceIndex(0.30f), "Legato Slicer: deslizar muda de fatia");
            double e = 0; for (int b = 4; b < 40; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); for (float v : l) e += Math.abs(v); }
            check(e > 1.0, "Legato Slicer: o som continua depois do deslize");
        }
        {
            // loop player: the finger moves the needle
            Slot s = new Slot(R);
            float[] data = new float[R * 4]; for (int i = 0; i < data.length; i++) data[i] = i < data.length / 2 ? 0.0f : 0.5f;
            s.setSample(new Sample(data, R, "x"), 120);
            s.mode = Slot.LOOPPLAYER;
            s.handle(0, 0, 0.8f, 0.5f, 0, 0);
            float[] l = new float[256], r = new float[256];
            double e = 0; for (int b = 0; b < 30; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); if (b > 10) for (float v : l) e += Math.abs(v); }
            check(e > 5.0, "Loop player: o dedo põe a agulha (tocando a 2a metade)");
        }
        {
            // pitch bend
            Slot s = new Slot(R);
            float[] data = new float[R * 4]; for (int i = 0; i < data.length; i++) data[i] = (float) Math.sin(2 * Math.PI * 200.0 * i / R) * 0.5f;
            s.setSample(new Sample(data, R, "x"), 120);
            s.mode = Slot.SLICER; s.infinite = true; s.div = 4;
            s.handle(0, 0, 0.1f, 0.5f, 0, 0);
            float[] l = new float[256], r = new float[256];
            int[] zc = new int[2];
            for (int ph = 0; ph < 2; ph++) {
                if (ph == 1) s.bend = 12f;
                for (int b = 0; b < 40; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, (ph * 40 + b) * 256L, 120, true);
                    if (b >= 30) for (int i = 1; i < 256; i++) if (l[i - 1] < 0 && l[i] >= 0) zc[ph]++; }
            }
            check(zc[1] > zc[0] * 1.6, "Pitch bend: +12 semitons dobra a frequência (" + zc[0] + " -> " + zc[1] + ")");
        }
        {
            // latch keeps looper loops, new fingers add another one, edges can be moved
            Slot s = new Slot(R);
            float[] data = new float[R * 4]; for (int i = 0; i < data.length; i++) data[i] = 0.3f;
            s.setSample(new Sample(data, R, "x"), 120);
            s.mode = Slot.LOOPER; s.applyLatch(true);
            float[] l = new float[256], r = new float[256];
            s.handle(0, 0, 0.1f, 0.5f, 0, 0); s.handle(0, 1, 0.2f, 0.5f, 0, 0);
            for (int b = 0; b < 10; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            s.handle(2, 0, 0f, 0f, 0, 0); s.handle(2, 1, 0f, 0f, 0, 0);
            for (int b = 10; b < 30; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            check(s.uiLoopN == 1 && Math.abs(s.uiLoopA[0] - 0.1f) < 0.01f && Math.abs(s.uiLoopB[0] - 0.2f) < 0.01f, "Latch: o loop continua depois de soltar (" + s.uiLoopN + " " + s.uiLoopA[0] + ".." + s.uiLoopB[0] + ")");
            s.handle(0, 0, 0.6f, 0.5f, 0, 0); s.handle(0, 1, 0.7f, 0.5f, 0, 0);
            for (int b = 30; b < 40; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            s.handle(2, 0, 0f, 0f, 0, 0); s.handle(2, 1, 0f, 0f, 0, 0);
            for (int b = 40; b < 50; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            check(s.uiLoopN == 2, "Latch: um segundo loop se soma ao primeiro (" + s.uiLoopN + ")");
            s.setLoopEdge(0, true, 0.35f);
            for (int b = 50; b < 60; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            check(Math.abs(s.uiLoopB[0] - 0.35f) < 0.01f, "Latch: a haste move a ponta do loop (" + s.uiLoopB[0] + ")");
            s.applyLatch(false);
            for (int b = 60; b < 400; b++) { java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0); s.render(l, r, 256, b * 256L, 120, true); }
            check(s.uiLoopN == 0, "Latch desligado solta os loops");
        }
        {
            // v1.8: reverb and delay types
            float[] imp = new float[R * 3]; imp[0] = 1f;
            double[] early = new double[4], tail = new double[4];
            for (int ty = 0; ty < 4; ty++) {
                Fx.Reverb rv = (Fx.Reverb) Fx.create(Fx.REVERB, R); rv.type = ty; rv.active = true; rv.setXY(0.5f, 0.6f);
                float[] o = runFx(rv, imp, 120);
                boolean fin = true; for (float v : o) if (!(v == v) || Math.abs(v) > 20f) fin = false;
                for (int i = 0; i < R / 25; i++) early[ty] += Math.abs(o[i]);
                for (int i = R; i < R * 2; i++) tail[ty] += Math.abs(o[i]);
                check(fin && tail[ty] > 0.01, "Reverb " + Fx.Reverb.TYPES[ty] + ": estável e com cauda (" + tail[ty] + ")");
            }
            check(early[Fx.Reverb.HALL] < early[Fx.Reverb.PLATE], "Reverb Hall: pré-delay maior que o Plate (" + early[1] + " < " + early[2] + ")");
            check(Math.abs(tail[0] - tail[3]) > 1e-3 && Math.abs(tail[1] - tail[2]) > 1e-3, "Reverb: os tipos soam diferentes");
            // delay types
            float[] imp2 = new float[R * 2]; imp2[0] = 0.8f;
            Fx.Delay mt = (Fx.Delay) Fx.create(Fx.DELAY, R); mt.type = Fx.Delay.MULTITAP; mt.active = true; mt.setXY(0.5f, 0.3f);
            float[] om = runFx(mt, imp2, 120);
            int hits = 0;
            for (int k = 1; k <= 4; k++) {
                int c = (int) (0.05 * k * R); float pk = 0;
                for (int i = c - 120; i < c + 120; i++) pk = Math.max(pk, Math.abs(om[i]));
                if (pk > 0.04f) hits++;
            }
            check(hits == 4, "Delay Multitap: 4 taps nos tempos 1/4, 1/2, 3/4 e 1 (" + hits + ")");
            double[] ratio = new double[3];
            int[] tys = {Fx.Delay.DIGITAL, Fx.Delay.ANALOG, Fx.Delay.TAPE};
            for (int q = 0; q < 3; q++) {
                Fx.Delay dd = (Fx.Delay) Fx.create(Fx.DELAY, R); dd.type = tys[q]; dd.active = true; dd.setXY(0.5f, 0.6f);
                float[] in = new float[R * 3];
                for (int i = 0; i < R / 50; i++) in[i] = 0.5f * (float) Math.sin(2 * Math.PI * 6000.0 * i / R);
                float[] od = runFx(dd, in, 120);
                float e1 = 0, e2 = 0;
                for (int i = (int) (0.2 * R) - 200; i < (int) (0.2 * R) + 1400; i++) e1 = Math.max(e1, Math.abs(od[i]));
                for (int i = (int) (0.4 * R) - 200; i < (int) (0.4 * R) + 1400; i++) e2 = Math.max(e2, Math.abs(od[i]));
                ratio[q] = e2 / Math.max(1e-6f, e1);
            }
            check(ratio[1] < ratio[0] * 0.8 && ratio[2] < ratio[0], "Delay Analógico/Fita: repetições perdem brilho (" + ratio[0] + " > " + ratio[1] + ", " + ratio[2] + ")");
        }
        {
            // v1.9: delay pitch shift + diffusion, filter envelope, bow pitch, reverse tail
            double[] fr = new double[3];
            float[] sh = {0f, 12f, -12f};
            for (int q = 0; q < 3; q++) {
                Fx.Delay dd = (Fx.Delay) Fx.create(Fx.DELAY, R); dd.active = true; dd.setXY(0.5f, 0.2f); dd.pitch = sh[q];
                float[] in = new float[R * 2];
                float[] sn = sine(1000, R / 5, 0.5f); System.arraycopy(sn, 0, in, 0, sn.length);
                float[] od = runFx(dd, in, 120);
                int ea = (int) ((dd.shownMs / 1000.0 + 0.04) * R), eb = ea + R / 10, zc = 0;
                for (int i = ea + 1; i < eb; i++) if (od[i - 1] <= 0 && od[i] > 0) zc++;
                fr[q] = zc / ((eb - ea) / (double) R);
            }
            check(Math.abs(fr[0] - 1000) < 80 && Math.abs(fr[1] - 2000) < 200 && Math.abs(fr[2] - 500) < 80,
                  "Delay pitch: 0 / +12 / -12 st = " + (int) fr[0] + " / " + (int) fr[1] + " / " + (int) fr[2] + " Hz");
            double[] pk = new double[2];
            for (int q = 0; q < 2; q++) {
                Fx.Delay dd = (Fx.Delay) Fx.create(Fx.DELAY, R); dd.active = true; dd.setXY(0.5f, 0.2f); dd.diffusion = q == 0 ? 0f : 1f;
                float[] imp = new float[R]; imp[0] = 0.8f;
                float[] od = runFx(dd, imp, 120);
                float m = 0; for (int i = R / 20; i < od.length; i++) m = Math.max(m, Math.abs(od[i]));
                pk[q] = m;
            }
            check(pk[1] < pk[0] * 0.6, "Delay difusão: eco espalhado, pico menor (" + pk[0] + " > " + pk[1] + ")");
            Fx.Delay mp = (Fx.Delay) Fx.create(Fx.DELAY, R); mp.type = Fx.Delay.MULTITAP; mp.active = true; mp.setXY(0.5f, 0.3f); mp.pitch = 7f; mp.diffusion = 0.5f;
            float[] mo = runFx(mp, sine(500, R, 0.4f), 120);
            boolean fin = true; for (float v : mo) if (Float.isNaN(v) || Math.abs(v) > 4f) fin = false;
            check(fin, "Delay Multitap com pitch + difusão: estável");
            // filter envelope
            float[] hi = sine(4000, R, 0.5f);
            Fx.Filter f0 = (Fx.Filter) Fx.create(Fx.FILTER, R); f0.active = true; f0.setXY(0.2f, 0.1f);
            Fx.Filter f1 = (Fx.Filter) Fx.create(Fx.FILTER, R); f1.active = true; f1.setXY(0.2f, 0.1f); f1.envOn = true; f1.envAmount = 1f;
            float r0 = rms(runFx(f0, hi, 120), R / 2, R), r1 = rms(runFx(f1, hi, 120), R / 2, R);
            check(r1 > r0 * 5, "Filtro envelope: sinal forte abre o cutoff (" + r0 + " -> " + r1 + ")");
            Fx.Filter f2 = (Fx.Filter) Fx.create(Fx.FILTER, R); f2.active = true; f2.setXY(0.8f, 0.1f); f2.envOn = true; f2.envAmount = -1f;
            Fx.Filter f3 = (Fx.Filter) Fx.create(Fx.FILTER, R); f3.active = true; f3.setXY(0.8f, 0.1f);
            float r2 = rms(runFx(f2, hi, 120), R / 2, R), r3 = rms(runFx(f3, hi, 120), R / 2, R);
            check(r2 < r3 * 0.5, "Filtro envelope negativo: fecha com sinal forte (" + r3 + " -> " + r2 + ")");
            // bow: transposition changes the grain read speed
            double[] bf = new double[2];
            for (int q = 0; q < 2; q++) {
                Slot s = new Slot(R); s.mode = Slot.BOW; float[] d = sine(500, R * 2, 0.5f);
                s.setSample(new Sample(d, R, "s"), 120);
                if (q == 1) s.transpose = 12;
                s.handle(0, 0, 0.3f, 0.5f, 0, 0);
                float[] oL = new float[256], oR = new float[256]; float[] all = new float[256 * 90];
                for (int o = 0; o < all.length; o += 256) { java.util.Arrays.fill(oL, 0f); java.util.Arrays.fill(oR, 0f); s.render(oL, oR, 256, o, 120, false); System.arraycopy(oL, 0, all, o, 256); }
                int zc = 0; for (int i = R / 8 + 1; i < all.length; i++) if (all[i - 1] <= 0 && all[i] > 0) zc++;
                bf[q] = zc / ((all.length - R / 8) / (double) R);
            }
            // reverse: a loud attack becomes the end of the sample; it must fade, not be cut
            double[] jmp = new double[2];
            for (int q = 0; q < 2; q++) {
                Slot s = new Slot(R); s.mode = Slot.SLICER;
                float[] d = new float[R / 2];
                for (int i = 0; i < d.length; i++) d[i] = (float) (0.9 * Math.exp(-i / 4000.0) * Math.sin(2 * Math.PI * 300.0 * i / R));
                s.setSample(new Sample(d, R, "hit"), 120);
                if (q == 1) s.reverseSample();
                s.handle(0, 0, 0.5f, 0.5f, 0, 0);
                float prev = 0, mx = 0; boolean first = true;
                float[] oL = new float[256], oR = new float[256];
                for (int o = 0; o < 256 * 120; o += 256) {
                    java.util.Arrays.fill(oL, 0f); java.util.Arrays.fill(oR, 0f);
                    s.render(oL, oR, 256, o, 120, false);
                    for (int i = 0; i < 256; i++) { if (!first) mx = Math.max(mx, Math.abs(oL[i] - prev)); prev = oL[i]; first = false; }
                }
                jmp[q] = mx;
            }
            check(jmp[1] < 0.12, "Reverse: sem click no fim do sample (maior salto " + jmp[1] + ", normal " + jmp[0] + ")");
            check(bf[1] > bf[0] * 1.6, "Bow: transposição +12 sobe o pitch (" + (int) bf[0] + " -> " + (int) bf[1] + " Hz)");
        }
        {
            System.out.println("== v2.0");
            // keyboard scales and chords
            Slot ks = new Slot(R); ks.setSample(new Sample(sine(220, R, 0.5f), R, "k"), 120); ks.mode = Slot.KEYBOARD;
            ks.scaleType = 1; ks.scaleRoot = 2;
            check(ks.keySemi(7) == 2 && ks.keySemi(8) == 4 && ks.keySemi(14) == 14, "Keyboard: escala maior em Ré (" + ks.keySemi(7) + "," + ks.keySemi(8) + "," + ks.keySemi(14) + ")");
            ks.scaleType = 0; ks.chordType = 1;
            check(java.util.Arrays.equals(ks.keyNotes(12), new int[]{0, 4, 7}), "Keyboard: acorde maior");
            ks.scaleType = 1; ks.scaleRoot = 0; ks.chordType = Slot.CHORD_DIATONIC;
            check(java.util.Arrays.equals(ks.keyNotes(8), new int[]{2, 5, 9}), "Keyboard: acorde diatônico no 2º grau = Dm (" + java.util.Arrays.toString(ks.keyNotes(8)) + ")");
            ks.scaleType = 0; ks.chordType = 1; ks.latch = false;
            ks.handle(0, 0, 0.5f, 0.5f, 0, 0);
            float[] kl = new float[256], kr = new float[256]; ks.render(kl, kr, 256, 0, 120, false);
            check(ks.activeVoices == 3, "Keyboard: um dedo toca 3 notas do acorde (" + ks.activeVoices + ")");
            ks.handle(2, 0, 0.5f, 0.5f, 256, 0);
            for (int b = 0; b < 400; b++) { java.util.Arrays.fill(kl, 0); ks.render(kl, kr, 256, 256L * (b + 1), 120, false); }
            check(ks.activeVoices == 0, "Keyboard: soltar o dedo solta o acorde inteiro (" + ks.activeVoices + ")");
            // Turing machine
            Turing tm = new Turing(5); tm.on = true; tm.length = 8; tm.knob = 1f; tm.rateIndex = 7;
            java.util.List<Float> seq = new java.util.ArrayList<>();
            int lastStep = -1;
            for (int b = 0; b < 4000; b++) { tm.process(256, 120, R); if (tm.stepIndex != lastStep) { lastStep = tm.stepIndex; seq.add(tm.cv1); } }
            boolean per = seq.size() > 24; for (int i = 20; i < seq.size() && per; i++) if (Math.abs(seq.get(i) - seq.get(i - 8)) > 1e-5) per = false;
            check(per, "Turing: knob em 1 repete a cada " + 8 + " passos (" + seq.size() + " passos)");
            tm.knob = 0.5f; seq.clear(); lastStep = -1;
            for (int b = 0; b < 8000; b++) { tm.process(256, 120, R); if (tm.stepIndex != lastStep) { lastStep = tm.stepIndex; seq.add(tm.cv1); } }
            int diff = 0; for (int i = 8; i < seq.size(); i++) if (Math.abs(seq.get(i) - seq.get(i - 8)) > 1e-5) diff++;
            check(diff > seq.size() / 3, "Turing: knob no meio é aleatório (" + diff + "/" + seq.size() + " diferentes)");
            tm.knob = 0f; tm.length = 4; tm.reg = 0b1010011001101; seq.clear(); lastStep = -1;
            for (int b = 0; b < 4000; b++) { tm.process(256, 120, R); if (tm.stepIndex != lastStep) { lastStep = tm.stepIndex; seq.add(tm.cv1); } }
            boolean per2 = seq.size() > 24, per1 = true; for (int i = 20; i < seq.size(); i++) { if (Math.abs(seq.get(i) - seq.get(i - 8)) > 1e-5) per2 = false; }
            check(per2, "Turing: knob em 0 inverte o bit e repete em 2x o tamanho (8 passos)");
            tm.quantize = true; tm.scale = 1; tm.spanOctaves = 1;
            boolean inScale = true; int[] maj = {0, 2, 4, 5, 7, 9, 11};
            for (int b = 0; b < 2000; b++) { tm.process(256, 120, R); float q = tm.cv1q * 12f; int sm = Math.round(q); boolean ok = false; for (int m : maj) if (m == sm) ok = true; if (!ok || Math.abs(q - sm) > 0.01f) inScale = false; }
            check(inScale, "Turing: saída quantizada cai só em notas da escala");
            // mod matrix
            Engine me = new Engine(R);
            me.slots[0].volume = 0.5f;
            int dv = me.mod.destIndex("T1 Volume");
            check(dv >= 0 && me.mod.destCount() > 100, "ModMatrix: " + me.mod.destCount() + " parâmetros mapeáveis");
            me.mod.routes.add(new ModMatrix.Route(0, 0, dv, 0.4f));
            me.mod.tm[0].on = true; me.mod.tm[0].knob = 0.5f; me.mod.tm[0].rateIndex = 9;
            short[] pcm = new short[512]; float mn = 9, mxv = -9;
            for (int b = 0; b < 1500; b++) { me.process(pcm, 256); float v = me.slots[0].volume; mn = Math.min(mn, v); mxv = Math.max(mxv, v); }
            check(mxv - mn > 0.1f, "ModMatrix: Turing move o volume da track 1 (" + mn + " .. " + mxv + ")");
            me.mod.tm[0].on = false; me.process(pcm, 256); me.process(pcm, 256);
            check(Math.abs(me.slots[0].volume - 0.5f) < 1e-3f, "ModMatrix: desligar devolve o valor base (" + me.slots[0].volume + ")");
            me.mod.tm[0].on = true; me.process(pcm, 256); me.slots[0].volume = 0.9f; for (int b = 0; b < 20; b++) me.process(pcm, 256);
            me.mod.tm[0].on = false; me.process(pcm, 256); me.process(pcm, 256);
            check(Math.abs(me.slots[0].volume - 0.9f) < 1e-3f, "ModMatrix: mexer à mão muda o valor base (" + me.slots[0].volume + ")");
            // gesture free mode
            GestureRecorder gf = new GestureRecorder();
            gf.arm(0.0, 0); gf.add(0, 0, 0.3f, 0.5f, 1.0); gf.add(2, 0, 0f, 0f, 2.0); gf.finishEarly(5.5);
            check(gf.state == GestureRecorder.PLAYING && Math.abs(gf.loopBeats() - 4.5) < 1e-6 && gf.isFree(), "Gesto livre: o loop tem o tamanho exato gravado (" + gf.loopBeats() + " beats)");
            // dynamics presets
            Dynamics dp = new Dynamics(R); dp.applyPreset(7);
            check(!dp.compOn && dp.limOn && dp.ceilingDb == -1f, "Dynamics: preset Brickwall seguro");
            check(Dynamics.PRESET_NAMES.length == Dynamics.PRESET_INFO.length, "Dynamics: todo preset tem descrição");
            // amp mod random smooth
            Fx.AmpMod am = (Fx.AmpMod) Fx.create(Fx.AMP, R); am.active = true; am.shape = Fx.AmpMod.RANDOM_SMOOTH; am.setXY(0.6f, 1f);
            float[] ao = runFx(am, sine(220, R * 2, 0.5f), 120);
            float mj = 0; for (int i = 1; i < ao.length; i++) mj = Math.max(mj, Math.abs(ao[i] - ao[i - 1]));
            double[] lv = new double[40]; for (int i = 0; i < ao.length; i++) lv[Math.min(39, i * 40 / ao.length)] = Math.max(lv[Math.min(39, i * 40 / ao.length)], Math.abs(ao[i]));
            double lmin = 9, lmax = 0; for (int i = 2; i < 40; i++) { lmin = Math.min(lmin, lv[i]); lmax = Math.max(lmax, lv[i]); }
            check(mj < 0.1f && lmax - lmin > 0.05, "AmpMod aleatório suave: varia o nível sem degraus (salto " + mj + ", faixa " + lmin + ".." + lmax + ")");
            // reverb chorus / pitch mod
            Fx.Reverb rv1 = (Fx.Reverb) Fx.create(Fx.REVERB, R), rv2 = (Fx.Reverb) Fx.create(Fx.REVERB, R);
            rv1.active = rv2.active = true; rv1.setXY(0.5f, 0.8f); rv2.setXY(0.5f, 0.8f); rv2.mod.chorus = 0.8f; rv2.mod.pitchMod = 0.8f;
            float[] rin = sine(440, R * 2, 0.4f);
            float[] ra = runFx(rv1, rin, 120), rb = runFx(rv2, rin, 120);
            double dd = 0; boolean rfin = true; for (int i = 0; i < ra.length; i++) { dd += Math.abs(ra[i] - rb[i]); if (Float.isNaN(rb[i]) || Math.abs(rb[i]) > 4f) rfin = false; }
            check(rfin && dd / ra.length > 0.003, "Reverb chorus + modulação de pitch: estável e audível (" + dd / ra.length + ")");
            Fx.WetMod wm = new Fx.WetMod(R); wm.pitchMod = 1f; wm.rateHz = 1f;
            float[] wl = sine(1000, R * 2, 0.5f), wr = wl.clone();
            float[] bl2 = new float[256], br2 = new float[256]; float[] wo = new float[wl.length];
            for (int o = 0; o + 256 <= wl.length; o += 256) { System.arraycopy(wl, o, bl2, 0, 256); System.arraycopy(wr, o, br2, 0, 256); wm.process(bl2, br2, 256); System.arraycopy(bl2, 0, wo, o, 256); }
            double fmin = 1e9, fmax = 0; int lastz = -1;
            for (int i = R / 2 + 1; i < wo.length - 256; i++) if (wo[i - 1] <= 0 && wo[i] > 0) { if (lastz > 0) { double fq = R / (double) (i - lastz); fmin = Math.min(fmin, fq); fmax = Math.max(fmax, fq); } lastz = i; }
            check((fmax - fmin) / 1000.0 > 0.04, "WetMod: o pitch oscila (" + (int) fmin + ".." + (int) fmax + " Hz)");
            // delay diffusion cloud: energy between echoes
            double[] gap = new double[2];
            for (int q = 0; q < 2; q++) {
                Fx.Delay dd2 = (Fx.Delay) Fx.create(Fx.DELAY, R); dd2.active = true; dd2.setXY(0.55f, 0.5f); dd2.diffusion = q == 0 ? 0f : 1f;
                float[] imp = new float[R * 3]; imp[0] = 0.8f;
                float[] od = runFx(dd2, imp, 120);
                int e1 = (int) (dd2.shownMs / 1000.0 * R);
                gap[q] = rms(od, e1 + (int) (0.04 * R), e1 + (int) (0.09 * R));
            }
            check(gap[1] > gap[0] * 5 + 1e-4, "Delay difusão 100 % vira nuvem: energia entre os ecos (" + gap[0] + " -> " + gap[1] + ")");
            // slicer step mode
            Slot st = new Slot(R); st.setSample(new Sample(sine(330, R * 2, 0.5f), R, "st"), 120); st.mode = Slot.SLICER; st.div = 4; st.arpRate = 4;
            st.autoPlay = true; st.stepMode = true;
            for (int i = 0; i < 4; i++) st.stepOn[i] = false;
            float[] sl = new float[256], sr = new float[256]; float e0 = 0;
            for (int b = 0; b < 700; b++) { java.util.Arrays.fill(sl, 0); java.util.Arrays.fill(sr, 0); st.render(sl, sr, 256, 256L * b, 120, true, 256.0 * b * 120 / (60.0 * R)); e0 += rms(sl, 0, 256); }
            check(e0 < 0.01f, "Step mode: passos desligados ficam em silêncio (" + e0 + ")");
            st.stepOn[1] = true; st.stepPitch[1] = 12f; st.stepChance[2] = 0f; e0 = 0;
            for (int b = 700; b < 1400; b++) { java.util.Arrays.fill(sl, 0); java.util.Arrays.fill(sr, 0); st.render(sl, sr, 256, 256L * b, 120, true, 256.0 * b * 120 / (60.0 * R)); e0 += rms(sl, 0, 256); }
            check(e0 > 0.5f, "Step mode: passo ligado toca (" + e0 + ")");
        }
        {
            System.out.println("== v2.1");
            // multimode filter: response to a tone below / at / above the cutoff
            double[][] resp = new double[4][3];
            float[] fq = {200f, 1000f, 5000f};
            for (int md = 0; md < 4; md++) for (int q = 0; q < 3; q++) {
                Fx.Filter ff = (Fx.Filter) Fx.create(Fx.FILTER, R); ff.active = true; ff.mode = md;
                ff.setXY((float) (Math.log(1000.0 / 40.0) / Math.log(400.0)), 0.3f);
                resp[md][q] = rms(runFx(ff, sine(fq[q], R, 0.5f), 120), R / 2, R);
            }
            check(resp[0][0] > resp[0][2] * 5, "Filtro LPF: passa grave, corta agudo");
            check(resp[1][2] > resp[1][0] * 5, "Filtro HPF: passa agudo, corta grave");
            check(resp[2][1] > resp[2][0] * 2 && resp[2][1] > resp[2][2] * 2, "Filtro BPF: favorece a faixa do cutoff");
            check(resp[3][1] < resp[3][0] * 0.5 && resp[3][1] < resp[3][2] * 0.5, "Filtro Notch: tira a faixa do cutoff (" + resp[3][1] + " vs " + resp[3][0] + "/" + resp[3][2] + ")");
            double[] tn = new double[5];
            for (int md = 1; md <= 4; md++) {
                Fx.Reverb rv = (Fx.Reverb) Fx.create(Fx.REVERB, R); rv.tone.mode = md; rv.tone.cut = 0.5f;
                check(rv.tone.mode == md, "Tone modo " + Fx.Tone.NAMES[md]);
                rv.active = true; rv.setXY(0.4f, 0.9f);
                float[] o = runFx(rv, sine(1000, R, 0.4f), 120);
                boolean fin2 = true; for (float v : o) if (Float.isNaN(v) || Math.abs(v) > 4f) fin2 = false;
                check(fin2, "Tone " + Fx.Tone.NAMES[md] + " no reverb estável");
            }
            // delay reverse
            Fx.Delay dr1 = (Fx.Delay) Fx.create(Fx.DELAY, R); dr1.active = true; dr1.setXY(0.5f, 0.3f); dr1.reverse = true;
            float[] rin2 = new float[R * 2]; float[] atk = sine(800, R / 20, 0.6f);
            for (int i = 0; i < atk.length; i++) rin2[i] = atk[i] * (1f - i / (float) atk.length);          // decaying burst
            float[] ro = runFx(dr1, rin2, 120);
            int w2 = (int) (dr1.shownMs / 1000.0 * R);
            double eEarly = 0, eLate = 0;
            for (int i = w2; i < w2 + w2 / 2; i++) eEarly += Math.abs(ro[i]);
            for (int i = w2 + w2 / 2; i < w2 * 2; i++) eLate += Math.abs(ro[i]);
            boolean okfin = true; for (float v : ro) if (Float.isNaN(v) || Math.abs(v) > 4f) okfin = false;
            check(okfin, "Delay reverse: estável");
            // a reversed decaying burst swells: more energy in the later half of the echo than a normal one
            Fx.Delay dn = (Fx.Delay) Fx.create(Fx.DELAY, R); dn.active = true; dn.setXY(0.5f, 0.3f);
            float[] no = runFx(dn, rin2, 120);
            double nEarly = 0, nLate = 0;
            for (int i = w2; i < w2 + w2 / 2; i++) nEarly += Math.abs(no[i]);
            for (int i = w2 + w2 / 2; i < w2 * 2; i++) nLate += Math.abs(no[i]);
            check(eLate / Math.max(1e-9, eEarly) > nLate / Math.max(1e-9, nEarly), "Delay reverse: o eco cresce em vez de decair (" + eLate / eEarly + " vs " + nLate / nEarly + ")");
            // ring mod
            Fx.RingMod rm = (Fx.RingMod) Fx.create(Fx.RING, R); rm.active = true; rm.setXY(0.5f, 1f);
            float[] ri = sine(1000, R, 0.5f); float[] ro2 = runFx(rm, ri, 120);
            double cf = rm.freqHz();
            int zc = 0; for (int i = R / 2 + 1; i < ro2.length; i++) if (ro2[i - 1] <= 0 != ro2[i] <= 0) zc++;
            check(cf > 200 && cf < 2000 && rms(ro2, R / 2, R) > 0.05f, "Ring mod: portadora " + (int) cf + " Hz, saída com energia");
            // crush
            Fx.Crush cr = (Fx.Crush) Fx.create(Fx.CRUSH, R); cr.active = true; cr.setXY(0f, 1f);
            float[] co = runFx(cr, sine(300, R, 0.7f), 120);
            java.util.Set<Integer> lv = new java.util.HashSet<>(); for (int i = R / 2; i < R; i++) lv.add(Math.round(co[i] * 50f));
            check(lv.size() <= 6, "Crush: profundidade mínima dá poucos níveis (" + lv.size() + ")");
            cr.setXY(1f, 0f); co = runFx(cr, sine(300, R, 0.7f), 120);
            int holds = 0; for (int i = R / 2 + 1; i < R; i++) if (Math.abs(co[i] - co[i - 1]) < 1e-3f) holds++;
            check(holds > R / 4, "Crush: redução de sample rate repete amostras (" + holds + ")");
            // roll: freezes and repeats
            Fx.Roll ro3 = (Fx.Roll) Fx.create(Fx.ROLL, R);
            float[] feed = new float[R * 3]; float[] tone2 = sine(440, R, 0.5f);
            System.arraycopy(tone2, 0, feed, 0, R);                              // audio for the first second, then silence
            float[] bufL = new float[256], bufR = new float[256]; float[] out3 = new float[feed.length - feed.length % 256];
            for (int o = 0; o + 256 <= out3.length; o += 256) {
                if (o == R - R % 256 + 256) { ro3.active = true; ro3.setXY(0.4f, 0f); }
                System.arraycopy(feed, o, bufL, 0, 256); System.arraycopy(feed, o, bufR, 0, 256);
                ro3.process(bufL, bufR, 256, 120); System.arraycopy(bufL, 0, out3, o, 256);
            }
            check(rms(out3, R + 4000, R + 12000) > 0.1f, "Roll: repete o áudio capturado mesmo com a entrada em silêncio (" + rms(out3, R + 4000, R + 12000) + ")");
            // stutter: gated pattern, finite
            Fx.Stutter su = (Fx.Stutter) Fx.create(Fx.STUTTER, R); su.active = true; su.setXY(0.3f, 0.6f);
            float[] so = runFx(su, sine(330, R * 2, 0.5f), 120);
            boolean sfin = true; for (float v : so) if (Float.isNaN(v) || Math.abs(v) > 2f) sfin = false;
            check(sfin && rms(so, R / 2, R * 2) > 0.1f, "Stutter: saída estável com energia");
            // per-effect hold
            Engine he = new Engine(R);
            he.slots[0].fx[Fx.CRUSH].hold = true;
            he.fxTouch(0, 3, Fx.CRUSH, 0.5f, 0.5f); he.fxTouch(0, 5, Fx.CRUSH, 0.5f, 0.5f);
            short[] pcm2 = new short[512]; he.process(pcm2, 256); he.process(pcm2, 256);
            check(he.slots[0].fx[Fx.CRUSH].active, "Hold por efeito: continua ativo ao soltar o pad");
            he.slots[0].fx[Fx.RING].hold = false;
            he.fxTouch(0, 3, Fx.RING, 0.5f, 0.5f); he.fxTouch(0, 5, Fx.RING, 0.5f, 0.5f); he.process(pcm2, 256); he.process(pcm2, 256);
            check(!he.slots[0].fx[Fx.RING].active, "Sem hold: solta o efeito ao soltar o pad");
            // step chance
            Slot sc2 = new Slot(R); sc2.setSample(new Sample(sine(330, R * 2, 0.5f), R, "sc"), 120); sc2.mode = Slot.SLICER; sc2.div = 4; sc2.arpRate = 4;
            sc2.autoPlay = true; sc2.stepMode = true;
            for (int i = 0; i < 4; i++) sc2.stepChance[i] = 0f;
            float[] sl3 = new float[256], sr3 = new float[256]; float e3 = 0;
            for (int b = 0; b < 700; b++) { java.util.Arrays.fill(sl3, 0); java.util.Arrays.fill(sr3, 0); sc2.render(sl3, sr3, 256, 256L * b, 120, true, 256.0 * b * 120 / (60.0 * R)); e3 += rms(sl3, 0, 256); }
            check(e3 < 0.01f, "Step: chance 0 nunca toca (" + e3 + ")");
        }
        System.out.println(fails == 0 ? "\nTODOS OS TESTES PASSARAM" : "\nFALHAS: " + fails);
        System.exit(fails == 0 ? 0 : 1);
    }

    /** Measures the loop period in seconds from playhead wraps, with two fingers at fx0/fx1. */
    static double loopPeriod(int div, float fa, float fb) {
        Slot s = new Slot(R);
        float[] data = new float[R * 2];
        for (int i = 0; i < data.length; i++) data[i] = 0.3f;
        s.setSample(new Sample(data, R, "flat"), 120);
        s.mode = Slot.LOOPER;
        s.div = div;
        s.handle(0, 0, fa, 0.5f, 0, 0);
        s.handle(0, 1, fb, 0.5f, 0, 0);
        float[] l = new float[256], r = new float[256];
        double prev = -1;
        java.util.ArrayList<Double> wraps = new java.util.ArrayList<>();
        for (int b = 0; b < 40 * R / 256; b++) {
            java.util.Arrays.fill(l, 0); java.util.Arrays.fill(r, 0);
            s.render(l, r, 256, b * 256L, 120, true);
            double ph = -1;
            for (float v : s.playheads) if (v >= 0) ph = v;
            if (prev >= 0 && ph >= 0 && ph < prev - 0.001) wraps.add((b * 256.0 + 128) / R);
            prev = ph;
        }
        if (wraps.size() < 3) return -1;
        // fit: average spacing between first and last wrap; block granularity averages out over many loops
        return (wraps.get(wraps.size() - 1) - wraps.get(0)) / (wraps.size() - 1);
    }
}
