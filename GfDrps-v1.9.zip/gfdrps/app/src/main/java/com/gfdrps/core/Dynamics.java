package com.gfdrps.core;

/** Master bus dynamics: a gentle stereo-linked compressor followed by a look-ahead peak limiter. */
public final class Dynamics {
    /** Both stages start enabled. */
    public volatile boolean compOn = true, limOn = true;
    /** Compressor: threshold dB (-40..0), ratio (1.2..20), attack ms (0.5..100), release ms (20..1000), makeup dB (0..18). */
    public volatile float threshDb = -14f, ratio = 2.5f, attackMs = 10f, releaseMs = 150f, makeupDb = 1.5f;
    /** Limiter: ceiling in dB (-12..0) and release ms (10..500). */
    public volatile float ceilingDb = -0.5f, limReleaseMs = 80f;
    /** One-knob macro (0..1) that moves threshold and ratio together. */
    public void setAmount(float a) {
        a = Math.max(0f, Math.min(1f, a));
        threshDb = -6f - 24f * a; ratio = 2f + 6f * a;
    }
    public float amount() { return Math.max(0f, Math.min(1f, (-6f - threshDb) / 24f)); }
    public void reset() {
        compOn = true; limOn = true; threshDb = -14f; ratio = 2.5f; attackMs = 10f; releaseMs = 150f; makeupDb = 1.5f;
        ceilingDb = -0.5f; limReleaseMs = 80f;
    }
    /** Compact text form, used for the "save as default" preference and projects. */
    public String serialize() {
        return (compOn ? 1 : 0) + "," + (limOn ? 1 : 0) + "," + threshDb + "," + ratio + "," + attackMs + "," + releaseMs + ","
                + makeupDb + "," + ceilingDb + "," + limReleaseMs;
    }
    public boolean load(String t) {
        if (t == null) return false;
        try {
            String[] p = t.split(",");
            if (p.length < 9) return false;
            boolean c = p[0].equals("1"), l = p[1].equals("1");
            float a = Float.parseFloat(p[2]), b = Float.parseFloat(p[3]), c2 = Float.parseFloat(p[4]), d = Float.parseFloat(p[5]),
                  e = Float.parseFloat(p[6]), f = Float.parseFloat(p[7]), g = Float.parseFloat(p[8]);
            compOn = c; limOn = l; threshDb = a; ratio = b; attackMs = c2; releaseMs = d; makeupDb = e; ceilingDb = f; limReleaseMs = g;
            return true;
        } catch (RuntimeException ex) { return false; }
    }
    /** Gain reduction shown by the UI in dB (0 = none). */
    public volatile float reductionDb;

    private final int rate;
    private float env, cgain = 1f, lgain = 1f;
    private final int look;
    private final float[] dl, dr;
    private int wp;

    public Dynamics(int rate) {
        this.rate = rate;
        look = Math.max(8, rate / 1000 * 2);               // 2 ms look-ahead
        dl = new float[look + 1]; dr = new float[look + 1];
    }

    public void process(float[] l, float[] r, int n) {
        final boolean comp = compOn, lim = limOn;
        if (!comp && !lim) { reductionDb = 0f; return; }
        final float thr = Math.max(-40f, Math.min(0f, threshDb)), ratio = Math.max(1.2f, Math.min(20f, this.ratio));
        final float atk = 1f - (float) Math.exp(-1.0 / (Math.max(0.5f, attackMs) * 0.001 * rate));
        final float rel = 1f - (float) Math.exp(-1.0 / (Math.max(20f, releaseMs) * 0.001 * rate));
        final float makeup = comp ? (float) Math.pow(10.0, Math.max(0f, Math.min(18f, makeupDb)) / 20.0) : 1f;
        final float ceil = (float) Math.pow(10.0, Math.min(0f, Math.max(-12f, ceilingDb)) / 20.0);
        final float latk = 1f - (float) Math.exp(-1.0 / (0.0007 * rate)), lrel = 1f - (float) Math.exp(-1.0 / (Math.max(10f, limReleaseMs) * 0.001 * rate));
        float minG = 1f;
        for (int i = 0; i < n; i++) {
            float a = l[i], b = r[i];
            if (comp) {
                float pk = Math.max(Math.abs(a), Math.abs(b));
                env += (pk - env) * (pk > env ? atk : rel);
                float db = 20f * (float) Math.log10(Math.max(1e-6f, env));
                float over = db - thr, red = 0f;
                if (over > 3f) red = over * (1f - 1f / ratio);                     // above the knee
                else if (over > -3f) { float t = over + 3f; red = (t * t / 12f) * (1f - 1f / ratio); }   // soft knee, 6 dB wide
                float tg = (float) Math.pow(10.0, -red / 20.0) * makeup;
                cgain += (tg - cgain) * 0.02f;
                a *= cgain; b *= cgain;
                minG = Math.min(minG, cgain / makeup);
            }
            if (lim) {
                dl[wp] = a; dr[wp] = b;
                float need = Math.max(Math.abs(a), Math.abs(b));
                float tg = need > ceil ? ceil / need : 1f;
                if (tg < lgain) lgain += (tg - lgain) * latk * 6f; else lgain += (tg - lgain) * lrel;
                if (lgain > 1f) lgain = 1f;
                if (++wp > look) wp = 0;
                float oa = dl[wp] * lgain, ob = dr[wp] * lgain;                    // delayed by the look-ahead
                if (oa > ceil) oa = ceil; else if (oa < -ceil) oa = -ceil;
                if (ob > ceil) ob = ceil; else if (ob < -ceil) ob = -ceil;
                l[i] = oa; r[i] = ob;
                minG = Math.min(minG, lgain);
            } else { l[i] = a; r[i] = b; }
        }
        reductionDb = minG >= 0.999f ? 0f : -20f * (float) Math.log10(minG);
    }
}
