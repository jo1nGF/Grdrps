package com.gfdrps.android;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Dialog in the look of the app: dark panel, square icon tiles and slider rows (instead of the system list dialogs).
 * Build it with a function that fills the rows; {@link #refresh()} runs that function again after a tile changed something,
 * so toggles show their new state.
 */
final class Panel {
    private final Activity act;
    private final Dialog dialog;
    private final LinearLayout body;
    private final String title;
    private Runnable builder;
    private LinearLayout row;
    private final float d;

    Panel(Activity a, String title) {
        act = a; this.title = title;
        d = a.getResources().getDisplayMetrics().density;
        dialog = new Dialog(a);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final int maxH = Math.round(a.getResources().getDisplayMetrics().heightPixels * 0.92f);
        ScrollView sv = new ScrollView(a) {          // as tall as its content, but never taller than the screen (then it scrolls)
            @Override protected void onMeasure(int w, int h) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST));
            }
        };
        sv.setBackgroundColor(Theme.PANEL);
        body = new LinearLayout(a);
        body.setOrientation(LinearLayout.VERTICAL);
        int pd = Math.round(10 * d);
        body.setPadding(pd, pd, pd, pd);
        sv.addView(body, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dialog.setContentView(sv);
    }

    /** Fill the panel: called now and again on every refresh(). */
    Panel build(Runnable b) { builder = b; refresh(); return this; }

    void refresh() {
        body.removeAllViews(); row = null;
        header();
        if (builder != null) builder.run();
    }

    void show() {
        dialog.show();
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int sw = act.getResources().getDisplayMetrics().widthPixels, sh = act.getResources().getDisplayMetrics().heightPixels;
            w.setLayout(Math.min(Math.round(sw * 0.72f), Math.round(560 * d)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.CENTER);
        }
    }

    void dismiss() { dialog.dismiss(); }

    private void header() {
        LinearLayout h = new LinearLayout(act);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = new TextView(act);
        t.setText(title); t.setTextColor(Theme.TEXT); t.setTextSize(16f);
        t.setTypeface(android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL));
        h.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Widgets.Tile x = new Widgets.Tile(act).icon(Theme.I_CLEAR).accent(Theme.DIM).onClick(dialog::dismiss);
        h.addView(x, new LinearLayout.LayoutParams(Math.round(44 * d), Math.round(40 * d)));
        body.addView(h, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** Starts a new row of tiles. */
    Panel row() {
        row = new LinearLayout(act);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.round(54 * d));
        lp.topMargin = Math.round(4 * d);
        body.addView(row, lp);
        return this;
    }

    private LinearLayout.LayoutParams cell() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        lp.rightMargin = Math.round(3 * d);
        return lp;
    }

    /** A tile with an icon (icon >= 0) or a short text, optionally lit (on) and with a caption under... (text). */
    Panel tile(int icon, String text, boolean on, int accent, final Runnable action) {
        if (row == null) row();
        Widgets.Tile t = new Widgets.Tile(act);
        if (icon >= 0) t.icon(icon); else t.text(text).textScale(0.3f);
        t.accent(accent);
        t.setOn(on);
        t.onClick(() -> { if (action != null) action.run(); refresh(); });
        row.addView(t, cell());
        return this;
    }

    /** Same, but a wide tile (weight 2) with an icon and a label — for toggles with a name. */
    Panel wide(int icon, String text, boolean on, int accent, final Runnable action) {
        if (row == null) row();
        LinearLayout box = new LinearLayout(act);
        box.setOrientation(LinearLayout.HORIZONTAL);
        Widgets.Tile t = new Widgets.Tile(act).icon(icon).accent(accent);
        t.setOn(on);
        t.onClick(() -> { if (action != null) action.run(); refresh(); });
        box.addView(t, new LinearLayout.LayoutParams(Math.round(54 * d), ViewGroup.LayoutParams.MATCH_PARENT));
        TextView tv = new TextView(act);
        tv.setText(text); tv.setTextColor(on ? Theme.TEXT : Theme.DIM); tv.setTextSize(13f); tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setPadding(Math.round(8 * d), 0, 0, 0);
        tv.setOnClickListener(v -> { if (action != null) action.run(); refresh(); });
        box.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        LinearLayout.LayoutParams lp = cell(); lp.weight = 2f;
        row.addView(box, lp);
        return this;
    }

    interface Fmt { String text(float v); }
    interface Change { void on(float v); }

    /** Horizontal slider row: identifying icon, slider (value 0..1) and the value written out. */
    Panel slider(int icon, int accent, float value, final Fmt fmt, final Change change) {
        row = null;
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        Widgets.Tile ic = new Widgets.Tile(act).icon(icon).accent(accent);
        ic.setClickable(false);
        r.addView(ic, new LinearLayout.LayoutParams(Math.round(54 * d), ViewGroup.LayoutParams.MATCH_PARENT));
        final TextView val = new TextView(act);
        Widgets.Slider sl = new Widgets.Slider(act, false).accent(accent).onValue(v -> { change.on(v); val.setText(fmt.text(v)); });
        sl.set(value);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        sp.leftMargin = Math.round(3 * d);
        r.addView(sl, sp);
        val.setText(fmt.text(value)); val.setTextColor(Theme.TEXT); val.setTextSize(13f); val.setGravity(Gravity.CENTER);
        r.addView(val, new LinearLayout.LayoutParams(Math.round(86 * d), ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.round(54 * d));
        lp.topMargin = Math.round(4 * d);
        body.addView(r, lp);
        return this;
    }

    Panel label(String text) {
        row = null;
        TextView tv = new TextView(act);
        tv.setText(text); tv.setTextColor(Theme.DIM); tv.setTextSize(12f);
        tv.setPadding(0, Math.round(8 * d), 0, Math.round(2 * d));
        body.addView(tv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return this;
    }

    /** A custom view row (e.g. a text field). */
    Panel view(View v, int heightDp) {
        row = null;
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.round(heightDp * d));
        lp.topMargin = Math.round(4 * d);
        body.addView(v, lp);
        return this;
    }
}
