package com.gfdrps.core;

/** The five per-slot effects (also reused for the master bus). All take x,y in 0..1 from an XY pad. */
public final class Fx {
    private Fx() {}

    public static final int DIST = 0, FILTER = 1, AMP = 2, DELAY = 3, REVERB = 4, COUNT = 5;
    public static final String[] NAMES = {"Distortion", "Filter", "Amp Mod", "Delay", "Reverb"};
    static final int MAXN = 512;

    /**
     * Insert effects implement apply(); the base class cross-fades them in and out in ~10 ms
     * so switching a pad on or off never clicks. Delay and Reverb override process() because
     * their tails must keep ringing after the pad is released.
     */
    public abstract static class Effect {
        public volatile float x = 0.5f, y = 0.5f;
        public volatile boolean active = false;
        protected final int rate;
        protected float mix;
        private final float[] dl = new float[MAXN], dr = new float[MAXN];

        protected Effect(int rate) { this.rate = rate; }

        protected void apply(float[] l, float[] r, int n, double bpm) {}
        protected void reset() {}

        public void process(float[] l, float[] r, int n, double bpm) {
            if (!active && mix <= 0.0005f) {
                if (mix != 0f) { mix = 0f; reset(); }
                return;
            }
            System.arraycopy(l, 0, dl, 0, n);
            System.arraycopy(r, 0, dr, 0, n);
            apply(l, r, n, bpm);
            final float t = active ? 1f : 0f;
            for (int i = 0; i < n; i++) {
                mix += (t - mix) * 0.003f;
                l[i] = dl[i] + (l[i] - dl[i]) * mix;
                r[i] = dr[i] + (r[i] - dr[i]) * mix;
            }
        }

        public void setXY(float nx, float ny) {
            x = Math.max(0f, Math.min(1f, nx));
            y = Math.max(0f, Math.min(1f, ny));
        }
    }

    /** The LP/HP tone of a Delay or Reverb; null for the other effects. */
    /** Note name for "notes per bar": 4 = 1/4, 6 = 1/4T, 1 = 1 bar. */
    public static String noteName(int r) { return r == 1 ? "1 bar" : (r % 3 == 0 ? "1/" + (r * 2 / 3) + "T" : "1/" + r); }

    public static Tone toneOf(Effect e) {
        if (e instanceof Delay) return ((Delay) e).tone;
        if (e instanceof Reverb) return ((Reverb) e).tone;
        return null;
    }

    public static Effect create(int type, int rate) {
        switch (type) {
            case DIST: return new Distortion(rate);
            case FILTER: return new Filter(rate);
            case AMP: return new AmpMod(rate);
            case DELAY: return new Delay(rate);
            default: return new Reverb(rate);
        }
    }

    /** x = drive, y = tone. */
    public static final class Distortion extends Effect {
        private float lpL, lpR;
        public Distortion(int rate) { super(rate); }
        @Override protected void reset() { lpL = lpR = 0f; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            float drive = 1f + x * 24f;
            float comp = 1f / (float) Math.tanh(drive * 0.5f + 0.5f);
            float a = 0.08f + y * 0.9f;
            for (int i = 0; i < n; i++) {
                float sl = (float) Math.tanh(l[i] * drive) * comp * 0.7f;
                float sr = (float) Math.tanh(r[i] * drive) * comp * 0.7f;
                lpL += a * (sl - lpL);
                lpR += a * (sr - lpR);
                l[i] = lpL; r[i] = lpR;
            }
        }
    }

    /**
     * Resonant state-variable filter. x = cutoff (40 Hz..16 kHz, log), y = resonance. Low-pass or high-pass.
     * Envelope mode: an envelope follower on the signal's own waveform moves the cutoff (auto-wah / "envelope filter").
     * envAmount > 0 opens the filter on loud parts, < 0 closes it; envRange is how many octaves it can travel.
     */
    public static final class Filter extends Effect {
        public volatile boolean highPass = false;
        public volatile boolean envOn = false;
        public volatile float envAmount = 0.7f, envAttackMs = 5f, envReleaseMs = 120f, envSens = 0.5f;
        public static final float ENV_OCTAVES = 6f;
        /** Last envelope value (0..1) and the cutoff it produced, for the UI. */
        public volatile float envLevel;
        private float s1L, s2L, s1R, s2R, envF;
        public Filter(int rate) { super(rate); }
        /** Damping used by the filter (2 = no resonance, 0.08 = strong); the pad uses it to draw the response. */
        public float damping() { return 2f - 1.92f * y; }
        public double cutoffHz() { return Math.min(40.0 * Math.pow(400.0, x), rate * 0.45); }
        /** Cutoff after the envelope has moved it. */
        public double modulatedHz(float env) {
            double hz = cutoffHz() * Math.pow(2.0, envAmount * env * ENV_OCTAVES);
            return Math.max(20.0, Math.min(rate * 0.45, hz));
        }
        @Override protected void reset() { s1L = s2L = s1R = s2R = 0f; envF = 0f; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final boolean hp = highPass, em = envOn;
            final float k = damping();
            final float atk = 1f - (float) Math.exp(-1.0 / (Math.max(0.5f, envAttackMs) * 0.001 * rate));
            final float rel = 1f - (float) Math.exp(-1.0 / (Math.max(5f, envReleaseMs) * 0.001 * rate));
            final float gain = 1f + 9f * envSens;
            float g = (float) Math.tan(Math.PI * cutoffHz() / rate);
            float a1 = 1f / (1f + g * (g + k)), a2 = g * a1, a3 = g * a2;
            for (int i = 0; i < n; i++) {
                if (em) {
                    float pk = Math.max(Math.abs(l[i]), Math.abs(r[i])) * gain;
                    envF += (pk - envF) * (pk > envF ? atk : rel);
                    if ((i & 7) == 0) {                                  // coefficients every 8 samples is plenty
                        float e = Math.min(1f, envF);
                        g = (float) Math.tan(Math.PI * modulatedHz(e) / rate);
                        a1 = 1f / (1f + g * (g + k)); a2 = g * a1; a3 = g * a2;
                    }
                }
                float v0 = l[i];
                float v3 = v0 - s2L;
                float v1 = a1 * s1L + a2 * v3;
                float v2 = s2L + a2 * s1L + a3 * v3;
                s1L = 2 * v1 - s1L; s2L = 2 * v2 - s2L;
                l[i] = hp ? v0 - k * v1 - v2 : v2;
                v0 = r[i];
                v3 = v0 - s2R;
                v1 = a1 * s1R + a2 * v3;
                v2 = s2R + a2 * s1R + a3 * v3;
                s1R = 2 * v1 - s1R; s2R = 2 * v2 - s2R;
                r[i] = hp ? v0 - k * v1 - v2 : v2;
            }
            envLevel = Math.min(1f, envF);
            if (Float.isNaN(s1L) || Float.isNaN(s2L) || Float.isNaN(s1R) || Float.isNaN(s2R)
                    || Math.abs(s1L) > 1e6f || Math.abs(s1R) > 1e6f) { s1L = s2L = s1R = s2R = 0f; }
        }
    }

    /**
     * Amp mod / gate. x = rate (0.5..20 Hz, or a note length of the tempo with sync), y = depth (0 = nothing, 1 = full gate).
     * The waveform decides how the level opens and closes: sine, square gate, saw down (plucks), ramp up (swells), triangle,
     * trance (short 25 % pulses) and random steps.
     */
    public static final class AmpMod extends Effect {
        public static final int SINE = 0, SQUARE = 1, SAW = 2, RAMP = 3, TRI = 4, TRANCE = 5, RANDOM = 6;
        public static final String[] SHAPES = {"Seno", "Gate", "Serra ↓", "Rampa ↑", "Triângulo", "Trance", "Aleatório"};
        public volatile int shape = SQUARE;
        /** true = the rate follows the project tempo (x picks the note length). */
        public volatile boolean sync = false;
        public static final int[] SYNC_RATES = {1, 2, 4, 6, 8, 12, 16, 24, 32};      // notes per bar
        private double ph;                                    // 0..1
        private float cur = 1f, rnd = 1f;
        private final java.util.Random rng = new java.util.Random(7);
        public AmpMod(int rate) { super(rate); }
        public static int syncIndex(double x) { return Math.min(SYNC_RATES.length - 1, (int) (Math.max(0.0, x) * SYNC_RATES.length)); }
        public static int syncRate(double x) { return SYNC_RATES[syncIndex(x)]; }
        private float wave(double p) {                        // 1 = open, 0 = closed
            switch (shape) {
                case SQUARE: return p < 0.5 ? 1f : 0f;
                case SAW: return (float) (1.0 - p);
                case RAMP: return (float) p;
                case TRI: return (float) (p < 0.5 ? p * 2 : 2 - p * 2);
                case TRANCE: return p < 0.25 ? 1f : 0f;
                case RANDOM: return rnd;
                default: return 0.5f + 0.5f * (float) Math.cos(2 * Math.PI * p);
            }
        }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            double f = sync ? (Math.max(30.0, bpm) / 60.0) * (syncRate(x) / 4.0) : 0.5 * Math.pow(40.0, x);
            double inc = f / rate;
            // sharp shapes get a ~1.5 ms edge so a gate never clicks
            final float slew = (shape == SQUARE || shape == TRANCE || shape == RANDOM || shape == SAW) ? 0.02f : 1f;
            final float depth = y;
            for (int i = 0; i < n; i++) {
                ph += inc;
                if (ph >= 1.0) { ph -= 1.0; if (shape == RANDOM) rnd = rng.nextInt(3) == 0 ? 0f : (0.4f + 0.6f * rng.nextFloat()); }
                float w = wave(ph);
                cur += (w - cur) * slew;
                float m = 1f - depth * (1f - cur);
                l[i] *= m; r[i] *= m;
            }
        }
    }

    /** State variable filter used as the optional low-pass / high-pass on a delay's or reverb's wet signal. */
    public static final class Tone {
        /** 0 = off, 1 = low-pass, 2 = high-pass. */
        public volatile int mode = 0;
        /** 0..1 position on a 40 Hz .. 18 kHz exponential scale. */
        public volatile float cut = 0.5f;
        private float s1, s2, g = 0.1f;
        private final int rate;
        public Tone(int rate) { this.rate = rate; }
        public static double hz(float c, int rate) { return Math.min(40.0 * Math.pow(450.0, Math.max(0f, Math.min(1f, c))), rate * 0.45); }
        public double cutoffHz() { return hz(cut, rate); }
        public static final String[] NAMES = {"OFF", "LP", "HP"};
        /** Call once per block: recomputes the coefficient from the (smoothed) cutoff. */
        void block() {
            float gt = (float) Math.tan(Math.PI * cutoffHz() / rate);
            g += (gt - g) * 0.5f;
        }
        float run(float v0) {
            int m = mode;
            if (m == 0) { s1 = s2 = 0f; return v0; }
            final float k = 1.0f;
            float a1 = 1f / (1f + g * (g + k)), a2 = g * a1, a3 = g * a2;
            float v3 = v0 - s2;
            float v1 = a1 * s1 + a2 * v3;
            float v2 = s2 + a2 * s1 + a3 * v3;
            s1 = 2 * v1 - s1; s2 = 2 * v2 - s2;
            if (!(s1 == s1) || !(s2 == s2) || Math.abs(s1) > 1e6f) { s1 = s2 = 0f; return 0f; }
            return m == 1 ? v2 : v0 - k * v1 - v2;
        }
        void clear() { s1 = s2 = 0f; }
    }

    /** Feedback delay. x = time (10 ms..4 s in whole ms, or a tempo-synced note length with sync), y = feedback. Short times make comb filters; long times ping-pong. */
    public static final class Delay extends Effect {
        public static final double MIN_MS = 10.0, MAX_MS = 4000.0;
        /** Note lengths in beats for sync mode (1/32 .. 1 bar, straight and dotted). */
        /** Same note grid as the arpeggiator / quantize / slices (notes per bar, shortest first), straight and triplets. */
        public static final int[] DIV_RATES = {64, 48, 32, 24, 16, 12, 8, 6, 4, 3, 2, 1};
        public static final double[] DIV = new double[DIV_RATES.length];
        public static final String[] DIV_NAMES = new String[DIV_RATES.length];
        static {
            for (int i = 0; i < DIV_RATES.length; i++) {
                int r = DIV_RATES[i];
                DIV[i] = 4.0 / r;
                DIV_NAMES[i] = r % 3 == 0 ? "1/" + (r * 2 / 3) + "T" : (r == 1 ? "1 bar" : "1/" + r);
            }
        }
        /** When set (and sync is on) the delay follows the track's grid (its arp rate / quantize value) instead of the pad's x. */
        public volatile boolean follow = false;
        public volatile int gridRate = 0;
        /** true = x picks a note length locked to the project tempo; false = x is free time in milliseconds. */
        public volatile boolean sync = false;
        /** Delay time currently used, in ms (for the UI). */
        public volatile float shownMs = 250f;
        public static final int DIGITAL = 0, ANALOG = 1, TAPE = 2, MULTITAP = 3;
        public static final String[] TYPES = {"Digital", "Analógico", "Fita", "Multitap"};
        /** Digital: clean repeats. Analógico: each repeat darker and softer (bucket-brigade). Fita: saturation, band-limited, wow and flutter. Multitap: four taps with their own level and stereo position. */
        public volatile int type = DIGITAL;
        /** Pitch of the echoes in semitones (-12..+12). It sits inside the feedback loop, so every repeat climbs / falls another step. */
        public volatile float pitch = 0f;
        /** Diffusion 0..1: smears the echoes with all-pass diffusers (0 = crisp repeats, 1 = washed, cloud-like). */
        public volatile float diffusion = 0f;
        private static final class PShift {
            final float[] b = new float[8192]; int w; double ph;
            float run(float in, double ratio, int win) {
                b[w] = in; w = (w + 1) & 8191;
                ph += (1.0 - ratio) / win;
                ph -= Math.floor(ph);
                float out = 0f;
                for (int t = 0; t < 2; t++) {
                    double p = ph + 0.5 * t; if (p >= 1.0) p -= 1.0;
                    double rp = w - 1 - p * win; if (rp < 0) rp += 8192;
                    int i0 = (int) rp; float f = (float) (rp - i0);
                    float v = b[i0 & 8191] + (b[(i0 + 1) & 8191] - b[i0 & 8191]) * f;
                    float sn = (float) Math.sin(Math.PI * p);
                    out += v * sn * sn;
                }
                return out;
            }
            void clear() { java.util.Arrays.fill(b, 0f); }
        }
        private static final class AP {
            final float[] b; int w;
            AP(int len) { b = new float[Math.max(2, len)]; }
            float run(float x, float g) {
                float d = b[w];
                float v = x - g * d;
                b[w] = v; if (++w >= b.length) w = 0;
                return d + g * v;
            }
        }
        private final PShift psL = new PShift(), psR = new PShift(), psF = new PShift();
        private final AP[] dfL = new AP[4], dfR = new AP[4];
        private static final int[] DF_LEN = {142, 107, 379, 277};
        private float aL1, aL2, aR1, aR2, hL, hR;          // feedback colour filters
        private double wowPh, flutPh;
        private final java.util.Random nz = new java.util.Random(11);
        private float flutNoise;
        private static final float[] TAP_F = {0.25f, 0.5f, 0.75f, 1f}, TAP_G = {0.5f, 0.65f, 0.8f, 1f}, TAP_P = {-0.8f, 0.5f, -0.3f, 0.8f};
        /** Optional low-pass / high-pass on the echoes (also inside the feedback loop, so repeats get darker or thinner). */
        public final Tone tone;
        private final Tone toneR;
        private final float[] bl, br;
        private int w;
        private float cur;
        public Delay(int rate) {
            super(rate);
            tone = new Tone(rate); toneR = new Tone(rate);
            for (int k = 0; k < 4; k++) {
                dfL[k] = new AP((int) Math.round(DF_LEN[k] * rate / 29761.0));
                dfR[k] = new AP((int) Math.round(DF_LEN[k] * rate / 29761.0 * 1.13) + 3);
            }
            int len = (int) (rate * (MAX_MS / 1000.0)) + 64;
            bl = new float[len];
            br = new float[len];
        }
        /** x (0..1) to milliseconds: exponential 10 ms .. 4000 ms, whole milliseconds (1 ms steps on the short side). */
        public static double msForX(double x) {
            double ms = MIN_MS * Math.pow(MAX_MS / MIN_MS, Math.max(0.0, Math.min(1.0, x)));
            return Math.round(ms);
        }
        public static int divIndex(double x) { return Math.min(DIV.length - 1, (int) (Math.max(0.0, x) * DIV.length)); }

        @Override public void process(float[] l, float[] r, int n, double bpm) {
            double ms;
            if (sync && follow && gridRate > 0) ms = (4.0 / gridRate) * 60000.0 / Math.max(30.0, bpm);
            else if (sync) ms = DIV[divIndex(x)] * 60000.0 / Math.max(30.0, bpm);
            else ms = msForX(x);
            ms = Math.max(MIN_MS, Math.min(MAX_MS, ms));
            shownMs = (float) ms;
            float target = (float) Math.min(ms * 0.001 * rate, bl.length - 3);
            if (cur == 0f) cur = target;
            final float slew = 0.0012f;                         // time changes glide (tape-style), never click
            // short times: straight feedback = a comb filter / metallic echo; longer times: ping-pong between L and R
            final float pp = (float) Math.max(0.0, Math.min(1.0, (ms - 60.0) / 90.0));
            float fb = (0.1f + 0.85f * y) * (active ? 1f : 0.55f);
            tone.block(); toneR.mode = tone.mode; toneR.cut = tone.cut; toneR.block();
            final int ty = type;
            final float kA = 1f - (float) Math.exp(-2 * Math.PI * (ty == TAPE ? 4200.0 : 2400.0) / rate);
            final float kH = 1f - (float) Math.exp(-2 * Math.PI * 130.0 / rate);
            final double wowInc = 0.55 / rate, flutInc = 6.8 / rate;
            final float semis = Math.max(-12f, Math.min(12f, pitch));
            final boolean shift = Math.abs(semis) > 0.01f;
            final double pr = Math.pow(2.0, semis / 12.0);
            final int pwin = (int) (0.06 * rate);
            final float dif = Math.max(0f, Math.min(1f, diffusion));
            final float dg = 0.3f + 0.42f * dif;
            for (int i = 0; i < n; i++) {
                cur += (target - cur) * slew;
                float modS = 0f;
                if (ty == TAPE) {
                    wowPh += wowInc; if (wowPh > 1) wowPh -= 1; flutPh += flutInc; if (flutPh > 1) flutPh -= 1;
                    if ((i & 63) == 0) flutNoise += (nz.nextFloat() * 2f - 1f - flutNoise) * 0.3f;
                    modS = (float) (Math.sin(2 * Math.PI * wowPh) * 0.0010 + Math.sin(2 * Math.PI * flutPh) * 0.00012 * (1 + flutNoise)) * rate;
                } else if (ty == ANALOG) {
                    wowPh += 0.8 / rate; if (wowPh > 1) wowPh -= 1;
                    modS = (float) (Math.sin(2 * Math.PI * wowPh) * 0.00025) * rate;      // faint bucket-brigade shimmer
                }
                float dly = Math.max(1f, Math.min(bl.length - 3, cur + modS));
                float rp = w - dly;
                while (rp < 0) rp += bl.length;
                int i0 = (int) rp;
                int i1 = i0 + 1 >= bl.length ? 0 : i0 + 1;
                float f = rp - i0;
                float inL = active ? l[i] : 0f;
                float inR = active ? r[i] : 0f;
                if (ty == MULTITAP) {
                    float oL = 0f, oR = 0f, last = 0f;
                    for (int k = 0; k < 4; k++) {
                        float rk = w - Math.max(1f, Math.min(bl.length - 3, dly * TAP_F[k]));
                        while (rk < 0) rk += bl.length;
                        int a0 = (int) rk, a1 = a0 + 1 >= bl.length ? 0 : a0 + 1;
                        float v = (bl[a0] + (bl[a1] - bl[a0]) * (rk - a0)) * TAP_G[k];
                        float pn = TAP_P[k];
                        oL += v * (pn <= 0 ? 1f : 1f - pn); oR += v * (pn >= 0 ? 1f : 1f + pn);
                        if (k == 3) last = v;
                    }
                    if (shift) { oL = psL.run(oL, pr, pwin); oR = psR.run(oR, pr, pwin); last = psF.run(last, pr, pwin); }
                    if (dif > 0.001f) {
                        float xl = oL, xr = oR;
                        for (int k = 0; k < 4; k++) { xl = dfL[k].run(xl, dg); xr = dfR[k].run(xr, dg); }
                        oL += (xl - oL) * dif; oR += (xr - oR) * dif;
                    }
                    oL = tone.run(oL); oR = toneR.run(oR);
                    bl[w] = clip((inL + inR) * 0.5f + last * fb * 0.9f);
                    if (++w >= bl.length) w = 0;
                    l[i] += oL * 0.7f; r[i] += oR * 0.7f;
                    continue;
                }
                float dl = bl[i0] + (bl[i1] - bl[i0]) * f;
                float dr = br[i0] + (br[i1] - br[i0]) * f;
                if (shift) { dl = psL.run(dl, pr, pwin); dr = psR.run(dr, pr, pwin); }
                if (dif > 0.001f) {
                    float xl = dl, xr = dr;
                    for (int k = 0; k < 4; k++) { xl = dfL[k].run(xl, dg); xr = dfR[k].run(xr, dg); }
                    dl += (xl - dl) * dif; dr += (xr - dr) * dif;
                }
                dl = tone.run(dl); dr = toneR.run(dr);
                float fl = dl, fr = dr;
                if (ty == ANALOG) {                       // every trip through the loop loses brightness and clarity
                    aL1 += kA * (fl - aL1); aL2 += kA * (aL1 - aL2); fl = aL2;
                    aR1 += kA * (fr - aR1); aR2 += kA * (aR1 - aR2); fr = aR2;
                } else if (ty == TAPE) {                  // band-limited and saturated, like tape
                    aL1 += kA * (fl - aL1); fl = aL1; hL += kH * (fl - hL); fl = sat(fl - hL);
                    aR1 += kA * (fr - aR1); fr = aR1; hR += kH * (fr - hR); fr = sat(fr - hR);
                }
                bl[w] = clip(inL + (fl * (1f - pp) + fr * pp) * fb);
                br[w] = clip(inR + (fr * (1f - pp) + fl * pp) * fb);
                if (++w >= bl.length) w = 0;
                l[i] += dl * 0.8f;
                r[i] += dr * 0.8f;
            }
        }
        private static float sat(float v) { return (float) Math.tanh(v * 1.4) / 1.4f; }
        private static float clip(float v) { return v > 1f ? 1f : (v < -1f ? -1f : v); }
    }

    /**
     * "Cloud" reverb: a Dattorro-style plate. The input goes through a pre-delay and four dense
     * diffusers into a figure-eight tank of two cross-coupled branches, each with a slowly
     * modulated all-pass, a darkening low-pass and a second diffuser. The modulation and the
     * all-pass diffusion keep the tail smooth and free of ringing/pitched resonances, and the
     * output is taken from 14 taps spread over both branches for a wide, decorrelated stereo image.
     *
     * x = decay time (0.6 s .. 14 s), y = wet level. It only listens while the pad is active; after
     * release the tail rings out naturally (at most ~2.5 s) and then goes completely silent.
     */
    public static final class Reverb extends Effect {
        public static final int CLOUD = 0, HALL = 1, PLATE = 2, SPRING = 3;
        public static final String[] TYPES = {"Cloud", "Hall", "Plate", "Spring"};
        /** Room model: Cloud (soft, lush), Hall (big space, long pre-delay and tail), Plate (dense, bright, fast attack), Spring (springy "boing" of an amp). */
        public volatile int type = CLOUD;
        // per type: shortest RT60, range (x24 etc.), pre-delay s, damping, input bandwidth, tail cap s, modulation depth of the diffusers, wet gain
        private static final float[][] TP = {
                {0.6f, 24f, 0.022f, 0.50f, 0.80f, 2.5f, 0.70f, 1.25f},
                {1.2f, 12f, 0.048f, 0.36f, 0.70f, 4.5f, 0.60f, 1.10f},
                {0.4f, 10f, 0.003f, 0.92f, 0.97f, 2.0f, 0.70f, 1.20f},
                {0.5f, 8f, 0.000f, 0.50f, 0.80f, 2.5f, 0.70f, 1.00f}};
        // spring: a chain of all-passes (the dispersion that makes the "chirp") inside a short feedback loop, one spring per channel
        private final Line[] spApL = new Line[6], spApR = new Line[6];
        private final Line spLoopL, spLoopR;
        private float spLpL, spLpR;
        /** Optional low-pass / high-pass on the wet signal. */
        public final Tone tone, toneR;
        // all lengths in samples at 29761 Hz (Dattorro's reference rate), scaled to the engine rate
        private static final double REF = 29761.0;
        private static final int[] IN_AP = {142, 107, 379, 277};
        private static final float[] IN_G = {0.75f, 0.75f, 0.625f, 0.625f};

        private static final class Line {
            final float[] b; int w;
            Line(int len) { b = new float[Math.max(4, len)]; }
            /** Oldest sample: the output of a delay of b.length samples. Call push() right after. */
            float oldest() { return b[w]; }
            void push(float v) { b[w] = v; if (++w >= b.length) w = 0; }
            /** Sample written `t` samples ago (0 = most recent). */
            float tap(int t) {
                int i = w - 1 - Math.min(t, b.length - 1);
                if (i < 0) i += b.length;
                return b[i];
            }
            void clear() { java.util.Arrays.fill(b, 0f); w = 0; }
        }

        private final Line[] inAp = new Line[4];
        private final Line pre;
        private final Line apL, apR;          // modulated decay diffusers
        private final Line d1L, d1R;          // first delays
        private final Line ap2L, ap2R;        // second diffusers
        private final Line d2L, d2R;          // second delays
        private final int[] tapL = new int[7], tapR = new int[7];
        private final float modDepth;
        private final int apLBase, apRBase;
        private double lfoL, lfoR, lfo2L, lfo2R;
        private final double lfoIncL, lfoIncR, lfo2IncL, lfo2IncR;
        private final int ap2LBase, ap2RBase;
        private final float mod2Depth;
        private float lpIn, lpL, lpR, dcIn;
        private float rt60 = 2f, wet = 0f, decay = 0.5f;
        private boolean clean = true;
        private final float loopSeconds;

        private static int sc(int v, double k) { return Math.max(2, (int) Math.round(v * k)); }

        public Reverb(int rate) {
            super(rate);
            tone = new Tone(rate); toneR = new Tone(rate);
            double k = rate / REF;
            for (int i = 0; i < 4; i++) inAp[i] = new Line(sc(IN_AP[i], k));
            pre = new Line(Math.max(8, (int) (0.06 * rate)) + 8);
            double[] spMs = {1.1, 1.6, 2.3, 3.1, 4.1, 5.3};
            for (int i = 0; i < 6; i++) { spApL[i] = new Line((int) Math.round(spMs[i] * 0.001 * rate)); spApR[i] = new Line((int) Math.round(spMs[i] * 0.93 * 0.001 * rate)); }
            spLoopL = new Line((int) (0.033 * rate)); spLoopR = new Line((int) (0.0413 * rate));
            modDepth = (float) (14 * k);
            apLBase = sc(672, k); apRBase = sc(908, k);
            apL = new Line(apLBase + (int) modDepth + 4);
            apR = new Line(apRBase + (int) modDepth + 4);
            d1L = new Line(sc(4453, k)); d1R = new Line(sc(4217, k));
            mod2Depth = (float) (10 * k);
            ap2LBase = sc(1800, k); ap2RBase = sc(2656, k);
            ap2L = new Line(ap2LBase + (int) mod2Depth + 4); ap2R = new Line(ap2RBase + (int) mod2Depth + 4);
            d2L = new Line(sc(3720, k)); d2R = new Line(sc(3163, k));
            // output taps (Dattorro): read inside the opposite/own branch
            int[] tl = {266, 2974, 1913, 1996, 1990, 187, 1066};
            int[] tr = {353, 3627, 1228, 2673, 2111, 335, 121};
            for (int i = 0; i < 7; i++) { tapL[i] = sc(tl[i], k); tapR[i] = sc(tr[i], k); }
            lfoIncL = 2 * Math.PI * 0.43 / rate;
            lfoIncR = 2 * Math.PI * 0.61 / rate;
            lfo2IncL = 2 * Math.PI * 0.29 / rate;
            lfo2IncR = 2 * Math.PI * 0.37 / rate;
            lfoR = 1.9; lfo2L = 0.7; lfo2R = 3.4;
            loopSeconds = (float) ((672 + 4453 + 1800 + 3720 + 908 + 4217 + 2656 + 3163) / REF);
        }

        private void clear() {
            for (Line l : inAp) l.clear();
            for (Line q : spApL) q.clear(); for (Line q : spApR) q.clear(); spLoopL.clear(); spLoopR.clear(); spLpL = spLpR = 0f;
            pre.clear(); apL.clear(); apR.clear(); d1L.clear(); d1R.clear();
            ap2L.clear(); ap2R.clear(); d2L.clear(); d2R.clear();
            lpIn = lpL = lpR = dcIn = 0f; wet = 0f;
            tone.clear(); toneR.clear();
            clean = true;
        }

        private static float frac(Line l, float d) {
            // fractional read, d samples behind the newest sample
            int i0 = (int) d;
            float f = d - i0;
            float a = l.tap(i0), b = l.tap(i0 + 1);
            return a + (b - a) * f;
        }

        private void springBlock(float[] l, float[] r, int n) {
            // feedback so the ring dies in about rt60: -60 dB over rt60 seconds, one trip = the loop delay
            final float fbL = (float) Math.min(0.94, Math.pow(10.0, -3.0 * (spLoopL.b.length / (double) rate) / Math.max(0.2, rt60)));
            final float fbR = (float) Math.min(0.94, Math.pow(10.0, -3.0 * (spLoopR.b.length / (double) rate) / Math.max(0.2, rt60)));
            final float kLp = 1f - (float) Math.exp(-2 * Math.PI * 3200.0 / rate);
            final float wetT = active ? (float) (1.0 * Math.pow(y, 1.2)) : 0f;
            final float wetFall = (float) Math.exp(-9.2 / (Math.min(2.5f, Math.max(0.5f, rt60)) * rate));
            final float g = 0.62f;
            for (int i = 0; i < n; i++) {
                if (active) wet += (wetT - wet) * 0.002f; else wet *= wetFall;
                float in = active ? (l[i] + r[i]) * 0.5f : 0f;
                float hp = in - dcIn; dcIn += 0.003f * hp; in = hp;
                for (int ch = 0; ch < 2; ch++) {
                    Line[] ap = ch == 0 ? spApL : spApR;
                    Line loop = ch == 0 ? spLoopL : spLoopR;
                    float s = in + (ch == 0 ? fbL : fbR) * loop.oldest();
                    for (int a = 0; a < 6; a++) {
                        float d = ap[a].oldest(), v = s - g * d;
                        ap[a].push(v);
                        s = g * v + d;
                    }
                    float lp = ch == 0 ? spLpL : spLpR;
                    lp += kLp * (s - lp);
                    lp = lp / (1f + 0.4f * Math.abs(lp));                       // the spring tank is slightly non-linear
                    if (ch == 0) spLpL = lp; else spLpR = lp;
                    loop.push(lp);
                    float o = (ch == 0 ? toneApply(lp, true) : toneApply(lp, false)) * wet * 0.9f;
                    if (ch == 0) l[i] += o; else r[i] += o;
                }
            }
            if (!(spLpL == spLpL) || !(spLpR == spLpR) || Math.abs(spLpL) > 1e4f || Math.abs(spLpR) > 1e4f) clear();
        }
        private float toneApply(float v, boolean left) { return left ? tone.run(v) : toneR.run(v); }

        @Override public void process(float[] l, float[] r, int n, double bpm) {
            if (!active && wet < 1e-4f) {
                if (!clean) clear();
                return;
            }
            clean = false;
            tone.block(); toneR.mode = tone.mode; toneR.cut = tone.cut; toneR.block();
            final float[] tp = TP[Math.max(0, Math.min(3, type))];
            if (active) {
                float rtT = tp[0] * (float) Math.pow(tp[1], x);
                rt60 += (rtT - rt60) * 0.05f;
            }
            final int preN = Math.max(1, (int) (tp[2] * rate));
            // calibrated so the measured RT60 matches the requested one
            decay = (float) Math.min(0.985, Math.pow(10.0, -3.0 * loopSeconds / (4.0 * Math.max(0.2, rt60))));
            final float dd2 = Math.max(0.25f, Math.min(0.5f, decay + 0.15f));
            final float wetT = active ? (float) (tp[7] * Math.pow(y, 1.3)) : 0f;
            final float tail = Math.min(tp[5], Math.max(0.5f, rt60));
            final float wetFall = (float) Math.exp(-9.2 / (tail * rate));      // -80 dB over `tail` seconds
            final float damp = tp[3];
            final float bw = tp[4];
            final float gMod = tp[6];
            if (type == SPRING) { springBlock(l, r, n); return; }
            for (int i = 0; i < n; i++) {
                if (active) wet += (wetT - wet) * 0.002f; else wet *= wetFall;

                float in = active ? (l[i] + r[i]) * 0.5f : 0f;
                float hp = in - dcIn; dcIn += 0.003f * hp; in = hp;
                pre.push(in); float pd = pre.tap(preN);
                lpIn += bw * (pd - lpIn);
                float s = lpIn;
                for (int a = 0; a < 4; a++) {
                    Line ln = inAp[a];
                    float d = ln.oldest();
                    float v = s - IN_G[a] * d;
                    ln.push(v);
                    s = IN_G[a] * v + d;
                }

                float feedL = d2R.oldest() * decay;      // each branch feeds the other
                float feedR = d2L.oldest() * decay;

                // ---- left branch
                lfoL += lfoIncL; if (lfoL > 6.283185307179586) lfoL -= 6.283185307179586;
                float dm = apLBase + modDepth * (float) Math.sin(lfoL);
                float d = frac(apL, dm);
                float v = (s + feedL) - gMod * d;
                apL.push(v);
                float y1 = gMod * v + d;
                float o1 = d1L.oldest(); d1L.push(y1);
                lpL += damp * (o1 - lpL);
                float z = lpL * decay;
                lfo2L += lfo2IncL; if (lfo2L > 6.283185307179586) lfo2L -= 6.283185307179586;
                float o2 = frac(ap2L, ap2LBase + mod2Depth * (float) Math.sin(lfo2L));
                float v2 = z - dd2 * o2;
                ap2L.push(v2);
                d2L.push(dd2 * v2 + o2);

                // ---- right branch
                lfoR += lfoIncR; if (lfoR > 6.283185307179586) lfoR -= 6.283185307179586;
                dm = apRBase + modDepth * (float) Math.sin(lfoR);
                d = frac(apR, dm);
                v = (s + feedR) - gMod * d;
                apR.push(v);
                y1 = gMod * v + d;
                o1 = d1R.oldest(); d1R.push(y1);
                lpR += damp * (o1 - lpR);
                z = lpR * decay;
                lfo2R += lfo2IncR; if (lfo2R > 6.283185307179586) lfo2R -= 6.283185307179586;
                o2 = frac(ap2R, ap2RBase + mod2Depth * (float) Math.sin(lfo2R));
                v2 = z - dd2 * o2;
                ap2R.push(v2);
                d2R.push(dd2 * v2 + o2);

                float outL = d1R.tap(tapL[0]) + d1R.tap(tapL[1]) - ap2R.tap(tapL[2]) + d2R.tap(tapL[3])
                        - d1L.tap(tapL[4]) - ap2L.tap(tapL[5]) - d2L.tap(tapL[6]);
                float outR = d1L.tap(tapR[0]) + d1L.tap(tapR[1]) - ap2L.tap(tapR[2]) + d2L.tap(tapR[3])
                        - d1R.tap(tapR[4]) - ap2R.tap(tapR[5]) - d2R.tap(tapR[6]);
                l[i] += tone.run(outL) * wet * 0.6f;
                r[i] += toneR.run(outR) * wet * 0.6f;
            }
            if (!(lpL == lpL) || !(lpR == lpR) || Math.abs(lpL) > 1e4f || Math.abs(lpR) > 1e4f) clear();
        }
    }
}
