package com.gfdrps.core;

/** The five per-slot effects (also reused for the master bus). All take x,y in 0..1 from an XY pad. */
public final class Fx {
    private Fx() {}

    public static final int DIST = 0, FILTER = 1, AMP = 2, DELAY = 3, REVERB = 4, ROLL = 5, STUTTER = 6, RING = 7, CRUSH = 8, COUNT = 9;
    public static final String[] NAMES = {"Distortion", "Filter", "Amp Mod", "Delay", "Reverb", "Roll", "Stutter", "Ring Mod", "Crush"};
    /** Signal order inside a track / the master: crush and ring first, rhythmic effects, then the time-based ones last so their tails stay clean. */
    public static final int[] ORDER = {DIST, CRUSH, RING, FILTER, AMP, ROLL, STUTTER, DELAY, REVERB};
    static final int MAXN = 512;

    /**
     * Insert effects implement apply(); the base class cross-fades them in and out in ~10 ms
     * so switching a pad on or off never clicks. Delay and Reverb override process() because
     * their tails must keep ringing after the pad is released.
     */
    public abstract static class Effect {
        public volatile float x = 0.5f, y = 0.5f;
        public volatile boolean active = false;
        /** Per-effect hold: the effect stays on after the pad is released. */
        public volatile boolean hold = false;
        /** Wet amount 0..1 (0 = only the dry signal, 1 = only the effect). For the pad: Y = mix when yIsMix. */
        public volatile float wetMix = 1f;
        /** true: the pad's vertical axis is the mix (bottom 0 %, middle 50 %, top 100 % wet, no dry); false: it drives the effect's own Y parameter. */
        public volatile boolean yIsMix = true;
        protected final int rate;
        protected float mix;
        private final float[] dl = new float[MAXN], dr = new float[MAXN];

        protected Effect(int rate) { this.rate = rate; }

        protected void apply(float[] l, float[] r, int n, double bpm) {}
        protected void reset() {}

        public void process(float[] l, float[] r, int n, double bpm) {
            if (!active && mix <= 0.0005f) {
                if (mix != 0f) { mix = 0f; reset(); }
                return;
            }
            System.arraycopy(l, 0, dl, 0, n);
            System.arraycopy(r, 0, dr, 0, n);
            apply(l, r, n, bpm);
            final float t = active ? 1f : 0f;
            final float wm = wetMix;
            for (int i = 0; i < n; i++) {
                mix += (t - mix) * 0.003f;
                final float k = mix * wm;
                l[i] = dl[i] + (l[i] - dl[i]) * k;
                r[i] = dr[i] + (r[i] - dr[i]) * k;
            }
        }

        /** Pad input: X always goes to the effect; Y goes to the mix or to the effect's own Y parameter. */
        public void setPad(float nx, float ny) {
            x = Math.max(0f, Math.min(1f, nx));
            float v = Math.max(0f, Math.min(1f, ny));
            if (yIsMix) wetMix = v; else y = v;
        }
        /** Vertical position the pad should show. */
        public float padY() { return yIsMix ? wetMix : y; }

        /** Send-style blend (delay / reverb output = dry + wet): dry stays whole up to 50 %, then fades out; wet rises to full at 50 %, 1.3x at 100 %. */
        protected final void blendSend(float[] l, float[] r, float[] dL, float[] dR, int n) {
            final float m = Math.max(0f, Math.min(1f, wetMix));
            final float wg = m <= 0.5f ? m * 2f : 1f + (m - 0.5f) * 0.6f;
            final float dgFull = m <= 0.5f ? 1f : Math.max(0f, 2f * (1f - m));
            final float t = active ? 1f : 0f;
            for (int i = 0; i < n; i++) {
                mix += (t - mix) * 0.003f;
                final float dg = 1f - (1f - dgFull) * mix;
                l[i] = dL[i] * dg + (l[i] - dL[i]) * wg;
                r[i] = dR[i] * dg + (r[i] - dR[i]) * wg;
            }
        }

        public void setXY(float nx, float ny) {
            x = Math.max(0f, Math.min(1f, nx));
            y = Math.max(0f, Math.min(1f, ny));
        }
    }

    /** The LP/HP tone of a Delay or Reverb; null for the other effects. */
    /** Note name for "notes per bar": 4 = 1/4, 6 = 1/4T, 1 = 1 bar. */
    public static String noteName(int r) { return r == 1 ? "1 bar" : (r % 3 == 0 ? "1/" + (r * 2 / 3) + "T" : "1/" + r); }

    public static Tone toneOf(Effect e) {
        if (e instanceof Delay) return ((Delay) e).tone;
        if (e instanceof Reverb) return ((Reverb) e).tone;
        return null;
    }

    public static Effect create(int type, int rate) {
        switch (type) {
            case DIST: return new Distortion(rate);
            case FILTER: return new Filter(rate);
            case AMP: return new AmpMod(rate);
            case DELAY: return new Delay(rate);
            case ROLL: return new Roll(rate);
            case STUTTER: return new Stutter(rate);
            case RING: return new RingMod(rate);
            case CRUSH: return new Crush(rate);
            default: return new Reverb(rate);
        }
    }

    /** x = drive, y = tone. */
    public static final class Distortion extends Effect {
        private float lpL, lpR;
        public Distortion(int rate) { super(rate); }
        @Override protected void reset() { lpL = lpR = 0f; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            float drive = 1f + x * 24f;
            float comp = 1f / (float) Math.tanh(drive * 0.5f + 0.5f);
            float a = 0.08f + y * 0.9f;
            for (int i = 0; i < n; i++) {
                float sl = (float) Math.tanh(l[i] * drive) * comp * 0.7f;
                float sr = (float) Math.tanh(r[i] * drive) * comp * 0.7f;
                lpL += a * (sl - lpL);
                lpR += a * (sr - lpR);
                l[i] = lpL; r[i] = lpR;
            }
        }
    }

    /**
     * Resonant state-variable filter. x = cutoff (40 Hz..16 kHz, log), y = resonance. Low-pass or high-pass.
     * Envelope mode: an envelope follower on the signal's own waveform moves the cutoff (auto-wah / "envelope filter").
     * envAmount > 0 opens the filter on loud parts, < 0 closes it; envRange is how many octaves it can travel.
     */
    public static final class Filter extends Effect {
        /** 0 = low-pass, 1 = high-pass, 2 = band-pass, 3 = notch. */
        public volatile int mode = 0;
        public static final String[] MODE_NAMES = {"Passa-baixas (LPF)", "Passa-altas (HPF)", "Passa-banda (BPF)", "Notch"};
        public static final String[] MODE_SHORT = {"LOW-PASS", "HIGH-PASS", "BAND-PASS", "NOTCH"};
        public volatile boolean envOn = false;
        public volatile float envAmount = 0.7f, envAttackMs = 5f, envReleaseMs = 120f, envSens = 0.5f;
        public static final float ENV_OCTAVES = 6f;
        /** Last envelope value (0..1) and the cutoff it produced, for the UI. */
        public volatile float envLevel;
        private float s1L, s2L, s1R, s2R, envF;
        public Filter(int rate) { super(rate); }
        /** Damping used by the filter (2 = no resonance, 0.08 = strong); the pad uses it to draw the response. */
        public float damping() { return 2f - 1.92f * y; }
        public double cutoffHz() { return Math.min(40.0 * Math.pow(400.0, x), rate * 0.45); }
        /** Cutoff after the envelope has moved it. */
        public double modulatedHz(float env) {
            double hz = cutoffHz() * Math.pow(2.0, envAmount * env * ENV_OCTAVES);
            return Math.max(20.0, Math.min(rate * 0.45, hz));
        }
        @Override protected void reset() { s1L = s2L = s1R = s2R = 0f; envF = 0f; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final int fm = mode; final boolean em = envOn;
            final float k = damping();
            final float atk = 1f - (float) Math.exp(-1.0 / (Math.max(0.5f, envAttackMs) * 0.001 * rate));
            final float rel = 1f - (float) Math.exp(-1.0 / (Math.max(5f, envReleaseMs) * 0.001 * rate));
            final float gain = 1f + 9f * envSens;
            float g = (float) Math.tan(Math.PI * cutoffHz() / rate);
            float a1 = 1f / (1f + g * (g + k)), a2 = g * a1, a3 = g * a2;
            for (int i = 0; i < n; i++) {
                if (em) {
                    float pk = Math.max(Math.abs(l[i]), Math.abs(r[i])) * gain;
                    envF += (pk - envF) * (pk > envF ? atk : rel);
                    if ((i & 7) == 0) {                                  // coefficients every 8 samples is plenty
                        float e = Math.min(1f, envF);
                        g = (float) Math.tan(Math.PI * modulatedHz(e) / rate);
                        a1 = 1f / (1f + g * (g + k)); a2 = g * a1; a3 = g * a2;
                    }
                }
                float v0 = l[i];
                float v3 = v0 - s2L;
                float v1 = a1 * s1L + a2 * v3;
                float v2 = s2L + a2 * s1L + a3 * v3;
                s1L = 2 * v1 - s1L; s2L = 2 * v2 - s2L;
                l[i] = fm == 0 ? v2 : fm == 1 ? v0 - k * v1 - v2 : fm == 2 ? v1 * k : v0 - k * v1;
                v0 = r[i];
                v3 = v0 - s2R;
                v1 = a1 * s1R + a2 * v3;
                v2 = s2R + a2 * s1R + a3 * v3;
                s1R = 2 * v1 - s1R; s2R = 2 * v2 - s2R;
                r[i] = fm == 0 ? v2 : fm == 1 ? v0 - k * v1 - v2 : fm == 2 ? v1 * k : v0 - k * v1;
            }
            envLevel = Math.min(1f, envF);
            if (Float.isNaN(s1L) || Float.isNaN(s2L) || Float.isNaN(s1R) || Float.isNaN(s2R)
                    || Math.abs(s1L) > 1e6f || Math.abs(s1R) > 1e6f) { s1L = s2L = s1R = s2R = 0f; }
        }
    }

    /**
     * Amp mod / gate. x = rate (0.5..20 Hz, or a note length of the tempo with sync), y = depth (0 = nothing, 1 = full gate).
     * The waveform decides how the level opens and closes: sine, square gate, saw down (plucks), ramp up (swells), triangle,
     * trance (short 25 % pulses) and random steps.
     */
    public static final class AmpMod extends Effect {
        public static final int SINE = 0, SQUARE = 1, SAW = 2, RAMP = 3, TRI = 4, TRANCE = 5, RANDOM = 6, RANDOM_SMOOTH = 7;
        public static final String[] SHAPES = {"Seno", "Gate", "Serra ↓", "Rampa ↑", "Triângulo", "Trance", "Aleatório", "Aleatório suave"};
        /** Waveform value (1 = open) at phase p for the UI grid; the random shapes use a fixed pattern keyed by `cycle`. */
        public static float shapeAt(int shape, double p, int cycle) {
            switch (shape) {
                case SQUARE: return p < 0.5 ? 1f : 0f;
                case SAW: return (float) (1.0 - p);
                case RAMP: return (float) p;
                case TRI: return (float) (p < 0.5 ? p * 2 : 2 - p * 2);
                case TRANCE: return p < 0.25 ? 1f : 0f;
                case RANDOM: return pat(cycle);
                case RANDOM_SMOOTH: { float a = pat(cycle), b = pat(cycle + 1); double t = p * p * (3 - 2 * p); return (float) (a + (b - a) * t); }
                default: return 0.5f + 0.5f * (float) Math.cos(2 * Math.PI * p);
            }
        }
        private static float pat(int c) { int h = (c * 2654435761L > 0 ? (int) ((c * 2654435761L) >>> 7) : c * 31) & 255; return 0.15f + 0.85f * (h / 255f); }
        public volatile int shape = SQUARE;
        /** true = the rate follows the project tempo (x picks the note length). */
        public volatile boolean sync = false;
        public static final int[] SYNC_RATES = {1, 2, 4, 6, 8, 12, 16, 24, 32};      // notes per bar
        private double ph;                                    // 0..1
        private float cur = 1f, rnd = 1f, rndPrev = 1f;
        private final java.util.Random rng = new java.util.Random(7);
        public AmpMod(int rate) { super(rate); }
        public static int syncIndex(double x) { return Math.min(SYNC_RATES.length - 1, (int) (Math.max(0.0, x) * SYNC_RATES.length)); }
        public static int syncRate(double x) { return SYNC_RATES[syncIndex(x)]; }
        private float wave(double p) {                        // 1 = open, 0 = closed
            switch (shape) {
                case SQUARE: return p < 0.5 ? 1f : 0f;
                case SAW: return (float) (1.0 - p);
                case RAMP: return (float) p;
                case TRI: return (float) (p < 0.5 ? p * 2 : 2 - p * 2);
                case TRANCE: return p < 0.25 ? 1f : 0f;
                case RANDOM: return rnd;
                case RANDOM_SMOOTH: { double t = p * p * (3 - 2 * p); return (float) (rndPrev + (rnd - rndPrev) * t); }
                default: return 0.5f + 0.5f * (float) Math.cos(2 * Math.PI * p);
            }
        }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            double f = sync ? (Math.max(30.0, bpm) / 60.0) * (syncRate(x) / 4.0) : 0.5 * Math.pow(40.0, x);
            double inc = f / rate;
            // sharp shapes get a ~1.5 ms edge so a gate never clicks
            final float slew = (shape == SQUARE || shape == TRANCE || shape == RANDOM || shape == SAW) ? 0.02f : 1f;
            final float depth = y;
            for (int i = 0; i < n; i++) {
                ph += inc;
                if (ph >= 1.0) { ph -= 1.0; if (shape == RANDOM) rnd = rng.nextInt(3) == 0 ? 0f : (0.4f + 0.6f * rng.nextFloat()); else if (shape == RANDOM_SMOOTH) { rndPrev = rnd; rnd = 0.1f + 0.9f * rng.nextFloat(); } }
                float w = wave(ph);
                cur += (w - cur) * slew;
                float m = 1f - depth * (1f - cur);
                l[i] *= m; r[i] *= m;
            }
        }
    }

    /** Chorus and pitch modulation (vibrato) for a wet signal: modulated delay taps. Used inside the Reverb. */
    public static final class WetMod {
        /** 0..1 chorus depth/mix, 0..1 vibrato depth (up to about +-50 cents at 1 Hz), LFO rate in Hz. */
        public volatile float chorus = 0f, pitchMod = 0f, rateHz = 1f;
        private final float[][] buf = new float[2][4096];
        private int w;
        private double ph1, ph2;
        private final int rate;
        public WetMod(int rate) { this.rate = rate; }
        public boolean active() { return chorus > 0.001f || pitchMod > 0.001f; }
        public void process(float[] l, float[] r, int n) {
            final float ch = Math.max(0f, Math.min(1f, chorus)), pm = Math.max(0f, Math.min(1f, pitchMod));
            if (ch <= 0.001f && pm <= 0.001f) return;
            final double inc1 = Math.max(0.05, rateHz) / rate, inc2 = 0.43 / rate;
            final float base = 0.014f * rate, vibD = pm * 0.0045f * rate, chD = ch * 0.004f * rate;
            final int M = 4095;
            for (int i = 0; i < n; i++) {
                buf[0][w] = l[i]; buf[1][w] = r[i];
                ph1 += inc1; if (ph1 >= 1) ph1 -= 1; ph2 += inc2; if (ph2 >= 1) ph2 -= 1;
                for (int c = 0; c < 2; c++) {
                    double off = c * 0.25;
                    float vib = vibD * (float) Math.sin(2 * Math.PI * (ph1 + off));
                    float dA = base + vib + chD * (float) Math.sin(2 * Math.PI * (ph2 + off));
                    float dB = base + vib + chD * (float) Math.sin(2 * Math.PI * (ph2 + off + 0.37));
                    float a = tap(buf[c], dA), b = tap(buf[c], dB);
                    float dry = buf[c][(w - (int) base + 4096) & M];
                    float out = ch > 0.001f ? dry * (1f - 0.45f * ch) + (a + b) * 0.5f * (0.45f + 0.4f * ch) * 1f : a;
                    if (ch > 0.001f && pm > 0.001f) out = (a + b) * 0.5f;
                    if (c == 0) l[i] = out; else r[i] = out;
                }
                w = (w + 1) & M;
            }
        }
        private float tap(float[] b, float d) {
            float rp = w - d; while (rp < 0) rp += 4096;
            int i0 = (int) rp; float f = rp - i0;
            return b[i0 & 4095] + (b[(i0 + 1) & 4095] - b[i0 & 4095]) * f;
        }
    }

    /** State variable filter used as the optional low-pass / high-pass on a delay's or reverb's wet signal. */
    public static final class Tone {
        /** 0 = off, 1 = low-pass, 2 = high-pass, 3 = band-pass, 4 = notch. */
        public volatile int mode = 0;
        /** 0..1 position on a 40 Hz .. 18 kHz exponential scale. */
        public volatile float cut = 0.5f;
        private float s1, s2, g = 0.1f;
        private final int rate;
        public Tone(int rate) { this.rate = rate; }
        public static double hz(float c, int rate) { return Math.min(40.0 * Math.pow(450.0, Math.max(0f, Math.min(1f, c))), rate * 0.45); }
        public double cutoffHz() { return hz(cut, rate); }
        public static final String[] NAMES = {"OFF", "LP", "HP", "BP", "Notch"};
        /** Call once per block: recomputes the coefficient from the (smoothed) cutoff. */
        void block() {
            float gt = (float) Math.tan(Math.PI * cutoffHz() / rate);
            g += (gt - g) * 0.5f;
        }
        float run(float v0) {
            int m = mode;
            if (m == 0) { s1 = s2 = 0f; return v0; }
            final float k = m >= 3 ? 0.55f : 1.0f;                       // band-pass and notch are narrower
            float a1 = 1f / (1f + g * (g + k)), a2 = g * a1, a3 = g * a2;
            float v3 = v0 - s2;
            float v1 = a1 * s1 + a2 * v3;
            float v2 = s2 + a2 * s1 + a3 * v3;
            s1 = 2 * v1 - s1; s2 = 2 * v2 - s2;
            if (!(s1 == s1) || !(s2 == s2) || Math.abs(s1) > 1e6f) { s1 = s2 = 0f; return 0f; }
            switch (m) {
                case 1: return v2;
                case 3: return v1 * k;
                case 4: return v0 - k * v1;
                default: return v0 - k * v1 - v2;
            }
        }
        void clear() { s1 = s2 = 0f; }
    }

    /** Feedback delay. x = time (10 ms..4 s in whole ms, or a tempo-synced note length with sync), y = feedback. Short times make comb filters; long times ping-pong. */
    public static final class Delay extends Effect {
        public static final double MIN_MS = 10.0, MAX_MS = 4000.0;
        /** Note lengths in beats for sync mode (1/32 .. 1 bar, straight and dotted). */
        /** Same note grid as the arpeggiator / quantize / slices (notes per bar, shortest first), straight and triplets. */
        public static final int[] DIV_RATES = {64, 48, 32, 24, 16, 12, 8, 6, 4, 3, 2, 1};
        public static final double[] DIV = new double[DIV_RATES.length];
        public static final String[] DIV_NAMES = new String[DIV_RATES.length];
        static {
            for (int i = 0; i < DIV_RATES.length; i++) {
                int r = DIV_RATES[i];
                DIV[i] = 4.0 / r;
                DIV_NAMES[i] = r % 3 == 0 ? "1/" + (r * 2 / 3) + "T" : (r == 1 ? "1 bar" : "1/" + r);
            }
        }
        /** When set (and sync is on) the delay follows the track's grid (its arp rate / quantize value) instead of the pad's x. */
        public volatile boolean follow = false;
        public volatile int gridRate = 0;
        /** true = x picks a note length locked to the project tempo; false = x is free time in milliseconds. */
        public volatile boolean sync = false;
        /** Delay time currently used, in ms (for the UI). */
        public volatile float shownMs = 250f;
        public static final int DIGITAL = 0, ANALOG = 1, TAPE = 2, MULTITAP = 3;
        public static final String[] TYPES = {"Digital", "Analógico", "Fita", "Multitap"};
        /** Digital: clean repeats. Analógico: each repeat darker and softer (bucket-brigade). Fita: saturation, band-limited, wow and flutter. Multitap: four taps with their own level and stereo position. */
        public volatile int type = DIGITAL;
        /** Pitch of the echoes in semitones (-12..+12). It sits inside the feedback loop, so every repeat climbs / falls another step. */
        public volatile float pitch = 0f;
        /** Reverse echoes: every repeat plays the past backwards (two overlapping heads crossfaded). */
        public volatile boolean reverse = false;
        private float rvPh;
        /** Diffusion 0..1: smears the echoes with all-pass diffusers (0 = crisp repeats, 1 = washed, cloud-like). */
        public volatile float diffusion = 0f;
        public static final class PShift {
            final float[] b = new float[8192]; int w; double ph;
            public float run(float in, double ratio, int win) {
                b[w] = in; w = (w + 1) & 8191;
                ph += (1.0 - ratio) / win;
                ph -= Math.floor(ph);
                float out = 0f;
                for (int t = 0; t < 2; t++) {
                    double p = ph + 0.5 * t; if (p >= 1.0) p -= 1.0;
                    double rp = w - 1 - p * win; if (rp < 0) rp += 8192;
                    int i0 = (int) rp; float f = (float) (rp - i0);
                    float v = b[i0 & 8191] + (b[(i0 + 1) & 8191] - b[i0 & 8191]) * f;
                    float sn = (float) Math.sin(Math.PI * p);
                    out += v * sn * sn;
                }
                return out;
            }
            public void clear() { java.util.Arrays.fill(b, 0f); }
        }
        private static final class AP {
            final float[] b; int w;
            AP(int len) { b = new float[Math.max(2, len)]; }
            float run(float x, float g) {
                float d = b[w];
                float v = x - g * d;
                b[w] = v; if (++w >= b.length) w = 0;
                return d + g * v;
            }
        }
        private final PShift psL = new PShift(), psR = new PShift(), psF = new PShift();
        private final AP[] dfL = new AP[8], dfR = new AP[8];
        private static final int[] DF_LEN = {142, 107, 379, 277, 53, 89, 211, 331};
        // "cloud" tank for high diffusion: damped combs fed by the diffused echoes, so the repeats bloom into a reverb-like wash
        private final float[] cbL = new float[4096], cbR = new float[4096];
        private int cbW;
        private float cbLpL, cbLpR;
        private float dOutL, dOutR;
        private double dModPh;
        /** Diffuses one stereo pair (dOutL / dOutR). dif 0..1: 0 = untouched, 1 = full cloud (8 all-passes + feedback tank). */
        private void diffuse(float l, float r, float dif) {
            final int stages = dif > 0.5f ? 8 : 4;
            final float g = 0.3f + 0.48f * dif;
            float xl = l, xr = r;
            for (int k = 0; k < stages; k++) { xl = dfL[k].run(xl, g); xr = dfR[k].run(xr, g); }
            float ol = l + (xl - l) * Math.min(1f, dif * 1.3f), or = r + (xr - r) * Math.min(1f, dif * 1.3f);
            if (dif > 0.5f) {
                float c = (dif - 0.5f) * 2f;                       // 0..1 : tank amount
                int len = cbL.length;
                int t1 = (int) (0.0263 * rate), t2 = (int) (0.0371 * rate);
                t1 = Math.min(t1, len - 2); t2 = Math.min(t2, len - 2);
                int a1 = (cbW - t1 + len) % len, a2 = (cbW - t2 + len) % len;
                float fbk = 0.55f + 0.38f * c;
                cbLpL += 0.35f * ((cbL[a1] + cbR[a2]) * 0.5f - cbLpL);      // damped, cross-coupled
                cbLpR += 0.35f * ((cbR[a1] + cbL[a2]) * 0.5f - cbLpR);
                cbL[cbW] = clip(xl * 0.5f + cbLpL * fbk);
                cbR[cbW] = clip(xr * 0.5f + cbLpR * fbk);
                cbW = (cbW + 1) % len;
                ol += cbLpL * c * 0.9f; or += cbLpR * c * 0.9f;
            }
            dOutL = ol; dOutR = or;
        }
        private float aL1, aL2, aR1, aR2, hL, hR;          // feedback colour filters
        private double wowPh, flutPh;
        private final java.util.Random nz = new java.util.Random(11);
        private float flutNoise;
        private static final float[] TAP_F = {0.25f, 0.5f, 0.75f, 1f}, TAP_G = {0.5f, 0.65f, 0.8f, 1f}, TAP_P = {-0.8f, 0.5f, -0.3f, 0.8f};
        /** Optional low-pass / high-pass on the echoes (also inside the feedback loop, so repeats get darker or thinner). */
        public final Tone tone;
        private final Tone toneR;
        private final float[] bl, br;
        private int w;
        private float cur;
        public Delay(int rate) {
            super(rate);
            tone = new Tone(rate); toneR = new Tone(rate);
            for (int k = 0; k < 8; k++) {
                dfL[k] = new AP((int) Math.round(DF_LEN[k] * rate / 29761.0));
                dfR[k] = new AP((int) Math.round(DF_LEN[k] * rate / 29761.0 * 1.13) + 3);
            }
            int len = (int) (rate * (MAX_MS / 1000.0)) + 64;
            bl = new float[len];
            br = new float[len];
        }
        /** x (0..1) to milliseconds: exponential 10 ms .. 4000 ms, whole milliseconds (1 ms steps on the short side). */
        public static double msForX(double x) {
            double ms = MIN_MS * Math.pow(MAX_MS / MIN_MS, Math.max(0.0, Math.min(1.0, x)));
            return Math.round(ms);
        }
        public static int divIndex(double x) { return Math.min(DIV.length - 1, (int) (Math.max(0.0, x) * DIV.length)); }

        private final float[] sdL = new float[MAXN], sdR = new float[MAXN];
        { wetMix = 0.5f; }
        @Override public void process(float[] l, float[] r, int n, double bpm) {
            System.arraycopy(l, 0, sdL, 0, n); System.arraycopy(r, 0, sdR, 0, n);
            processCore(l, r, n, bpm);
            blendSend(l, r, sdL, sdR, n);
        }
        private void processCore(float[] l, float[] r, int n, double bpm) {
            double ms;
            if (sync && follow && gridRate > 0) ms = (4.0 / gridRate) * 60000.0 / Math.max(30.0, bpm);
            else if (sync) ms = DIV[divIndex(x)] * 60000.0 / Math.max(30.0, bpm);
            else ms = msForX(x);
            ms = Math.max(MIN_MS, Math.min(MAX_MS, ms));
            shownMs = (float) ms;
            float target = (float) Math.min(ms * 0.001 * rate, bl.length - 3);
            if (cur == 0f) cur = target;
            final float slew = 0.0012f;                         // time changes glide (tape-style), never click
            // short times: straight feedback = a comb filter / metallic echo; longer times: ping-pong between L and R
            final float pp = (float) Math.max(0.0, Math.min(1.0, (ms - 60.0) / 90.0));
            float fb = (0.1f + 0.85f * y) * (active ? 1f : 0.55f);
            tone.block(); toneR.mode = tone.mode; toneR.cut = tone.cut; toneR.block();
            final int ty = type;
            final float kA = 1f - (float) Math.exp(-2 * Math.PI * (ty == TAPE ? 4200.0 : 2400.0) / rate);
            final float kH = 1f - (float) Math.exp(-2 * Math.PI * 130.0 / rate);
            final double wowInc = 0.55 / rate, flutInc = 6.8 / rate;
            final float semis = Math.max(-12f, Math.min(12f, pitch));
            final boolean shift = Math.abs(semis) > 0.01f;
            final double pr = Math.pow(2.0, semis / 12.0);
            final int pwin = (int) (0.06 * rate);
            final float dif = Math.max(0f, Math.min(1f, diffusion));
            final boolean rev = reverse && ty != MULTITAP;
            for (int i = 0; i < n; i++) {
                cur += (target - cur) * slew;
                float modS = 0f;
                if (ty == TAPE) {
                    wowPh += wowInc; if (wowPh > 1) wowPh -= 1; flutPh += flutInc; if (flutPh > 1) flutPh -= 1;
                    if ((i & 63) == 0) flutNoise += (nz.nextFloat() * 2f - 1f - flutNoise) * 0.3f;
                    modS = (float) (Math.sin(2 * Math.PI * wowPh) * 0.0010 + Math.sin(2 * Math.PI * flutPh) * 0.00012 * (1 + flutNoise)) * rate;
                } else if (ty == ANALOG) {
                    wowPh += 0.8 / rate; if (wowPh > 1) wowPh -= 1;
                    modS = (float) (Math.sin(2 * Math.PI * wowPh) * 0.00025) * rate;      // faint bucket-brigade shimmer
                }
                float dly = Math.max(1f, Math.min(bl.length - 3, cur + modS));
                float rp = w - dly;
                while (rp < 0) rp += bl.length;
                int i0 = (int) rp;
                int i1 = i0 + 1 >= bl.length ? 0 : i0 + 1;
                float f = rp - i0;
                float inL = active ? l[i] : 0f;
                float inR = active ? r[i] : 0f;
                if (ty == MULTITAP) {
                    float oL = 0f, oR = 0f, last = 0f;
                    for (int k = 0; k < 4; k++) {
                        float rk = w - Math.max(1f, Math.min(bl.length - 3, dly * TAP_F[k]));
                        while (rk < 0) rk += bl.length;
                        int a0 = (int) rk, a1 = a0 + 1 >= bl.length ? 0 : a0 + 1;
                        float v = (bl[a0] + (bl[a1] - bl[a0]) * (rk - a0)) * TAP_G[k];
                        float pn = TAP_P[k];
                        oL += v * (pn <= 0 ? 1f : 1f - pn); oR += v * (pn >= 0 ? 1f : 1f + pn);
                        if (k == 3) last = v;
                    }
                    if (shift) { oL = psL.run(oL, pr, pwin); oR = psR.run(oR, pr, pwin); last = psF.run(last, pr, pwin); }
                    if (dif > 0.001f) { diffuse(oL, oR, dif); oL = dOutL; oR = dOutR; }
                    oL = tone.run(oL); oR = toneR.run(oR);
                    bl[w] = clip((inL + inR) * 0.5f + last * fb * 0.9f);
                    if (++w >= bl.length) w = 0;
                    l[i] += oL * 0.7f; r[i] += oR * 0.7f;
                    continue;
                }
                float dl = bl[i0] + (bl[i1] - bl[i0]) * f;
                float dr = br[i0] + (br[i1] - br[i0]) * f;
                if (rev) {                                   // heads walk backwards through the last 2 x delay time
                    rvPh += 1f / Math.max(64f, dly); if (rvPh >= 1f) rvPh -= 1f;
                    dl = 0f; dr = 0f;
                    for (int hd = 0; hd < 2; hd++) {
                        float ph = rvPh + 0.5f * hd; if (ph >= 1f) ph -= 1f;
                        float rk = w - Math.max(1f, Math.min(bl.length - 3, ph * 2f * dly));
                        while (rk < 0) rk += bl.length;
                        int a0 = (int) rk, a1 = a0 + 1 >= bl.length ? 0 : a0 + 1;
                        float fr2 = rk - a0, sn = (float) Math.sin(Math.PI * ph); sn *= sn;
                        dl += (bl[a0] + (bl[a1] - bl[a0]) * fr2) * sn;
                        dr += (br[a0] + (br[a1] - br[a0]) * fr2) * sn;
                    }
                }
                if (shift) { dl = psL.run(dl, pr, pwin); dr = psR.run(dr, pr, pwin); }
                if (dif > 0.001f) { diffuse(dl, dr, dif); dl = dOutL; dr = dOutR; }
                dl = tone.run(dl); dr = toneR.run(dr);
                float fl = dl, fr = dr;
                if (ty == ANALOG) {                       // every trip through the loop loses brightness and clarity
                    aL1 += kA * (fl - aL1); aL2 += kA * (aL1 - aL2); fl = aL2;
                    aR1 += kA * (fr - aR1); aR2 += kA * (aR1 - aR2); fr = aR2;
                } else if (ty == TAPE) {                  // band-limited and saturated, like tape
                    aL1 += kA * (fl - aL1); fl = aL1; hL += kH * (fl - hL); fl = sat(fl - hL);
                    aR1 += kA * (fr - aR1); fr = aR1; hR += kH * (fr - hR); fr = sat(fr - hR);
                }
                bl[w] = clip(inL + (fl * (1f - pp) + fr * pp) * fb);
                br[w] = clip(inR + (fr * (1f - pp) + fl * pp) * fb);
                if (++w >= bl.length) w = 0;
                l[i] += dl * 0.8f;
                r[i] += dr * 0.8f;
            }
        }
        private static float sat(float v) { return (float) Math.tanh(v * 1.4) / 1.4f; }
        private static float clip(float v) { return v > 1f ? 1f : (v < -1f ? -1f : v); }
    }

    /** Shared by Roll and Stutter: a short ring of the incoming signal. */
    private abstract static class Capture extends Effect {
        protected final float[] rl, rr;
        protected int rw;
        protected boolean wasActive;
        protected Capture(int rate, double seconds) { super(rate); rl = new float[(int) (rate * seconds)]; rr = new float[rl.length]; }
        protected final void record(float[] l, float[] r, int n) {
            for (int i = 0; i < n; i++) { rl[rw] = l[i]; rr[rw] = r[i]; if (++rw >= rl.length) rw = 0; }
        }
        protected abstract void onStart();
        @Override public void process(float[] l, float[] r, int n, double bpm) {
            if (active && !wasActive) onStart();                  // freeze / restart exactly when the pad goes down
            wasActive = active;
            super.process(l, r, n, bpm);
            if (!active) record(l, r, n);                         // keep listening while idle so a press captures what just played
        }
        protected double divSamples(double bpm, int notesPerBar) { return rate * 60.0 / Math.max(30.0, bpm) * 4.0 / notesPerBar; }
    }

    /**
     * Roll (beat repeat): when the pad goes down the last moment of audio is frozen and repeated like a DJ roll.
     * x = repeat length (1/4 down to 1/64, straight and triplet), y = acceleration: the repeats keep getting shorter, up to a "roll-up".
     */
    public static final class Roll extends Capture {
        public static final int[] RATES = {4, 6, 8, 12, 16, 24, 32, 48, 64};
        /** Seconds it takes the roll to reach its shortest length when y = 1. */
        public volatile float rampBars = 2f;
        private float[] fl, fr;
        private double p, t, curLen;
        private int fEnd;
        public Roll(int rate) { super(rate, 2.0); fl = new float[rl.length]; fr = new float[rl.length]; }
        public static int rateIndex(float x) { return Math.min(RATES.length - 1, (int) (Math.max(0f, x) * RATES.length)); }
        @Override protected void onStart() {
            int n = rl.length;
            for (int i = 0; i < n; i++) { int src = (rw + i) % n; fl[i] = rl[src]; fr[i] = rr[src]; }
            p = 0; t = 0; fEnd = n; curLen = 0;
        }
        @Override protected void reset() { p = 0; t = 0; curLen = 0; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final double base = Math.min(fEnd - 4.0, divSamples(bpm, RATES[rateIndex(x)]));
            final double ramp = rampBars * 4.0 * rate * 60.0 / Math.max(30.0, bpm);
            final double xf = Math.max(8.0, 0.002 * rate);
            for (int i = 0; i < n; i++) {
                if (curLen <= 0 || p >= curLen) {                // the length is only changed at the loop seam (a moving window made glitches)
                    double prog = Math.min(1.0, t / ramp);
                    curLen = Math.max(Math.min(base, 0.004 * rate + 8), base * (1.0 - 0.9 * y * prog));
                    p = 0;
                }
                final double len = curLen;
                double rp = fEnd - len + p;
                int i0 = Math.min(fEnd - 1, (int) rp); float fr2 = (float) Math.max(0.0, rp - i0);
                int i1 = Math.min(fEnd - 1, i0 + 1);
                float gl = fl[i0] + (fl[i1] - fl[i0]) * fr2, gr = fr[i0] + (fr[i1] - fr[i0]) * fr2;
                float g = (float) Math.min(1.0, Math.min(p / xf, (len - p) / xf));      // short fades at the loop seam: no clicks
                l[i] = gl * g; r[i] = gr * g;
                p += 1.0; t += 1.0;
            }
        }
    }

    /**
     * Stutter: the signal is re-triggered on a grid. At the start of every step the first slice of audio is captured and
     * repeated for the rest of the step. x = step length (1/2 .. 1/32), y = how many repeats fit in a step (2 .. 16).
     */
    public static final class Stutter extends Capture {
        public static final int[] RATES = {2, 4, 6, 8, 12, 16, 24, 32};
        /** 0..1: gate shape of every repeat (0 = full length, 1 = short taps). */
        public volatile float gate = 0f;
        private final float[] cl, cr;
        private double stepPos;
        private int capLen, capCount;
        private double rp;
        private float mLoop;
        public Stutter(int rate) { super(rate, 0.5); cl = new float[rate]; cr = new float[rate]; }
        @Override protected void onStart() { stepPos = 0; capCount = 0; capLen = 0; rp = 0; mLoop = 0f; }
        @Override protected void reset() { stepPos = 0; capCount = 0; capLen = 0; mLoop = 0f; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final double step = Math.min(cl.length * 0.99, divSamples(bpm, RATES[Math.min(RATES.length - 1, (int) (x * RATES.length))]));
            final int reps = 2 + Math.round(y * 14f);
            final double chunk = Math.max(0.004 * rate, step / reps);
            final double xf = Math.max(8.0, 0.0015 * rate);
            final float gt = 1f - 0.75f * gate;
            for (int i = 0; i < n; i++) {
                if (stepPos >= step) { stepPos -= step; capCount = 0; capLen = 0; rp = 0; }
                float ol, or;
                final float mInc = (float) (1.0 / xf);
                if (stepPos < chunk) {
                    mLoop = Math.max(0f, mLoop - mInc);                           // capture window: live signal passes and is recorded
                    if (capCount < cl.length) { cl[capCount] = l[i]; cr[capCount] = r[i]; capCount++; }
                    capLen = capCount;
                    ol = l[i]; or = r[i];
                } else if (capLen > 8) {
                    mLoop = Math.min(1f, mLoop + mInc);
                    double len = capLen;
                    if (rp >= len) rp -= len * Math.floor(rp / len);
                    int i0 = (int) rp, i1 = Math.min(capLen - 1, i0 + 1); float f = (float) (rp - i0);
                    ol = cl[i0] + (cl[i1] - cl[i0]) * f; or = cr[i0] + (cr[i1] - cr[i0]) * f;
                    float g = (float) Math.min(1.0, Math.min(rp / xf, (len - rp) / xf));
                    double pos = rp / len; if (pos > gt) g = 0f;
                    ol = l[i] * (1f - mLoop) + ol * g * mLoop; or = r[i] * (1f - mLoop) + or * g * mLoop;
                    rp += 1.0;
                } else { mLoop = Math.max(0f, mLoop - mInc); ol = l[i]; or = r[i]; }
                l[i] = ol; r[i] = or;
                stepPos += 1.0;
            }
        }
    }

    /** Ring modulation: the input is multiplied by a carrier. x = carrier frequency (20 Hz .. 5 kHz), y = depth (dry/ring blend). */
    public static final class RingMod extends Effect {
        public static final String[] SHAPES = {"Seno", "Quadrada", "Triângulo", "Serra"};
        public volatile int shape = 0;
        /** Sync the carrier to a note frequency grid (semitone steps) instead of a continuous sweep. */
        public volatile boolean snap = false;
        private double ph;
        public RingMod(int rate) { super(rate); }
        public double freqHz() {
            double f = 20.0 * Math.pow(250.0, x);
            if (snap) f = 55.0 * Math.pow(2.0, Math.round(12.0 * Math.log(f / 55.0) / Math.log(2.0)) / 12.0);
            return Math.min(f, rate * 0.45);
        }
        /** Carrier value (-1..1) of a shape at phase 0..1 (also used to draw the pad curve). */
        public static float carrier(int shape, double ph) {
            switch (shape) {
                case 1: return ph < 0.5 ? 1f : -1f;
                case 2: return (float) (ph < 0.5 ? 4 * ph - 1 : 3 - 4 * ph);
                case 3: return (float) (2 * ph - 1);
                default: return (float) Math.sin(2 * Math.PI * ph);
            }
        }
        @Override protected void reset() { ph = 0; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final double inc = freqHz() / rate;
            final float d = Math.max(0f, Math.min(1f, y));
            final int sh = shape;
            for (int i = 0; i < n; i++) {
                ph += inc; if (ph >= 1.0) ph -= 1.0;
                float c;
                switch (sh) {
                    case 1: c = ph < 0.5 ? 1f : -1f; break;
                    case 2: c = (float) (ph < 0.5 ? 4 * ph - 1 : 3 - 4 * ph); break;
                    case 3: c = (float) (2 * ph - 1); break;
                    default: c = (float) Math.sin(2 * Math.PI * ph);
                }
                float g = 1f - d + d * c;
                l[i] *= g; r[i] *= g;
            }
        }
    }

    /** Crush (bit crusher + sample-rate reducer). x = sample-rate reduction (none .. 1/64), y = bit depth (16 down to 2 bits). */
    public static final class Crush extends Effect {
        public volatile boolean dither = false;
        private float hl, hr;
        private double cnt;
        private final java.util.Random rng = new java.util.Random(11);
        public Crush(int rate) { super(rate); }
        public double hold() { return 1.0 + x * x * 63.0; }
        public double bits() { return 16.0 - y * 14.0; }
        @Override protected void reset() { hl = hr = 0f; cnt = 0; }
        @Override protected void apply(float[] l, float[] r, int n, double bpm) {
            final double h = hold();
            final float q = (float) Math.pow(2.0, bits() - 1.0);
            for (int i = 0; i < n; i++) {
                cnt += 1.0;
                if (cnt >= h) {
                    cnt -= h;
                    float dl = dither ? (rng.nextFloat() - rng.nextFloat()) / q : 0f;
                    float dr = dither ? (rng.nextFloat() - rng.nextFloat()) / q : 0f;
                    hl = Math.round((l[i] + dl) * q) / q; hr = Math.round((r[i] + dr) * q) / q;
                }
                l[i] = hl; r[i] = hr;
            }
        }
    }

    /**
     * "Cloud" reverb: a Dattorro-style plate. The input goes through a pre-delay and four dense
     * diffusers into a figure-eight tank of two cross-coupled branches, each with a slowly
     * modulated all-pass, a darkening low-pass and a second diffuser. The modulation and the
     * all-pass diffusion keep the tail smooth and free of ringing/pitched resonances, and the
     * output is taken from 14 taps spread over both branches for a wide, decorrelated stereo image.
     *
     * x = decay time (0.6 s .. 14 s), y = wet level. It only listens while the pad is active; after
     * release the tail rings out naturally (at most ~2.5 s) and then goes completely silent.
     */
    public static final class Reverb extends Effect {
        public static final int CLOUD = 0, HALL = 1, PLATE = 2, SPRING = 3, SHIMMER = 4;
        public static final String[] TYPES = {"Cloud", "Hall", "Plate", "Spring", "Shimmer"};
        /**
         * Shimmer settings: 0 feedback (0..0.35), 1 semitones A, 2 gain A, 3 B on, 4 semitones B, 5 gain B, 6 C on, 7 semitones C, 8 gain C,
         * 9 D on, 10 semitones D, 11 gain D, 12 low RT60 multiplier, 13 HF damping Hz, 14 loop high-pass Hz, 15 loop low-pass Hz.
         */
        public final float[] sh = {0.25f, 12f, 0.7f, 1f, 7f, 0.3f, 0f, -12f, 0.4f, 0f, 4f, 0.3f, 1f, 6000f, 250f, 8000f};
        public static final float[] SH_DEFAULT = sh0();
        private static float[] sh0() { return new float[]{0.25f, 12f, 0.7f, 1f, 7f, 0.3f, 0f, -12f, 0.4f, 0f, 4f, 0.3f, 1f, 6000f, 250f, 8000f}; }
        private ZitaRev zita;
        private GranShift[] layers;
        private final float[] zInL = new float[MAXN], zInR = new float[MAXN], zWL = new float[MAXN], zWR = new float[MAXN];
        private final float[] fbL = new float[MAXN], fbR = new float[MAXN], tmL = new float[MAXN], tmR = new float[MAXN];
        private final float[] lpfS = new float[8];       // loop filter states: high-pass (L,R x 2) and low-pass (L,R x 2)
        private float shBHz = -1, shBLo = -1;
        private double[] hpC = new double[5], lpC = new double[5];
        /** Room model: Cloud (soft, lush), Hall (big space, long pre-delay and tail), Plate (dense, bright, fast attack), Spring (springy "boing" of an amp). */
        public volatile int type = CLOUD;
        // per type: shortest RT60, range (x24 etc.), pre-delay s, damping, input bandwidth, tail cap s, modulation depth of the diffusers, wet gain
        private static final float[][] TP = {
                {0.6f, 24f, 0.022f, 0.50f, 0.80f, 2.5f, 0.70f, 1.25f},
                {1.2f, 12f, 0.048f, 0.36f, 0.70f, 4.5f, 0.60f, 1.10f},
                {0.4f, 10f, 0.003f, 0.92f, 0.97f, 2.0f, 0.70f, 1.20f},
                {0.5f, 8f, 0.000f, 0.50f, 0.80f, 2.5f, 0.70f, 1.00f},
                {1.5f, 14f, 0.020f, 0.40f, 0.85f, 6.0f, 0.75f, 1.10f}};
        // spring: a chain of all-passes (the dispersion that makes the "chirp") inside a short feedback loop, one spring per channel
        private final Line[] spApL = new Line[6], spApR = new Line[6];
        private final Line spLoopL, spLoopR;
        private float spLpL, spLpR;
        /** Optional low-pass / high-pass on the wet signal. */
        public final Tone tone, toneR;
        // all lengths in samples at 29761 Hz (Dattorro's reference rate), scaled to the engine rate
        private static final double REF = 29761.0;
        private static final int[] IN_AP = {142, 107, 379, 277};
        private static final float[] IN_G = {0.75f, 0.75f, 0.625f, 0.625f};

        private static final class Line {
            final float[] b; int w;
            Line(int len) { b = new float[Math.max(4, len)]; }
            /** Oldest sample: the output of a delay of b.length samples. Call push() right after. */
            float oldest() { return b[w]; }
            void push(float v) { b[w] = v; if (++w >= b.length) w = 0; }
            /** Sample written `t` samples ago (0 = most recent). */
            float tap(int t) {
                int i = w - 1 - Math.min(t, b.length - 1);
                if (i < 0) i += b.length;
                return b[i];
            }
            void clear() { java.util.Arrays.fill(b, 0f); w = 0; }
        }

        private final Line[] inAp = new Line[4];
        private final Line pre;
        private final Line apL, apR;          // modulated decay diffusers
        private final Line d1L, d1R;          // first delays
        private final Line ap2L, ap2R;        // second diffusers
        private final Line d2L, d2R;          // second delays
        private final int[] tapL = new int[7], tapR = new int[7];
        private final float modDepth;
        private final int apLBase, apRBase;
        private double lfoL, lfoR, lfo2L, lfo2R;
        private final double lfoIncL, lfoIncR, lfo2IncL, lfo2IncR;
        private final int ap2LBase, ap2RBase;
        private final float mod2Depth;
        private float lpIn, lpL, lpR, dcIn;
        private float rt60 = 2f, wet = 0f, decay = 0.5f;
        private boolean clean = true;
        private final float loopSeconds;

        private static int sc(int v, double k) { return Math.max(2, (int) Math.round(v * k)); }

        public Reverb(int rate) {
            super(rate);
            tone = new Tone(rate); toneR = new Tone(rate); mod = new WetMod(rate);
            double k = rate / REF;
            for (int i = 0; i < 4; i++) inAp[i] = new Line(sc(IN_AP[i], k));
            pre = new Line(Math.max(8, (int) (0.06 * rate)) + 8);
            double[] spMs = {1.1, 1.6, 2.3, 3.1, 4.1, 5.3};
            for (int i = 0; i < 6; i++) { spApL[i] = new Line((int) Math.round(spMs[i] * 0.001 * rate)); spApR[i] = new Line((int) Math.round(spMs[i] * 0.93 * 0.001 * rate)); }
            spLoopL = new Line((int) (0.033 * rate)); spLoopR = new Line((int) (0.0413 * rate));
            modDepth = (float) (14 * k);
            apLBase = sc(672, k); apRBase = sc(908, k);
            apL = new Line(apLBase + (int) modDepth + 4);
            apR = new Line(apRBase + (int) modDepth + 4);
            d1L = new Line(sc(4453, k)); d1R = new Line(sc(4217, k));
            mod2Depth = (float) (10 * k);
            ap2LBase = sc(1800, k); ap2RBase = sc(2656, k);
            ap2L = new Line(ap2LBase + (int) mod2Depth + 4); ap2R = new Line(ap2RBase + (int) mod2Depth + 4);
            d2L = new Line(sc(3720, k)); d2R = new Line(sc(3163, k));
            // output taps (Dattorro): read inside the opposite/own branch
            int[] tl = {266, 2974, 1913, 1996, 1990, 187, 1066};
            int[] tr = {353, 3627, 1228, 2673, 2111, 335, 121};
            for (int i = 0; i < 7; i++) { tapL[i] = sc(tl[i], k); tapR[i] = sc(tr[i], k); }
            lfoIncL = 2 * Math.PI * 0.43 / rate;
            lfoIncR = 2 * Math.PI * 0.61 / rate;
            lfo2IncL = 2 * Math.PI * 0.29 / rate;
            lfo2IncR = 2 * Math.PI * 0.37 / rate;
            lfoR = 1.9; lfo2L = 0.7; lfo2R = 3.4;
            loopSeconds = (float) ((672 + 4453 + 1800 + 3720 + 908 + 4217 + 2656 + 3163) / REF);
        }

        private void clear() {
            for (Line l : inAp) l.clear();
            for (Line q : spApL) q.clear(); for (Line q : spApR) q.clear(); spLoopL.clear(); spLoopR.clear(); spLpL = spLpR = 0f;
            pre.clear(); apL.clear(); apR.clear(); d1L.clear(); d1R.clear();
            ap2L.clear(); ap2R.clear(); d2L.clear(); d2R.clear();
            lpIn = lpL = lpR = dcIn = 0f; wet = 0f;
            if (zita != null) zita.clear();
            if (layers != null) for (GranShift g : layers) g.clear();
            java.util.Arrays.fill(fbL, 0f); java.util.Arrays.fill(fbR, 0f); java.util.Arrays.fill(lpfS, 0f);
            tone.clear(); toneR.clear();
            clean = true;
        }

        private static float frac(Line l, float d) {
            // fractional read, d samples behind the newest sample
            int i0 = (int) d;
            float f = d - i0;
            float a = l.tap(i0), b = l.tap(i0 + 1);
            return a + (b - a) * f;
        }

        private void springBlock(float[] l, float[] r, int n) {
            // feedback so the ring dies in about rt60: -60 dB over rt60 seconds, one trip = the loop delay
            final float fbL = (float) Math.min(0.94, Math.pow(10.0, -3.0 * (spLoopL.b.length / (double) rate) / Math.max(0.2, rt60)));
            final float fbR = (float) Math.min(0.94, Math.pow(10.0, -3.0 * (spLoopR.b.length / (double) rate) / Math.max(0.2, rt60)));
            final float kLp = 1f - (float) Math.exp(-2 * Math.PI * 3200.0 / rate);
            final float wetT = active ? (float) (1.0 * Math.pow(yIsMix ? 0.75f : y, 1.2)) : 0f;
            final float wetFall = (float) Math.exp(-9.2 / (Math.min(2.5f, Math.max(0.5f, rt60)) * rate));
            final float g = 0.62f;
            for (int i = 0; i < n; i++) {
                if (active) wet += (wetT - wet) * 0.002f; else wet *= wetFall;
                float in = active ? (l[i] + r[i]) * 0.5f : 0f;
                float hp = in - dcIn; dcIn += 0.003f * hp; in = hp;
                for (int ch = 0; ch < 2; ch++) {
                    Line[] ap = ch == 0 ? spApL : spApR;
                    Line loop = ch == 0 ? spLoopL : spLoopR;
                    float s = in + (ch == 0 ? fbL : fbR) * loop.oldest();
                    for (int a = 0; a < 6; a++) {
                        float d = ap[a].oldest(), v = s - g * d;
                        ap[a].push(v);
                        s = g * v + d;
                    }
                    float lp = ch == 0 ? spLpL : spLpR;
                    lp += kLp * (s - lp);
                    lp = lp / (1f + 0.4f * Math.abs(lp));                       // the spring tank is slightly non-linear
                    if (ch == 0) spLpL = lp; else spLpR = lp;
                    loop.push(lp);
                    float o = (ch == 0 ? toneApply(lp, true) : toneApply(lp, false)) * wet * 0.9f;
                    if (ch == 0) l[i] += o; else r[i] += o;
                }
            }
            if (!(spLpL == spLpL) || !(spLpR == spLpR) || Math.abs(spLpL) > 1e4f || Math.abs(spLpR) > 1e4f) clear();
        }
        private float toneApply(float v, boolean left) { return left ? tone.run(v) : toneR.run(v); }

        /** Chorus and pitch modulation: the chorus comes FIRST and feeds the reverb (input > chorus > reverb); the dry signal is untouched. */
        public final WetMod mod;
        private final float[] dryL = new float[MAXN], dryR = new float[MAXN], chL = new float[MAXN], chR = new float[MAXN];
        @Override public void process(float[] l, float[] r, int n, double bpm) {
            System.arraycopy(l, 0, dryL, 0, n); System.arraycopy(r, 0, dryR, 0, n);
            final boolean cm = mod.active();
            if (cm) {
                mod.process(l, r, n);                                   // l/r = the chorused input
                System.arraycopy(l, 0, chL, 0, n); System.arraycopy(r, 0, chR, 0, n);
            }
            processCore(l, r, n, bpm);                                  // l/r = chorused input + reverb
            if (cm) for (int i = 0; i < n; i++) { l[i] += dryL[i] - chL[i]; r[i] += dryR[i] - chR[i]; }   // keep only the reverb on top of the real dry
            blendSend(l, r, dryL, dryR, n);
        }

        private static void biquad(double[] c, boolean high, double hz, int rate) {
            final double w0 = 2 * Math.PI * Math.min(hz, rate * 0.45) / rate, cs = Math.cos(w0), al = Math.sin(w0) / (2 * 0.7071);
            final double b0, b1, b2;
            if (high) { b0 = (1 + cs) / 2; b1 = -(1 + cs); b2 = (1 + cs) / 2; } else { b0 = (1 - cs) / 2; b1 = 1 - cs; b2 = (1 - cs) / 2; }
            final double a0 = 1 + al;
            c[0] = b0 / a0; c[1] = b1 / a0; c[2] = b2 / a0; c[3] = -2 * cs / a0; c[4] = (1 - al) / a0;
        }
        /** lpfS layout per filter x channel: z1, z2 (direct form II transposed). */
        private static float bq(double[] c, float[] st, int o, float x) {
            final float y = (float) (c[0] * x) + st[o];
            st[o] = (float) (c[1] * x - c[3] * y) + st[o + 1];
            st[o + 1] = (float) (c[2] * x - c[4] * y);
            return y;
        }

        /** Shimmer: a Zita FDN reverb whose output is pitch-shifted by granular layers and fed back into its input. */
        private void shimmerBlock(float[] l, float[] r, int n, float wetT, float wetFall) {
            if (zita == null) {
                zita = new ZitaRev(rate);
                layers = new GranShift[]{new GranShift(rate, 70, 8, 5f), new GranShift(rate, 60, 8, 5f), new GranShift(rate, 90, 8, 5f), new GranShift(rate, 60, 8, 5f)};
            }
            if (active) rt60 += (Math.max(1f, Math.min(8f, 1f + 7f * x)) - rt60) * 0.05f;
            final float rtz = Math.max(1f, Math.min(8f, rt60));
            zita.setDecay(rtz);
            zita.setLowRT60(Math.max(1f, Math.min(8f, rtz * sh[12])));
            zita.setHFDamping(Math.max(1500f, Math.min(12000f, sh[13])));
            final float fb = Math.max(0f, Math.min(0.9f, sh[0]));
            for (int i = 0; i < n; i++) {
                final float inL = active ? l[i] : 0f, inR = active ? r[i] : 0f;
                zInL[i] = inL + fbL[i] * fb; zInR[i] = inR + fbR[i] * fb;
            }
            zita.process(zInL, zInR, zWL, zWR, n);
            // audible wet
            for (int i = 0; i < n; i++) {
                if (active) wet += (wetT - wet) * 0.002f; else wet *= wetFall;
                l[i] += tone.run(zWL[i]) * wet * 1.2f;
                r[i] += toneR.run(zWR[i]) * wet * 1.2f;
            }
            // feedback: loop filters, then the pitched layers
            if (sh[14] != shBHz || sh[15] != shBLo) { shBHz = sh[14]; shBLo = sh[15]; biquad(hpC, true, shBHz, rate); biquad(lpC, false, shBLo, rate); }
            for (int i = 0; i < n; i++) {
                float a = bq(hpC, lpfS, 0, zWL[i]), b = bq(hpC, lpfS, 2, zWR[i]);
                tmL[i] = bq(lpC, lpfS, 4, a); tmR[i] = bq(lpC, lpfS, 6, b);
            }
            java.util.Arrays.fill(fbL, 0, n, 0f); java.util.Arrays.fill(fbR, 0, n, 0f);
            for (int k = 0; k < 4; k++) {
                final int o = k == 0 ? 1 : k == 1 ? 4 : k == 2 ? 7 : 10;
                if (k > 0 && sh[o - 1] < 0.5f) continue;                  // B, C and D can be switched off
                layers[k].setSemitones(sh[o]);
                layers[k].process(tmL, tmR, zWL, zWR, n);                 // zW is free again here
                final float g = sh[o + 1];
                for (int i = 0; i < n; i++) { fbL[i] += zWL[i] * g; fbR[i] += zWR[i] * g; }
            }
            for (int i = 0; i < n; i++) {
                fbL[i] = (float) Math.tanh(fbL[i] * 0.85f * 1.5f);
                fbR[i] = (float) Math.tanh(fbR[i] * 0.85f * 1.5f);
            }
            if (!(fbL[0] == fbL[0]) || Math.abs(fbL[n - 1]) > 1e3f) clear();
        }
        { wetMix = 0.5f; }
        private void processCore(float[] l, float[] r, int n, double bpm) {
            if (!active && wet < 1e-4f) {
                if (!clean) clear();
                return;
            }
            clean = false;
            tone.block(); toneR.mode = tone.mode; toneR.cut = tone.cut; toneR.block();
            final float[] tp = TP[Math.max(0, Math.min(4, type))];
            if (active) {
                float rtT = tp[0] * (float) Math.pow(tp[1], x);
                rt60 += (rtT - rt60) * 0.05f;
            }
            final int preN = Math.max(1, (int) (tp[2] * rate));
            // calibrated so the measured RT60 matches the requested one
            decay = (float) Math.min(0.985, Math.pow(10.0, -3.0 * loopSeconds / (4.0 * Math.max(0.2, rt60))));
            final float dd2 = Math.max(0.25f, Math.min(0.5f, decay + 0.15f));
            final float wetT = active ? (float) (tp[7] * Math.pow(yIsMix ? 0.75f : y, 1.3)) : 0f;
            final float tail = Math.min(tp[5], Math.max(0.5f, rt60));
            final float wetFall = (float) Math.exp(-9.2 / (tail * rate));      // -80 dB over `tail` seconds
            final float damp = tp[3];
            final float bw = tp[4];
            final float gMod = tp[6];
            if (type == SHIMMER) { shimmerBlock(l, r, n, wetT, wetFall); return; }
            if (type == SPRING) { springBlock(l, r, n); return; }
            for (int i = 0; i < n; i++) {
                if (active) wet += (wetT - wet) * 0.002f; else wet *= wetFall;

                float in = active ? (l[i] + r[i]) * 0.5f : 0f;
                float hp = in - dcIn; dcIn += 0.003f * hp; in = hp;
                pre.push(in); float pd = pre.tap(preN);
                lpIn += bw * (pd - lpIn);
                float s = lpIn;
                for (int a = 0; a < 4; a++) {
                    Line ln = inAp[a];
                    float d = ln.oldest();
                    float v = s - IN_G[a] * d;
                    ln.push(v);
                    s = IN_G[a] * v + d;
                }

                float feedL = d2R.oldest() * decay;      // each branch feeds the other
                float feedR = d2L.oldest() * decay;

                // ---- left branch
                lfoL += lfoIncL; if (lfoL > 6.283185307179586) lfoL -= 6.283185307179586;
                float dm = apLBase + modDepth * (float) Math.sin(lfoL);
                float d = frac(apL, dm);
                float v = (s + feedL) - gMod * d;
                apL.push(v);
                float y1 = gMod * v + d;
                float o1 = d1L.oldest(); d1L.push(y1);
                lpL += damp * (o1 - lpL);
                float z = lpL * decay;
                lfo2L += lfo2IncL; if (lfo2L > 6.283185307179586) lfo2L -= 6.283185307179586;
                float o2 = frac(ap2L, ap2LBase + mod2Depth * (float) Math.sin(lfo2L));
                float v2 = z - dd2 * o2;
                ap2L.push(v2);
                d2L.push(dd2 * v2 + o2);

                // ---- right branch
                lfoR += lfoIncR; if (lfoR > 6.283185307179586) lfoR -= 6.283185307179586;
                dm = apRBase + modDepth * (float) Math.sin(lfoR);
                d = frac(apR, dm);
                v = (s + feedR) - gMod * d;
                apR.push(v);
                y1 = gMod * v + d;
                o1 = d1R.oldest(); d1R.push(y1);
                lpR += damp * (o1 - lpR);
                z = lpR * decay;
                lfo2R += lfo2IncR; if (lfo2R > 6.283185307179586) lfo2R -= 6.283185307179586;
                o2 = frac(ap2R, ap2RBase + mod2Depth * (float) Math.sin(lfo2R));
                v2 = z - dd2 * o2;
                ap2R.push(v2);
                d2R.push(dd2 * v2 + o2);

                float outL = d1R.tap(tapL[0]) + d1R.tap(tapL[1]) - ap2R.tap(tapL[2]) + d2R.tap(tapL[3])
                        - d1L.tap(tapL[4]) - ap2L.tap(tapL[5]) - d2L.tap(tapL[6]);
                float outR = d1L.tap(tapR[0]) + d1L.tap(tapR[1]) - ap2L.tap(tapR[2]) + d2L.tap(tapR[3])
                        - d1R.tap(tapR[4]) - ap2R.tap(tapR[5]) - d2R.tap(tapR[6]);
                l[i] += tone.run(outL) * wet * 0.6f;
                r[i] += toneR.run(outR) * wet * 0.6f;
            }
            if (!(lpL == lpL) || !(lpR == lpR) || Math.abs(lpL) > 1e4f || Math.abs(lpR) > 1e4f) clear();
        }
    }
}
