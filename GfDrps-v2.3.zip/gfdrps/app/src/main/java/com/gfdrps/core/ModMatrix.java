package com.gfdrps.core;

import java.util.ArrayList;
import java.util.List;

/**
 * Modulation matrix: routes the outputs of the Turing machines to any mappable parameter (track level, pan, pitch, envelope,
 * effect pads and effect options, master volume, tempo, compressor...). Each route has a depth (+/-) and can be switched off.
 * The value the user set is kept as the base: while a route is active the parameter = base + modulation; moving the control
 * by hand moves the base.
 */
public final class ModMatrix {
    public interface Getter { float get(); }
    public interface Setter { void set(float v); }
    public static final class Dest {
        public final String name; public final float min, max; final Getter g; final Setter st;
        Dest(String name, float min, float max, Getter g, Setter st) { this.name = name; this.min = min; this.max = max; this.g = g; this.st = st; }
    }
    public static final class Route {
        public volatile int machine = 0, source = 0, dest = 0;
        public volatile float depth = 0.5f;
        public volatile boolean on = true;
        public Route(int m, int s, int d, float depth) { machine = m; source = s; dest = d; this.depth = depth; }
    }

    public static final int MACHINES = 2, MAX_ROUTES = 16;
    public final Turing[] tm = new Turing[MACHINES];
    public final List<Route> routes = new java.util.concurrent.CopyOnWriteArrayList<>();
    public final List<Dest> dests = new ArrayList<>();
    private final float[] base, applied, acc;
    private final boolean[] driven;
    private boolean[] now;

    public ModMatrix(Engine e) {
        tm[0] = new Turing(1); tm[1] = new Turing(2);
        tm[1].rateIndex = 5; tm[1].length = 5;
        final String[] fxn = {"Distorção", "Filtro", "Amp mod", "Delay", "Reverb", "Roll", "Stutter", "Ring mod", "Crush"};
        for (int i = 0; i < Engine.SLOTS; i++) {
            final Slot s = e.slots[i];
            final String p = "T" + (i + 1) + " ";
            add(p + "Volume", 0, 1, () -> s.volume, v -> s.volume = v);
            add(p + "Pan", 0, 1, () -> s.pan, v -> s.pan = v);
            add(p + "Pitch (st)", -12, 12, () -> s.fine, v -> s.fine = v);
            add(p + "Attack", 0, 1, () -> s.attack, v -> s.attack = v);
            add(p + "Decay", 0, 1, () -> s.decay, v -> s.decay = v);
            add(p + "Sustain", 0, 1, () -> s.sustain, v -> s.sustain = v);
            add(p + "Release", 0, 1, () -> s.release, v -> s.release = v);
            add(p + "Grão (Bow)", 0, 1, () -> s.bowSize, v -> s.bowSize = v);
            for (int f = 0; f < Fx.COUNT; f++) {
                final Fx.Effect ef = s.fx[f];
                add(p + fxn[f] + " X", 0, 1, () -> ef.x, v -> ef.x = v);
                add(p + fxn[f] + " Y", 0, 1, () -> ef.y, v -> ef.y = v);
            }
            final Fx.Filter fl = (Fx.Filter) s.fx[Fx.FILTER];
            add(p + "Filtro env. quantidade", -1, 1, () -> fl.envAmount, v -> fl.envAmount = v);
            final Fx.Delay dl = (Fx.Delay) s.fx[Fx.DELAY];
            add(p + "Delay pitch", -12, 12, () -> dl.pitch, v -> dl.pitch = v);
            add(p + "Delay difusão", 0, 1, () -> dl.diffusion, v -> dl.diffusion = v);
            add(p + "Delay filtro", 0, 1, () -> dl.tone.cut, v -> dl.tone.cut = v);
            final Fx.Reverb rv = (Fx.Reverb) s.fx[Fx.REVERB];
            add(p + "Reverb chorus", 0, 1, () -> rv.mod.chorus, v -> rv.mod.chorus = v);
            add(p + "Reverb mod. pitch", 0, 1, () -> rv.mod.pitchMod, v -> rv.mod.pitchMod = v);
            add(p + "Reverb filtro", 0, 1, () -> rv.tone.cut, v -> rv.tone.cut = v);
        }
        add("Master volume", 0, 1, () -> e.masterVolume, v -> e.masterVolume = v);
        add("Tempo (BPM)", 40, 240, () -> (float) e.bpm, v -> e.bpm = v);
        for (int f = 0; f < Fx.COUNT; f++) {
            final Fx.Effect ef = e.master[f];
            add("Master " + fxn[f] + " X", 0, 1, () -> ef.x, v -> ef.x = v);
            add("Master " + fxn[f] + " Y", 0, 1, () -> ef.y, v -> ef.y = v);
        }
        add("Compressor threshold", -40, 0, () -> e.dyn.threshDb, v -> e.dyn.threshDb = v);
        add("Compressor makeup", 0, 18, () -> e.dyn.makeupDb, v -> e.dyn.makeupDb = v);
        add("Limiter teto", -12, 0, () -> e.dyn.ceilingDb, v -> e.dyn.ceilingDb = v);
        base = new float[dests.size()]; applied = new float[dests.size()]; acc = new float[dests.size()];
        driven = new boolean[dests.size()]; now = new boolean[dests.size()];
        java.util.Arrays.fill(base, Float.NaN);
    }

    private void add(String name, float min, float max, Getter g, Setter st) { dests.add(new Dest(name, min, max, g, st)); }

    public int destCount() { return dests.size(); }
    public boolean anyOn() { for (Turing t : tm) if (t.on) return true; return false; }

    /** Index of a destination by name (for saved projects), or -1. */
    public int destIndex(String name) { for (int i = 0; i < dests.size(); i++) if (dests.get(i).name.equals(name)) return i; return -1; }

    /** Called once per audio block from the engine thread. */
    public void process(int n, double bpm, int rate) {
        for (Turing t : tm) t.process(n, bpm, rate);
        java.util.Arrays.fill(acc, 0f);
        final boolean[] now = this.now; java.util.Arrays.fill(now, false);
        for (Route r : routes) {
            if (!r.on || r.dest < 0 || r.dest >= dests.size() || r.machine < 0 || r.machine >= MACHINES) continue;
            Turing t = tm[r.machine];
            if (!t.on) continue;
            Dest d = dests.get(r.dest);
            float src = t.source(r.source);
            acc[r.dest] += src * r.depth * (d.max - d.min);
            now[r.dest] = true;
        }
        for (int i = 0; i < dests.size(); i++) {
            Dest d = dests.get(i);
            if (now[i]) {
                float cur = d.g.get();
                if (!driven[i] || Math.abs(cur - applied[i]) > 1e-4f * (d.max - d.min)) base[i] = cur;   // the user moved it: new base
                float v = Math.max(d.min, Math.min(d.max, base[i] + acc[i]));
                d.st.set(v); applied[i] = d.g.get(); driven[i] = true;
            } else if (driven[i]) {                                  // route removed or machine off: hand the value back
                if (Math.abs(d.g.get() - applied[i]) <= 1e-4f * (d.max - d.min)) d.st.set(base[i]);
                driven[i] = false;
            }
        }
    }
}
