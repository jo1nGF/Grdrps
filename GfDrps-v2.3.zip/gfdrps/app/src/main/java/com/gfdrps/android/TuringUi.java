package com.gfdrps.android;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.Toast;

import com.gfdrps.core.Engine;
import com.gfdrps.core.ModMatrix;
import com.gfdrps.core.Slot;
import com.gfdrps.core.Turing;

import java.util.Locale;

/** Panel for the two Turing Machines and the modulation matrix (routes from their outputs to any mappable parameter). */
final class TuringUi {
    private final Activity act;
    private final Engine engine;
    private int mi = 0;
    private Panel panel;

    private TuringUi(Activity a, Engine e) { act = a; engine = e; }

    static void show(Activity a, Engine e) { new TuringUi(a, e).open(); }

    private void open() {
        panel = new Panel(act, "Turing Machine · modulação");
        panel.build(this::build);
        panel.show();
    }

    private void build() {
        final Panel p = panel;
        final Turing t = engine.mod.tm[mi];
        final int col = 0xFF2FE0C8, col2 = 0xFFFFD23F;
        final Locale us = Locale.US;
        p.label("Máquina");
        p.row().tile(-1, "Turing 1", mi == 0, col, () -> mi = 0).tile(-1, "Turing 2", mi == 1, col, () -> mi = 1)
                .wide(Theme.I_PLAY, t.on ? "Ligada" : "Desligada", t.on, col, () -> t.on = !t.on);
        p.label("Registrador de 16 bits (toque para inverter um bit; o bit 0 é o mais novo)");
        for (int rowI = 0; rowI < 2; rowI++) {
            p.row();
            for (int i = 0; i < 8; i++) {
                final int bit = 15 - (rowI * 8 + i);
                final boolean on = ((t.reg >> bit) & 1) != 0;
                final boolean inLoop = bit < t.length;
                p.tile(-1, on ? "1" : "0", on, inLoop ? col : 0xFF6B7380, () -> t.flipBit(bit));
            }
        }
        p.row().wide(Theme.I_DICE, "Randomizar", false, col, t::randomize)
                .wide(Theme.I_CLEAR, "Zerar clock", false, col, t::reset)
                .wide(Theme.I_LAYER, t.write ? (t.writeBit ? "Escrevendo 1" : "Escrevendo 0") : "Write: off", t.write, col2, () -> {
                    if (!t.write) { t.write = true; t.writeBit = true; } else if (t.writeBit) t.writeBit = false; else t.write = false;
                });
        p.label("Probabilidade: 1 = loop travado · 0,5 = aleatório · 0 = travado e invertido (dobra o ciclo)");
        p.slider(Theme.I_DICE, col, t.knob, 0.75f, v -> String.format(us, "Knob %.2f", v) + (Math.abs(v - 0.5f) > 0.46f ? " (loop)" : ""), v -> t.knob = v);
        p.slider(Theme.I_GRID, col, (t.length - 2) / 14f, 6f / 14f, v -> "Tamanho " + (2 + Math.round(v * 14f)) + " passos", v -> t.length = 2 + Math.round(v * 14f));
        p.row().wide(Theme.I_CLOCK, t.sync ? "Clock: sincronizado ao BPM" : "Clock: livre (Hz)", t.sync, col, () -> t.sync = !t.sync);
        if (t.sync) {
            p.slider(Theme.I_CLOCK, col, t.rateIndex / (float) (Turing.RATES.length - 1), 7f / 9f,
                    v -> noteName(Turing.RATES[Math.round(v * (Turing.RATES.length - 1))]), v -> t.rateIndex = Math.round(v * (Turing.RATES.length - 1)));
        } else {
            p.slider(Theme.I_CLOCK, col, (float) (Math.log(t.hz / 0.1f) / Math.log(200.0)), 0.57f,
                    v -> String.format(us, "%.2f Hz", 0.1 * Math.pow(200.0, v)), v -> t.hz = (float) (0.1 * Math.pow(200.0, v)));
        }
        p.slider(Theme.I_GLIDE, col, t.slew, 0f, v -> v < 0.01f ? "Slew: degraus" : String.format(us, "Slew %d %%", Math.round(v * 100)), v -> t.slew = v);
        p.slider(Theme.I_GATE, col, t.gateLen, 0.5f, v -> "Gate " + Math.round(v * 100) + " %", v -> t.gateLen = v);
        p.slider(Theme.I_LAYER, col, t.swing / 0.6f, 0f, v -> "Swing " + Math.round(v * 60) + " %", v -> t.swing = v * 0.6f);
        p.row().wide(Theme.I_PAN, t.bipolar ? "Saída bipolar (−1…+1)" : "Saída unipolar (0…1)", t.bipolar, col, () -> t.bipolar = !t.bipolar)
                .wide(Theme.I_KEYS, t.quantize ? "CV1 quantizado" : "CV1 contínuo", t.quantize, col, () -> t.quantize = !t.quantize);
        if (t.quantize) {
            p.slider(Theme.I_KEYS, col, t.scale / (float) (Slot.SCALE_NAMES.length - 1), 1f / 15f,
                    v -> Slot.SCALE_NAMES[Math.round(v * (Slot.SCALE_NAMES.length - 1))], v -> t.scale = Math.round(v * (Slot.SCALE_NAMES.length - 1)));
            p.slider(Theme.I_GRID, col, (t.spanOctaves - 1) / 3f, 1f / 3f, v -> (1 + Math.round(v * 3)) + " oitava(s) de extensão", v -> t.spanOctaves = 1 + Math.round(v * 3));
        }
        p.label("Pulsos (expansor): " + String.join(" · ", Turing.PULSE_INFO));

        p.label("Rotas de modulação (a saída move o parâmetro ao redor do valor que você ajustou)");
        int n = 0;
        for (final ModMatrix.Route r : engine.mod.routes) {
            final int idx = n++;
            String dn = r.dest >= 0 && r.dest < engine.mod.dests.size() ? engine.mod.dests.get(r.dest).name : "?";
            p.label((idx + 1) + ". Turing " + (r.machine + 1) + " · " + Turing.SRC_NAMES[Math.max(0, Math.min(Turing.SRC_PER_MACHINE - 1, r.source))] + "  →  " + dn);
            p.row().wide(Theme.I_PLAY, r.on ? "Ativa" : "Pausada", r.on, col, () -> r.on = !r.on)
                    .tile(Theme.I_TRASH, null, false, 0xFFFF4D5E, () -> engine.mod.routes.remove(r));
            p.slider(Theme.I_MIX, col2, (r.depth + 1f) / 2f, 0.75f, v -> String.format(us, "Profundidade %+d %%", Math.round((v * 2f - 1f) * 100f)), v -> r.depth = v * 2f - 1f);
        }
        if (engine.mod.routes.size() < ModMatrix.MAX_ROUTES)
            p.row().wide(Theme.I_LINK, "Adicionar rota…", false, col2, this::addRoute);
        else p.label("Máximo de " + ModMatrix.MAX_ROUTES + " rotas.");
    }

    private static String noteName(int perBar) {
        return perBar == 1 ? "1 compasso" : (perBar % 3 == 0 ? "1/" + (perBar * 2 / 3) + "T" : "1/" + perBar);
    }

    private void addRoute() {
        final String[] src = new String[ModMatrix.MACHINES * Turing.SRC_PER_MACHINE];
        for (int m = 0; m < ModMatrix.MACHINES; m++)
            for (int k = 0; k < Turing.SRC_PER_MACHINE; k++) src[m * Turing.SRC_PER_MACHINE + k] = "Turing " + (m + 1) + " · " + Turing.SRC_NAMES[k];
        new AlertDialog.Builder(act).setTitle("Fonte de modulação").setItems(src, (d, w) -> {
            final int machine = w / Turing.SRC_PER_MACHINE, source = w % Turing.SRC_PER_MACHINE;
            final String[] names = new String[engine.mod.dests.size()];
            for (int i = 0; i < names.length; i++) names[i] = engine.mod.dests.get(i).name;
            new AlertDialog.Builder(act).setTitle("Enviar para…").setItems(names, (d2, w2) -> {
                engine.mod.routes.add(new ModMatrix.Route(machine, source, w2, 0.5f));
                engine.mod.tm[machine].on = true;
                Toast.makeText(act, "Rota criada: " + src[w] + " → " + names[w2], Toast.LENGTH_SHORT).show();
                panel.refresh();
            }).show();
        }).show();
    }
}
