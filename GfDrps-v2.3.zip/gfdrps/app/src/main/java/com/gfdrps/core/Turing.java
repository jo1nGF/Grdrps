package com.gfdrps.core;

/**
 * A Turing Machine (after the Music Thing Modular design) used as a modulation source: a 16-bit shift register that is
 * clocked in time with the project tempo. Every clock the register shifts and a new bit enters:
 *  - knob at 1: the loop is locked (the bit that falls off the end comes back);
 *  - knob at 0.5: the new bit is completely random;
 *  - knob at 0: the loop is locked but inverted (so the pattern repeats after twice the length);
 *  - in between: a growing chance that the bit is replaced by a random one (slow mutation).
 * The register is read by DACs: CV1 = the 8 newest bits, CV2 = the 8 older bits, CV3 = CV1 at half range. A pulse expander
 * gives six gates from logic of different bits. Outputs can be slewed and quantised to a musical scale, and every output is a
 * modulation source in the {@link ModMatrix}.
 */
public final class Turing {
    public static final int SRC_PER_MACHINE = 12;           // CV1, CV2, CV3, CV1 quantised, gates P1..P6, clock, register bit 0
    public static final String[] SRC_NAMES = {"CV1", "CV2", "CV3", "CV1 quant.", "Pulso 1", "Pulso 2", "Pulso 3", "Pulso 4", "Pulso 5", "Pulso 6", "Clock", "Bit 0"};
    public static final String[] PULSE_INFO = {"bit 0", "bit 1", "bit 0 E bit 1", "bit 0 XOR bit 2", "bit 3 OU bit 5", "bit 0 E NÃO bit 4"};
    /** Clock rates in notes per bar (same grid as the rest of the app). */
    public static final int[] RATES = {1, 2, 3, 4, 6, 8, 12, 16, 24, 32};

    public volatile boolean on = false;
    /** 0..1, see class comment. */
    public volatile float knob = 0.75f;
    /** Register length in steps, 2..16. */
    public volatile int length = 8;
    public volatile int rateIndex = 7;
    public volatile boolean sync = true;
    /** Free clock in Hz when sync is off. */
    public volatile float hz = 4f;
    /** Output smoothing 0 (steps) .. 1 (very slow glide). */
    public volatile float slew = 0f;
    public volatile boolean bipolar = false;
    public volatile boolean quantize = false;
    public volatile int scale = 1, spanOctaves = 2, root = 0;
    /** While true the machine writes `writeBit` instead of a new bit (a held "write" switch). */
    public volatile boolean write = false, writeBit = false;
    /** Gate length as a fraction of a step. */
    public volatile float gateLen = 0.5f;
    /** Swing: delays every second step (0..0.6 of a step). */
    public volatile float swing = 0f;

    /** The register (16 bits), visible to the UI. */
    public volatile int reg = 0x5A3C;
    public volatile int stepIndex = 0;
    public volatile float cv1, cv2, cv3, cv1q;
    public final boolean[] gates = new boolean[6];
    public volatile boolean clockHigh;

    private final java.util.Random rng;
    private double phase;
    private int stepCount;
    private float s1, s2, s3, s4;
    private boolean pendingStep;

    public Turing(long seed) { rng = new java.util.Random(seed); randomize(); }

    public void randomize() { reg = rng.nextInt(1 << 16); }
    public void flipBit(int i) { reg ^= 1 << (Math.max(0, Math.min(15, i))); }
    public void reset() { phase = 0; stepCount = 0; }

    private static double stepsPerBeat(int idx) { return RATES[Math.max(0, Math.min(RATES.length - 1, idx))] / 4.0; }

    /** Advances the machine by n frames. Returns after updating all outputs. */
    public void process(int n, double bpm, int rate) {
        if (!on) { for (int i = 0; i < 6; i++) gates[i] = false; clockHigh = false; return; }
        final double stepsPerSec = sync ? stepsPerBeat(rateIndex) * Math.max(20.0, bpm) / 60.0 : Math.max(0.05, hz);
        // swing: odd steps are pushed later, even steps earlier, so the average rate stays the same
        double len = 1.0 + ((stepCount & 1) == 0 ? swing : -swing);
        phase += n * stepsPerSec / rate / Math.max(0.2, len);
        int guard = 0;
        while (phase >= 1.0 && guard++ < 8) { phase -= 1.0; clock(); }
        final float gl = Math.max(0.05f, Math.min(0.95f, gateLen));
        clockHigh = phase < gl;
        final int r = reg;
        for (int i = 0; i < 6; i++) gates[i] = clockHigh && pulse(i, r);
        // slewed outputs (one pole per block)
        final float a = slew <= 0.001f ? 1f : (float) (1.0 - Math.exp(-n / (rate * (0.005 + slew * slew * 1.5))));
        s1 += (target(cv8(r, 0)) - s1) * a;
        s2 += (target(cv8(r, 8)) - s2) * a;
        s3 += (target(cv8(r, 0) * 0.5f) - s3) * a;
        s4 += (target(quant(cv8(r, 0))) - s4) * a;
        cv1 = s1; cv2 = s2; cv3 = s3; cv1q = s4;
    }

    private float target(float v) { return bipolar ? v * 2f - 1f : v; }

    /** 8 bits starting at `shift`, weighted like a DAC (newest bit = most significant), 0..1. */
    static float cv8(int reg, int shift) {
        int v = 0;
        for (int i = 0; i < 8; i++) if (((reg >> (shift + i)) & 1) != 0) v |= 1 << (7 - i);
        return v / 255f;
    }

    private float quant(float v) {
        int[] iv = Slot.SCALES[Math.max(0, Math.min(Slot.SCALES.length - 1, scale))];
        int span = Math.max(1, Math.min(4, spanOctaves));
        int notes = iv.length * span;
        int deg = Math.min(notes - 1, (int) (v * notes));
        int semi = Math.floorDiv(deg, iv.length) * 12 + iv[Math.floorMod(deg, iv.length)];
        return semi / (12f * span);
    }

    private static boolean bit(int r, int i) { return ((r >> i) & 1) != 0; }

    private static boolean pulse(int k, int r) {
        switch (k) {
            case 0: return bit(r, 0);
            case 1: return bit(r, 1);
            case 2: return bit(r, 0) && bit(r, 1);
            case 3: return bit(r, 0) ^ bit(r, 2);
            case 4: return bit(r, 3) || bit(r, 5);
            default: return bit(r, 0) && !bit(r, 4);
        }
    }

    private void clock() {
        int len = Math.max(2, Math.min(16, length));
        int r = reg;
        boolean old = bit(r, len - 1);
        boolean nb;
        if (write) nb = writeBit;
        else {
            float k = Math.max(0f, Math.min(1f, knob));
            float keep = Math.abs(2f * k - 1f);                         // 1 at either end: the loop is kept
            if (rng.nextFloat() < keep) nb = k >= 0.5f ? old : !old;
            else nb = rng.nextBoolean();
        }
        r = ((r << 1) | (nb ? 1 : 0)) & 0xFFFF;
        reg = r;
        stepIndex = (stepIndex + 1) % len;
        stepCount++;
    }

    /** Value of modulation source k (0..SRC_PER_MACHINE-1), -1..1 if bipolar else 0..1. */
    public float source(int k) {
        switch (k) {
            case 0: return quantize ? cv1q : cv1;
            case 1: return cv2;
            case 2: return cv3;
            case 3: return cv1q;
            case 4: case 5: case 6: case 7: case 8: case 9: return gates[k - 4] ? 1f : 0f;
            case 10: return clockHigh ? 1f : 0f;
            default: return bit(reg, 0) ? 1f : 0f;
        }
    }

    public String serialize() {
        return (on ? 1 : 0) + "," + knob + "," + length + "," + rateIndex + "," + (sync ? 1 : 0) + "," + hz + "," + slew + "," + (bipolar ? 1 : 0) + ","
                + (quantize ? 1 : 0) + "," + scale + "," + spanOctaves + "," + root + "," + gateLen + "," + swing + "," + reg;
    }

    public void load(String t) {
        if (t == null) return;
        try {
            String[] p = t.split(",");
            if (p.length < 15) return;
            on = p[0].equals("1"); knob = Float.parseFloat(p[1]); length = Integer.parseInt(p[2]); rateIndex = Integer.parseInt(p[3]);
            sync = p[4].equals("1"); hz = Float.parseFloat(p[5]); slew = Float.parseFloat(p[6]); bipolar = p[7].equals("1");
            quantize = p[8].equals("1"); scale = Integer.parseInt(p[9]); spanOctaves = Integer.parseInt(p[10]); root = Integer.parseInt(p[11]);
            gateLen = Float.parseFloat(p[12]); swing = Float.parseFloat(p[13]); reg = Integer.parseInt(p[14]);
        } catch (RuntimeException ignored) { }
    }
}
