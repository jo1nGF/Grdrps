package com.gfdrps.android;

import android.annotation.SuppressLint;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import com.gfdrps.core.Engine;

/**
 * Records the audio that OTHER apps are playing (Android 10+ "audio playback capture") into the engine's recording buffer,
 * so it can be resampled into a track. Needs RECORD_AUDIO and a MediaProjection grant. The capture runs while the user
 * switches to the other app, kept alive by {@link CaptureService}. Apps can opt out of being captured and DRM-protected audio
 * is silent: that is an Android rule, not something this app can change.
 */
final class AppCapture {
    interface Listener { void onFailed(String why); void onEnded(); }

    private static Engine engine;
    private static Listener listener;
    private static MediaProjection projection;
    private static AudioRecord rec;
    private static volatile boolean running;
    private static Thread thread;

    private AppCapture() { }

    static void setTarget(Engine e, Listener l) { engine = e; listener = l; }
    static boolean isRunning() { return running; }

    @SuppressLint("MissingPermission")
    static synchronized void start(MediaProjection mp) {
        stopInternal();
        if (Build.VERSION.SDK_INT < 29 || engine == null) { fail("Requer Android 10 ou mais novo"); return; }
        projection = mp;
        try {
            mp.registerCallback(new MediaProjection.Callback() {
                @Override public void onStop() { stopInternal(); if (listener != null) listener.onEnded(); }
            }, new Handler(Looper.getMainLooper()));
            final int rate = engine.rate;
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(mp)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .excludeUid(Process.myUid())                 // never record this app's own output (it would feed back)
                    .build();
            AudioFormat fmt = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build();
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord.Builder().setAudioFormat(fmt).setAudioPlaybackCaptureConfig(cfg)
                    .setBufferSizeInBytes(Math.max(min, rate * 4)).build();
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) { fail("Não foi possível abrir a captura de áudio"); return; }
            rec.startRecording();
        } catch (Throwable t) {
            fail("Captura indisponível: " + t.getClass().getSimpleName());
            return;
        }
        running = true;
        final AudioRecord r = rec;
        final Engine e = engine;
        thread = new Thread(() -> {
            short[] s = new short[2048];
            float[] f = new float[1024];
            while (running) {
                int n = r.read(s, 0, s.length);                 // interleaved stereo
                if (n <= 0) continue;
                int frames = n / 2;
                for (int i = 0; i < frames; i++) f[i] = (s[2 * i] + s[2 * i + 1]) * (0.5f / 32768f);
                e.pushInput(f, frames);
            }
        }, "gfdrps-appcap");
        thread.start();
    }

    private static void fail(String why) {
        stopInternal();
        if (listener != null) listener.onFailed(why);
    }

    static synchronized void stopInternal() {
        running = false;
        if (thread != null) { try { thread.join(500); } catch (InterruptedException ignored) { } thread = null; }
        if (rec != null) { try { rec.stop(); } catch (Exception ignored) { } rec.release(); rec = null; }
        if (projection != null) { try { projection.stop(); } catch (Exception ignored) { } projection = null; }
    }
}
