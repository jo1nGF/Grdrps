package com.gfdrps.core;

/**
 * Granular pitch shifter (overlapping Hann grains read from a circular buffer at a different speed), stereo.
 * Port of GranularPitchShift from "Shimmer-Reverb" (c) 2025 Danial Kooshki (MIT licence).
 */
public final class GranShift {
    private final int grainSize, numVoices, hopSize, lookback, jitter;
    private final float[][] circ;
    private final int circSize;
    private final float[] window;
    private final double[] voicePhase;
    private final int[] voiceAge, voiceDelay;
    private int writePos, nextTrig;
    private float semitones, zPrev;
    private double pitchRatioSmoothed = 1.0;
    private long seed = 0xC0FFEEL;

    public GranShift(int rate, int grainMs, int voices, float jitterMs) {
        grainSize = Math.max(32, Math.round(grainMs * rate * 0.001f));
        numVoices = Math.max(2, Math.min(16, voices));
        jitter = Math.round(jitterMs * rate * 0.001f);
        lookback = grainSize;
        circSize = grainSize * 4 + lookback + 8;
        circ = new float[2][circSize];
        window = new float[grainSize];
        for (int i = 0; i < grainSize; i++) window[i] = (float) (0.5 - 0.5 * Math.cos(2.0 * Math.PI * i / grainSize));
        voicePhase = new double[numVoices];
        voiceAge = new int[numVoices];
        voiceDelay = new int[numVoices];
        java.util.Arrays.fill(voiceDelay, lookback);
        hopSize = Math.max(1, grainSize / 3);
    }

    public void setSemitones(float st) { semitones = st; }

    public void clear() {
        java.util.Arrays.fill(circ[0], 0f); java.util.Arrays.fill(circ[1], 0f);
        java.util.Arrays.fill(voicePhase, 0.0); java.util.Arrays.fill(voiceAge, 0); java.util.Arrays.fill(voiceDelay, lookback);
        writePos = 0; nextTrig = 0; zPrev = semitones; pitchRatioSmoothed = Math.pow(2.0, semitones / 12.0);
    }

    private int rnd(int lo, int hi) {                                   // cheap LCG, no allocation
        seed = seed * 6364136223846793005L + 1442695040888963407L;
        return lo + (int) (((seed >>> 33) & 0x7fffffffL) % (hi - lo + 1));
    }

    /** The pitch ratio glides towards the target so that changing the interval never clicks. */
    public void process(float[] inL, float[] inR, float[] outL, float[] outR, int n) {
        final float a = 0.995f;
        zPrev = a * zPrev + (1f - a) * semitones;
        final double ratio = Math.pow(2.0, zPrev / 12.0);
        pitchRatioSmoothed = a * pitchRatioSmoothed + (1.0 - a) * ratio;
        final float inv = 1f / numVoices;
        for (int i = 0; i < n; i++) {
            circ[0][writePos] = inL[i]; circ[1][writePos] = inR[i];
            float accL = 0f, accR = 0f;
            for (int v = 0; v < numVoices; v++) {
                if (voiceAge[v] <= 0) {
                    voiceAge[v] = grainSize;
                    voicePhase[v] = 0.0;
                    voiceDelay[v] = lookback + (jitter > 0 ? rnd(-jitter, jitter) : 0);
                }
                final double ph = voicePhase[v];
                final int ip = (int) ph;
                final float frac = (float) (ph - ip);
                final float env = window[ip % grainSize];
                int r1 = (writePos - voiceDelay[v] + ip) % circSize; if (r1 < 0) r1 += circSize;
                int r2 = r1 + 1; if (r2 >= circSize) r2 = 0;
                accL += (circ[0][r1] * (1f - frac) + circ[0][r2] * frac) * env * inv;
                accR += (circ[1][r1] * (1f - frac) + circ[1][r2] * frac) * env * inv;
                voicePhase[v] += pitchRatioSmoothed;
                voiceAge[v]--;
                if (voicePhase[v] >= grainSize) voicePhase[v] -= grainSize;
            }
            outL[i] = accL; outR[i] = accR;
            if (++writePos >= circSize) writePos = 0;
            if (++nextTrig >= hopSize) {
                nextTrig = 0;
                int minIdx = 0, minAge = voiceAge[0];
                for (int v = 1; v < numVoices; v++) if (voiceAge[v] < minAge) { minAge = voiceAge[v]; minIdx = v; }
                voiceAge[minIdx] = 0;
            }
        }
    }
}
