package com.gfdrps.android;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;

/** Foreground service (type mediaProjection) that keeps the capture of other apps' audio alive while the user is in another app. */
public final class CaptureService extends Service {
    static final String EXTRA_CODE = "code", EXTRA_DATA = "data", ACTION_STOP = "stop";
    private static final String CH = "gfdrps_capture";

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent in, int flags, int startId) {
        if (in == null || ACTION_STOP.equals(in.getAction())) {
            AppCapture.stopInternal();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel(CH, "Captura de áudio", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CH).setContentTitle("Gf Drps está gravando o áudio de outros apps")
                .setContentText("Toque para voltar e salvar na track").setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(77, n);
            MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
            Intent data = in.getParcelableExtra(EXTRA_DATA);
            MediaProjection mp = mpm.getMediaProjection(in.getIntExtra(EXTRA_CODE, 0), data);
            AppCapture.start(mp);
        } catch (Throwable t) {
            AppCapture.stopInternal();
            stopForeground(true);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() { AppCapture.stopInternal(); super.onDestroy(); }
}
